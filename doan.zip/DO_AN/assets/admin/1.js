jQuery(document).ready(function($) {
	$('.btnbar').click(function(event) {
		$('.main').toggleClass('pull_sidebar');
		return false;
	});
});