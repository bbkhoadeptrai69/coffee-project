jQuery(document).ready(function($) {

	//code effect first load
	TweenMax.from($('.slide-top .layer1'), 5, {opacity: 0, x: -400, ease: Elastic.easeOut.config(1, 0.2)});
	TweenMax.from($('.slide-top .layer2'), 5, {opacity: 0, x: -400, delay: 0.3, ease: Elastic.easeOut.config(1, 0.2)});
	TweenMax.from($('.slide-top .layer3'), 3, {opacity: 0, x: -400, delay: 1, ease: Bounce.easeOut});

	//code load products
	var i = 0.5, item = 0;
	$('.products div').each(function(index, el) {
		var time_delay = i+"s";
		$(this).addClass('wow').addClass('bounceInUp');
		$(this).css('animation-duration', '1s');
		$(this).css('animation-delay', time_delay);
		i+= 0.3;
		item++;
		if(item % 3 == 0)
			i = 0.5;		
	});


	//code click content-menu in menu page
	// $('.content-menu .sidebar ul li a').click(function(event) {
	// 	console.log('aaa');
	// 	var id = $(this).attr('href');

	// 	var khoangcach = $(id).offset().top - 100;

	// 	$('html').animate({scrollTop: khoangcach}, 1000, "easeOutCirc");

	// 	return false;
	// });


	//code effect scroll
	$(window).scroll(function(event) {
		var vitri_hientai = $(this).scrollTop();

		//for sidebar
		if($('div').hasClass('content-menu')){
			var vitri_sidebar = $('.content-menu .content').offset().top - 70;
			if(vitri_hientai >= vitri_sidebar){
			 	$('.content-menu .sidebar').addClass('position_fixed');
			}
			else{
				$('.content-menu .sidebar').removeClass('position_fixed');
			}
		}
		
		//for menu top
		if(vitri_hientai > 50){
			$('.menu .navbar').addClass('bg_menu');
		}
		else{
			$('.menu .navbar').removeClass('bg_menu');
		}
	});



	//code for effect click img in single page
	$('.product-info .duoi a').click(function(event) {	
		$('.product-info .duoi a').removeClass('active');
		$(this).addClass('active');

		var vitri_click = $(this).index() + 1;
		var vitri_img_active = $('.product-info .tren img.active').index() + 1;

		$('.product-info .tren img.active').addClass('bienmatquatrai').one('webkitAnimationEnd', function(event) {
			$(this).removeClass('active').removeClass('bienmatquatrai');
		});
		$('.product-info .tren img:nth-child('+vitri_click+')').addClass('xuathienquatrai').one('webkitAnimationEnd', function(event) {
			$(this).addClass('active').removeClass('xuathienquatrai');
		});
		return false;
	});

	//code for event click tab in single page
	if($('div').hasClass('mota-danhgia')){
		$('.mota-danhgia .duoi .vuong1').css('left', $('.mota-danhgia .tren li a.active').position().left + 24 + 'px');
		$('.mota-danhgia .duoi .vuong2').css('left', $('.mota-danhgia .tren li a.active').position().left + 24 + 'px');
		$('.mota-danhgia .tren ul li a').click(function(event) {
			console.log("aa");
			$('.mota-danhgia .tren li a').removeClass('active');
			$('.mota-danhgia .duoi li').removeClass('active');
			$(this).addClass('active');

			var id = $(this).attr('href');
			$(id).addClass('active');

			//console.log($(this).position().left);
			var toado = $(this).position().left + 24 + 'px';
			$('.mota-danhgia .duoi .vuong1').css('left', toado);
			$('.mota-danhgia .duoi .vuong2').css('left', toado);

			return false;
		});
	}
	

	//code set Interval for carousel-danhgia in single page
	$('#item2').mousemove(function(event) {
		clearInterval();
	});

	//code effect loading
	if($('div').hasClass('loading')){
		var hieuungloading = new TimelineMax({onComplete: chuyendong});
		hieuungloading.to($('.loading .tron1'), 0, {opacity: 0})
				      .to($('.loading .tron2'), 0, {opacity: 0})
					  .to($('.loading .tronzoom'), 0.3, {scale: 2})
					  .to($('.loading .tron1'), 0, {opacity: 1})
				      .to($('.loading .tron2'), 0, {opacity: 1});			  

		function chuyendong(){
			var hieuungtron1 = new TimelineMax({repeat: 1});
			hieuungtron1.to($('.loading .tron1'), 0.2, {x: 30, opacity: 1})
						.to($('.loading .tron1'), 0.2, {x: 0, opacity: 1});

			var hieuungtron2 = new TimelineMax({onComplete: bienmat ,repeat: 1});
			hieuungtron2.to($('.loading .tron2'), 0.2, {x: -30, opacity: 1})
						.to($('.loading .tron2'), 0.2, {x: 0, opacity: 1});
		}

		// var hieuungbienmat = new TimelineMax({onComplete: noidungdivao, paused: true});
		// hieuungbienmat.to($('.loading'), 0.5, {x: -1200});
		function bienmat(){
			var hieuungbienmat = new TimelineMax({onComplete: noidungdivao});
			hieuungbienmat.to($('.loading .tronzoom'), 0.3, {scale: 0})
						  .to($('.loading .tron1'), 0, {opacity: 0})
				      	  .to($('.loading .tron2'), 0, {opacity: 0});
		}

		function noidungdivao(){
			TweenMax.from($('.content-main'), 0.2, {opacity: 0});
			TweenMax.to($('.loading'), 0, {zIndex: 0, visibility:'hidden'});
		}
	}


	// index page

	//code click btnclose
	$('.dangnhap .btnclose').click(function(event) {
		$('.dangnhap').css('visibility', 'hidden').css('opacity', '0');
		return false;
	});
	//code click open dangnhap
	$('.btnDangNhap').click(function(event) {
		$('.dangnhap').css('visibility', 'visible').css('opacity', '1');
		return false;
	});
	//xử lý sự kiện đăng nhập
	$('.dangnhap .btnDangNhapNgay').click(function(event) {
		$('.valid').text('');
		if($('.username').val() == '')
		{
			$('.validationUsername').text('Vui lòng không bỏ trống ô này');
			$('.username').focus();
		}
		else if($('.password').val() == '')
		{
			$('.validationPassword').text('Vui lòng không bỏ trống ô này');
			$('.password').focus();
		}

		else
		{
			$.ajax({
				url: '/DO_AN/User/dangNhap',
				type: 'POST',
				dataType: 'json',
				data: {
					username: $('.username').val(),
					password: $('.password').val()
				},
			})
			.done(function() {
				console.log("success");
			})
			.fail(function() {
				console.log("error");
			})
			.always(function(res) {
				console.log("complete");
				if(res == -1){
					$('.thongbao').text('Username này không tồn tại.');
					$('.username').select().focus();
				}
				else if(res == 0){
					$('.thongbao').text('Sai mật khẩu');
					$('.password').select().focus();	
				}
				else if(res == 1){
					location.reload();
				}
			});
			
		}
	});
	// //xử lý sự kiện đăng nhập khi đang ở trang thanh toán
	// $('.khachhang-dangnhap #dangnhap .btnDangNhap').click(function(event) {
	// 	$('.valid').text('');
	// 	if($('.username').val() == '')
	// 	{
	// 		$('#dangnhap .validationUsername').text('Vui lòng không bỏ trống ô này');
	// 		$('#dangnhap .username').focus();
	// 	}
	// 	else if($('.password').val() == '')
	// 	{
	// 		$('#dangnhap .validationPassword').text('Vui lòng không bỏ trống ô này');
	// 		$('#dangnhap .password').focus();
	// 	}

	// 	else
	// 	{
	// 		$.ajax({
	// 			url: '/DO_AN/User/dangNhap',
	// 			type: 'POST',
	// 			dataType: 'json',
	// 			data: {
	// 				username: $('.username').val(),
	// 				password: $('.password').val()
	// 			},
	// 		})
	// 		.done(function() {
	// 			console.log("success");
	// 		})
	// 		.fail(function() {
	// 			console.log("error");
	// 		})
	// 		.always(function(res) {
	// 			console.log("complete");
	// 			if(res == -1){
	// 				$('#dangnhap .thongbao').text('Username này không tồn tại.');
	// 				$('.username').select().focus();
	// 			}
	// 			else if(res == 0){
	// 				$('#dangnhap .thongbao').text('Sai mật khẩu');
	// 				$('.password').select().focus();	
	// 			}
	// 			else if(res == 1){
	// 				//đăng nhập thành công
	// 				location.reload();
	// 			}
	// 		});
	// 	}		
	// });	

	//code effect menu
	$('.user').click(function(event) {
		$('.user-setting').slideToggle(500);
	});

	//code effect cho trang thanh toán
	var li_active = $('.khachhang-dangnhap .thongtinkhachhang ul li.active');
	$('.khachhang-dangnhap .thongtinkhachhang ul li').click(function(event) {
		$('.khachhang-dangnhap .thongtinkhachhang ul li').removeClass('active');

		$(this).addClass('active');
		li_active= $(this);

		$('.phai div.user').addClass('d-none');
		var id = $(this).data('id');
		$(id).removeClass('d-none');
	});
	$('.khachhang-dangnhap .thongtinkhachhang ul li').mouseenter(function(event) {
		$(this).addClass('active');
	});
	$('.khachhang-dangnhap .thongtinkhachhang ul li').mouseleave(function(event) {

		$(this).removeClass('active');
		li_active.addClass('active');
	});



	//start wow js
	new WOW().init();
});