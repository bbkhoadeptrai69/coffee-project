<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		
	}

	private function kiemtraquyen()
	{
		if($this->session->has_userdata('user'))
		{
			foreach ($this->session->userdata('quyen') as $item) {
				if($item['maquyen'] == 'quantrivien')
				{
					return 1;
				}
				if($item['maquyen'] == 'quanlydonhang')
				{
					return 2;
				}
			}
			
		}
		return false;
	}

	private function loadmenutop()
	{
		$this->load->model('Dondathang_model');
		$dsDDHChuaxacnhan = $this->Dondathang_model->get('chuaxacnhan');
		$dsDDHChuaxacnhan = array(
			'dsDDHChuaxacnhan' => $dsDDHChuaxacnhan
		);

		$this->load->view('admin/menu-top.php', $dsDDHChuaxacnhan);
	}
	public function index()
	{
		if($this->kiemtraquyen() == 1)
		{
			$this->loadmenutop();

			$tongdoanhthu = $this->tinhtongdoanhthu();
			$tongdoanhthu = array(
				'tongdoanhthu' => $tongdoanhthu
			);

			$this->load->view('admin/admin_view', $tongdoanhthu);
		}
		else
		{
			$this->load->view('admin/saiquyen_view');
		}
	}

	public function thongke()
	{
		$namthongke = $this->input->post('namthongke');

		if($namthongke != '')
		{
			$doanhthutheonam = $this->thongkedoanhthutheonam($namthongke);
			$khachhangtheonam = $this->thongkekhachhangtheonam($namthongke);
			$donhangtheonam = $this->thongkedonhangtheonam($namthongke);

			$dl = array(
				'doanhthutheonam' =>$doanhthutheonam,
				'khachhangtheonam' => $khachhangtheonam,
				'donhangtheonam' => $donhangtheonam
			);

			echo json_encode($dl);
		}
	}

	private function thongkedoanhthutheonam($nam)
	{
		$doanhthutheonam = array(
			'thang1' => $this->tinhdoanhthutheothangnam(1, $nam),
			'thang2' => $this->tinhdoanhthutheothangnam(2, $nam),
			'thang3' => $this->tinhdoanhthutheothangnam(3, $nam),
			'thang4' => $this->tinhdoanhthutheothangnam(4, $nam),
			'thang5' => $this->tinhdoanhthutheothangnam(5, $nam),
			'thang6' => $this->tinhdoanhthutheothangnam(6, $nam),
			'thang7' => $this->tinhdoanhthutheothangnam(7, $nam),
			'thang8' => $this->tinhdoanhthutheothangnam(8, $nam),
			'thang9' => $this->tinhdoanhthutheothangnam(9, $nam),
			'thang10' => $this->tinhdoanhthutheothangnam(10, $nam),
			'thang11' => $this->tinhdoanhthutheothangnam(11, $nam),
			'thang12' => $this->tinhdoanhthutheothangnam(12, $nam),

		);
		return $doanhthutheonam;
	}
	private function thongkekhachhangtheonam($nam)
	{
		$khachhangtheonam = array(
			'thang1' => $this->tinhsoluongkhachhangtheothangnam(1, $nam),
			'thang2' => $this->tinhsoluongkhachhangtheothangnam(2, $nam),
			'thang3' => $this->tinhsoluongkhachhangtheothangnam(3, $nam),
			'thang4' => $this->tinhsoluongkhachhangtheothangnam(4, $nam),
			'thang5' => $this->tinhsoluongkhachhangtheothangnam(5, $nam),
			'thang6' => $this->tinhsoluongkhachhangtheothangnam(6, $nam),
			'thang7' => $this->tinhsoluongkhachhangtheothangnam(7, $nam),
			'thang8' => $this->tinhsoluongkhachhangtheothangnam(8, $nam),
			'thang9' => $this->tinhsoluongkhachhangtheothangnam(9, $nam),
			'thang10' => $this->tinhsoluongkhachhangtheothangnam(10, $nam),
			'thang11' => $this->tinhsoluongkhachhangtheothangnam(11, $nam),
			'thang12' => $this->tinhsoluongkhachhangtheothangnam(12, $nam),

		);
		return $khachhangtheonam;
	}

	private function thongkedonhangtheonam($nam)
	{
		$donhangtheonam = array(
			'thang1' => $this->tinhsoluongdonhangtheothangnam(1, $nam),
			'thang2' => $this->tinhsoluongdonhangtheothangnam(2, $nam),
			'thang3' => $this->tinhsoluongdonhangtheothangnam(3, $nam),
			'thang4' => $this->tinhsoluongdonhangtheothangnam(4, $nam),
			'thang5' => $this->tinhsoluongdonhangtheothangnam(5, $nam),
			'thang6' => $this->tinhsoluongdonhangtheothangnam(6, $nam),
			'thang7' => $this->tinhsoluongdonhangtheothangnam(7, $nam),
			'thang8' => $this->tinhsoluongdonhangtheothangnam(8, $nam),
			'thang9' => $this->tinhsoluongdonhangtheothangnam(9, $nam),
			'thang10' => $this->tinhsoluongdonhangtheothangnam(10, $nam),
			'thang11' => $this->tinhsoluongdonhangtheothangnam(11, $nam),
			'thang12' => $this->tinhsoluongdonhangtheothangnam(12, $nam),

		);
		return $donhangtheonam;
	}

	private function tinhdoanhthutheothangnam($thang, $nam)
	{
		$this->load->model('ChitietDDH_model');
		$dsChitietDDHDathanhtoan = $this->ChitietDDH_model->layChiTietDDHByMatinhtrang('dathanhtoan');
		$tongdoanhthu = 0;
		foreach ($dsChitietDDHDathanhtoan as $item) {
			//echo date('m', $item['ngaydat']);
			if($thang == date('m', $item['ngaydat']) && $nam == date('Y', $item['ngaydat']))
			{
				$tongdoanhthu += $item['dongia'];
			}
		}
		return $tongdoanhthu;
	}

	private function tinhsoluongkhachhangtheothangnam($thang, $nam)
	{
		$this->load->model('Thanhvien_model');
		$dskhachhang = $this->Thanhvien_model->laykhachhang();

		$tongkhachhang = 0;
		foreach ($dskhachhang as $item) {
			if($thang == date('m', $item['create']) && $nam == date('Y', $item['create']))
			{
				$tongkhachhang += 1;
			}
		}
		return $tongkhachhang;
	}

	private function tinhsoluongdonhangtheothangnam($thang, $nam)
	{
		$this->load->model('ChitietDDH_model');
		$dsChitietDDH = $this->ChitietDDH_model->thongkedonhang();
	
		$tongdonhang = 0;

		foreach ($dsChitietDDH as $item) {
			if($thang == date('m', $item['ngaydat']) && $nam == date('Y', $item['ngaydat']))
			{
				$tongdonhang += 1;
			}
		}
		return $tongdonhang;
	}

	public function menu()
	{
		if($this->kiemtraquyen() == 1)
		{
			$this->loadmenutop();

			$this->load->model('Homepage_model');
			$danhsachmenu = $this->Homepage_model->getMenu();
			$danhsachitemmenu = $this->Homepage_model->getItemMenu();
			$dl = array(
				'danhsachmenu' => json_decode($danhsachmenu, true),
				'danhsachitemmenu' => $danhsachitemmenu
			);
			// echo '<pre>';
			// var_dump($dl);
			// echo '</prev>'; die();
			$this->load->view('admin/menu_view', $dl);
		}
		else
		{
			$this->load->view('admin/saiquyen_view');
		}
	}
	public function themMenu()
	{			
		$this->load->model('Homepage_model');
		$dulieucu = $this->Homepage_model->getItemMenu(); 
		//$dulieucu = json_decode($dulieucu, true);

		$textmenu = $this->input->post('textmenu');
		$linkmenu = $this->input->post('linkmenu');
		$textmenuphu = $this->input->post('textmenuphu'); 
		$linkmenuphu = $this->input->post('linkmenuphu');
		
		$menuphu = array();
		for ($i = 0; $i < count($textmenuphu); $i++) {
			$temp = array(
				'textmenuphu' => $textmenuphu[$i],
				'linkmenuphu' => $linkmenuphu[$i]
			);
			array_push($menuphu, $temp);
		}

		$item = array(
			'textmenu' => $textmenu,
			'linkmenu' => $linkmenu, 
			'menuphu' => $menuphu
		);
		if(is_null($dulieucu)){
			$dulieucu = array();
		}		
		array_push($dulieucu, $item);

		$temp = array(
			'textlogo' => $this->input->post('textlogo'),
			'item'=> $dulieucu
		);
		$dulieucapnhat = array();
		array_push($dulieucapnhat, $temp);
		$this->Homepage_model->updateMenu(json_encode($dulieucapnhat));
	}

	public function slide()
	{	
		if($this->kiemtraquyen() == 1)
		{
			$this->loadmenutop();
			$this->load->model('Homepage_model');		
			$mangdulieu = $this->Homepage_model->getSlide();
			$mangdulieu = array('slide' => json_decode($mangdulieu, true));
			$this->load->view('admin/slide_view', $mangdulieu);
		}
		else
		{
			$this->load->view('admin/saiquyen_view');
		}
		
	}

	public function themSlide()
	{
		$this->load->model('Homepage_model');
		$dulieucu = $this->Homepage_model->getSlide();
		$dulieucu = json_decode($dulieucu, true);

		$tieude1 = $this->input->post('tieude1');
		$tieude2 = $this->input->post('tieude2');
		$mota = $this->input->post('mota');
		$anh = base_url() . $this->uploadAnh('uploads', 'anh');

		$mangdulieu = array(
							'tieude1' =>$tieude1,
							'tieude2' => $tieude2,
							'anh' => $anh,
							'mota' => $mota
							);
		if(is_null($dulieucu))
			$dulieucu = array();
		array_push($dulieucu, $mangdulieu);
		$dulieumoi = json_encode($dulieucu);
		if($this->Homepage_model->updateSlide($dulieumoi))
		{
			$rs = array(
				'stt' => true,
				'anh' => $anh
			);
			echo json_encode($rs);
		}
		else {
			$rs = array('stt' => false);
			echo json_encode(false);
		}
		
	}

	public function luuSlide()
	{
		$tieude1 =  $this->input->post('tieude1');
		$tieude2 = $this->input->post('tieude2');
		$anh = $this->input->post('anh'); echo json_encode($anh);
		$mota = $this->input->post('mota');
		$mangdulieu = array();
		if($tieude1 != '')
		{
			for ($i = 0; $i < count($tieude1); $i++) {
				$temp = array(
					'tieude1' => $tieude1[$i],
					'tieude2' => $tieude2[$i],
					'anh' => $anh[$i],
					'mota' => $mota[$i]
				);

				array_push($mangdulieu, $temp);
			}
		}
		
		$mangdulieu = json_encode($mangdulieu);
		$this->load->model('Homepage_model');
		if($this->Homepage_model->updateSlide($mangdulieu)){
			$rs = array('stt' => true);
			echo json_encode($rs);
		}
		else {
			$rs = array('stt' => false);
			echo json_encode($rs);
		}
		//echo json_encode($mangdulieu);
	}

	public function footer()
	{
		if($this->kiemtraquyen() == 1)
		{
			$this->loadmenutop();
			$this->load->view('admin/footer_view');
		}
		else
		{
			$this->load->view('admin/saiquyen_view');
		}
		
	}
	public function updateFooter()
	{
		$this->load->model('Homepage_model');
		$textlogo = $this->input->post('textlogo');
		$gioithieu = $this->input->post('gioithieu');
		$diachi = $this->input->post('diachi');
		$dienthoai = $this->input->post('dienthoai');
		$email = $this->input->post('email');
		$t2_t6 = $this->input->post('t2_t6');
		$t7 = $this->input->post('t7');
		$cn = $this->input->post('cn');

		$mangdulieu = array(
			'textlogo' => $textlogo,
			'gioithieu' =>$gioithieu,
			'diachi' =>$diachi,
			'dienthoai' => $dienthoai,
			'email' => $email,
			't2-t6' => $t2_t6,
			't7' => $t7,
			'cn' => $cn
		);

		$dulieuupdate = array();
		array_push($dulieuupdate, $mangdulieu);
		$dulieumoi = json_encode($dulieuupdate);
		$this->Homepage_model->updateFooter($dulieumoi);
	}

	public function sanpham()
	{
		if($this->kiemtraquyen() == 1)
		{
			$this->loadmenutop();

			$this->load->model('Loaisanpham_model');
			$this->load->model('Sanpham_model');
			$dssanpham = $this->Sanpham_model->getSanPham();
			$mangdulieu = array(
				'dssanpham' => $dssanpham,
				'loaisanpham' => $this->Loaisanpham_model->getLoaiSanPham()
			);
			$this->load->view('admin/sanpham_view', $mangdulieu);
		}
		else
		{
			$this->load->view('admin/saiquyen_view');
		}
		
	}
	public function themSanPham()
	{
		$tensp = $this->input->post('tensp');
		$gia = $this->input->post('gia');
		$mota = $this->input->post('mota');
		$maloaisp = $this->input->post('maloaisp');
		if($this->input->post('noibat'))
			$noibat = 1;
		else
			$noibat = 0;
		$soluongton = $this->input->post('soluongton');
		$hinhanh = base_url() . $this->uploadAnh('uploads', 'hinhanh');

		$this->load->model('Sanpham_model');
		$id = $this->Sanpham_model->themSanPham($tensp, $gia, $mota, $hinhanh, $maloaisp, $noibat, $soluongton);

		//lấy tên loại sản phẩm
		$this->load->model('Loaisanpham_model');
		$loaisanpham = $this->Loaisanpham_model->getLoaiSanPhamById($maloaisp);
		
		
		if($id > 0)
		{
			$rs = array(
				'id' => $id,
				'hinhanh' => $hinhanh,
				'tenloaisp' => $loaisanpham[0]['tenloaisp'],
				'gia' => $gia
			);
			echo json_encode($rs);
		}
	}

	public function xoaSanPham()
	{
		$this->load->model('Sanpham_model');
		if($this->Sanpham_model->xoaSanPham($this->input->post('masp')))
		{
			echo json_encode(true);
		}
		else
		{
			echo json_encode(false);
		}
	}

	public function chinhSuaSanPham($masp)
	{
		
	}

	public function loaisanpham()
	{
		if($this->kiemtraquyen() == 1)
		{
			$this->loadmenutop();

			$this->load->model('Loaisanpham_model');
			$mangdulieu = $this->Loaisanpham_model->getLoaiSanPham();
			$mangdulieu = array(
				'dsloaisanpham' => $mangdulieu
			);
			$this->load->view('admin/loaisanpham_view', $mangdulieu);
		}
		else
		{
			$this->load->view('admin/saiquyen_view');
		}
		
	}

	public function themLoaiSanPham()
	{
		$tenloaisp = $this->input->post('tenloaisp');
		$this->load->model('Loaisanpham_model');
		$id = $this->Loaisanpham_model->them($tenloaisp);
		if($id > 0)
		{
			echo json_encode($id);
		}
		else
		{
			echo json_encode(0);
		}
	}

	public function luuLoaiSanPham()
	{
		$id = $this->input->post('id');
		$tenloaisp = $this->input->post('tenloaisp');
		$this->load->model('Loaisanpham_model');
		if($this->Loaisanpham_model->luu($id, $tenloaisp))
		{
			echo json_encode(true);
		}
		else
		{
			echo json_encode(false);
		}
	}

	public function xoaLoaiSanPham()
	{
		$id = $this->input->post('id');
		
		$this->load->model('Sanpham_model');
		$sanphambelong = $this->Sanpham_model->getSPByIdLoaiSP($id);

		if(count($sanphambelong) == 0)
		{
			$this->load->model('Loaisanpham_model');
			$this->Loaisanpham_model->xoa($id);
			echo json_encode(true);
		}
		else
		{
			echo json_encode(false);
		}
	}

	public function nguyenlieu()
	{
		$this->load->view('admin/nguyenlieu_view');
	}

	public function thanhvien()
	{
		if($this->kiemtraquyen() == 1)
		{
			$this->loadmenutop();

			$this->load->model('Loaithanhvien_model');
			$this->load->model('Thanhvien_model');
			$mangdulieu = array(
				'loaithanhvien' => $this->Loaithanhvien_model->getLoaiThanhVien(),
				'dsthanhvien' => $this->Thanhvien_model->layThanhVien()
			);
			// echo '<pre>';
			// var_dump($mangdulieu['dsthanhvien'][0]['taikhoan']);
			// echo '</prev>'; die();
			//echo json_encode($mangdulieu['dsthanhvien']); die();
			$this->load->view('admin/thanhvien_view', $mangdulieu);
		}
		else
		{
			$this->load->view('admin/saiquyen_view');
		}
		
	}
	public function themThanhVien()
	{
		$avatar = base_url() . $this->uploadAnh('uploads', 'avatar');
		$hoten = $this->input->post('hoten');
		$taikhoan = $this->input->post('taikhoan');
		$matkhau = $this->input->post('matkhau');
		$diachi = $this->input->post('diachi');
		$email = $this->input->post('email');
		$sodienthoai = $this->input->post('sodienthoai');
		$maloaitv = $this->input->post('maloaitv');
		$macapdo = $this->input->post('macapdo');
		
		$this->load->model('Thanhvien_model');
		$id = $this->Thanhvien_model->themThanhVien($taikhoan, $matkhau, $hoten, $diachi, $email, $avatar, $sodienthoai, $maloaitv, $macapdo);
		if ($id > 0) {
			$rs = array(
				'id' => $id,
				'avatar' => $avatar
			);
			echo json_encode($rs);
		}
		else{
			echo json_encode(0);
		}
	}
	public function xoaThanhVien()
	{
		$matv = $this->input->post('matv');
		$this->load->model('Thanhvien_model');
		if($this->Thanhvien_model->xoaThanhVien($matv))
		{
			echo json_encode(true);
		}
		else
		{
			echo json_encode(false);
		}

	}

	public function luuThanhVien()
	{
		$avatar = $this->input->post('avatarcu');
		if($avatar == null)
		{
			$avatar = $this->uploadAnh('uploads', 'avatarmoi');

		}

		echo json_encode($avatar);  
	}


	public function loaithanhvien()
	{
		if($this->kiemtraquyen() == 1)
		{
			$this->loadmenutop();

			$this->load->model('Loaithanhvien_model');
			$mangdulieu = $this->Loaithanhvien_model->getLoaiThanhVien();
			$mangdulieu = array(
				'dsloaithanhvien' => $mangdulieu
			);
			$this->load->view('admin/loaithanhvien_view', $mangdulieu);
		}
		else
		{
			$this->load->view('admin/saiquyen_view');
		}
		
	}

	public function themLoaiThanhVien()
	{
		$tenloaitv = $this->input->post('tenloaitv');
		$this->load->model('Loaithanhvien_model');
		$id = $this->Loaithanhvien_model->them($tenloaitv);
		if($id > 0)
		{
			echo json_encode($id);
		}
		else
		{
			echo json_encode(0);
		}
	}

	public function luuLoaiThanhVien()
	{
		$idcu = $this->input->post('idcu');
		$idmoi = $this->input->post('idmoi');
		$tenloaitv = $this->input->post('tenloaitv');
		$this->load->model('Loaithanhvien_model');
		if($this->Loaithanhvien_model->luu($idcu, $idmoi, $tenloaitv))
		{
			echo json_encode(true);
		}
		else
		{
			echo json_encode(false);
		}
	}

	public function xoaLoaiThanhVien()
	{
		$id = $this->input->post('id');
		
		$this->load->model('Thanhvien_model');
		$thanhvienbelong = $this->Thanhvien_model->getTVByIdLoaiTV($id);

		if(count($thanhvienbelong) == 0)
		{
			$this->load->model('Loaithanhvien_model');
			$this->Loaithanhvien_model->xoa($id);
			echo json_encode(true);
		}
		else
		{
			echo json_encode(false);
		}
	}

	public function dondathang()
	{	
		if($this->kiemtraquyen() == 1 || $this->kiemtraquyen() == 2)
		{
			$this->loadmenutop();

			$this->load->model('Dondathang_model');
			$DDHChuaxacnhan = $this->Dondathang_model->get('chuaxacnhan');
			$DDHChuagiao = $this->Dondathang_model->get('daxacnhan');
			$DDHChuathanhtoan = $this->Dondathang_model->get('dagiao');
			$DDHDathanhtoan = $this->Dondathang_model->get('dathanhtoan');
			$DDHDahuy = $this->Dondathang_model->get('dahuy');
			$DDH = array(
				'DDHChuaxacnhan' => $DDHChuaxacnhan,
				'DDHChuagiao' => $DDHChuagiao,
				'DDHChuathanhtoan' => $DDHChuathanhtoan,
				'DDHDathanhtoan' => $DDHDathanhtoan,
				'DDHDahuy' => $DDHDahuy
			);
			$this->load->view('admin/dondathang_view', $DDH);
		}
		else
		{
			$this->load->view('admin/saiquyen_view');
		}
		
	}

	public function chitietddh($maddh)
	{
		if($this->kiemtraquyen() == 1 || $this->kiemtraquyen() == 2)
		{
			$this->loadmenutop();

			$this->load->model('ChitietDDH_model');
			$this->load->model('Tinhtrang_model');
			$dschitietDDH =  $this->ChitietDDH_model->layChiTietDDHByMaDDH($maddh);
			$dstinhtrang = $this->Tinhtrang_model->get();
			$dschitietDDH = array(
				'dschitietDDH' => $dschitietDDH,
				'dstinhtrang' => $dstinhtrang
			);
			$this->load->view('admin/chitietddh_view', $dschitietDDH);	
		}
		else
		{
			$this->load->view('admin/saiquyen_view');
		}
		
	}

	public function duyetdonhang()
	{
		$machitietddh = $this->input->post('machitietddh');
		$matinhtrang = $this->input->post('matinhtrang');
		
		$this->load->model('ChitietDDH_model');
		$rs = $this->ChitietDDH_model->capnhattinhtrang($machitietddh, $matinhtrang);

		if($matinhtrang == 'dathanhtoan')
		{
			$masp = $this->input->post('masp');
			$this->capnhatsolanmuasp($masp);
		}
	}

	private function capnhatsolanmuasp($masp)
	{
		$this->load->model('Sanpham_model');
		$sanpham = $this->Sanpham_model->getSanPhamById($masp);
		$solanmua;
		foreach ($sanpham as $item) {
			$solanmua = $item['solanmua'];
		}
		$solanmua++;
		$this->Sanpham_model->capnhatsolanmuasp($masp, $solanmua);
	}

	public function tinhtongdoanhthu()
	{
		$this->load->model('ChitietDDH_model');
		$dsChitietDDHDathanhtoan = $this->ChitietDDH_model->layChiTietDDHByMatinhtrang('dathanhtoan');
		$tongdoanhthu = 0;
		foreach ($dsChitietDDHDathanhtoan as $item) {
			$tongdoanhthu += $item['dongia'];
		}

		return $tongdoanhthu;
	}

	

	public function uploadAnh($file_dir, $file_name)
	{
		//xử lý lấy file ảnh
		$target_dir = $file_dir.'/';
		$target_file = $target_dir . basename($_FILES[$file_name]["name"]);
		$uploadOk = 1;
		$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
		// Check if image file is a actual image or fake image
		if(isset($_POST["submit"])) {
		    $check = getimagesize($_FILES[$file_name]["tmp_name"]);
		    if($check !== false) {
		        echo "File là một ảnh - " . $check["mime"] . ".";
		        $uploadOk = 1;
		    } else {
		        echo "File không phải là một ảnh.";
		        $uploadOk = 0;
		    }
		}
		// Check if file already exists
		// if (file_exists($target_file)) {
		//     return $target_file;
		// }
		// Check file size
		if ($_FILES[$file_name]["size"] > 50000000) {
		    echo "Kích thước file quá lớn.";
		    $uploadOk = 0;
		}
		// Allow certain file formats
		if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
		&& $imageFileType != "gif" ) {
		    echo "chỉ nhận file có đuôi JPG, JPEG, PNG & GIF.";
		    $uploadOk = 0;
		}
		// Check if $uploadOk is set to 0 by an error
		if ($uploadOk == 0) {
		    echo "Upload file thất bại.";
		    return '';
		// if everything is ok, try to upload file
		} else {
			move_uploaded_file($_FILES[$file_name]["tmp_name"], $target_file);
			return $target_file;
		}
	}	
}

/* End of file Admin.php */
/* Location: ./application/controllers/Admin.php */