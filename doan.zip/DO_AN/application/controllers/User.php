<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

require ('assets/mail/PHPMailer.php');
require('assets/mail/SMTP.php');
require('assets/mail/phpmailerautoload.php');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class User extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
	}

	public function loadmenu()
	{
		$this->load->model('Homepage_model');
		$menu = $this->Homepage_model->getMenu();
		$menu = array('menu' =>json_decode($menu, true));
		$this->load->view('menu', $menu);
	}

	public function index()
	{
		$this->load->model('Homepage_model');
		$slide = json_decode($this->Homepage_model->getSlide(), true);

		$this->loadmenu();

		$this->load->model('Sanpham_model');
		$dsspnoibat = $this->Sanpham_model->getSanPhamNoiBat(6);

		$dl = array(
			'dsspnoibat' => $dsspnoibat,
			'slide' => $slide
		);

		$this->load->view('index_view', $dl);
		//$this->session->unset_userdata('giohang');
		// $this->session->unset_userdata('user');
	}

	public function menu()
	{
		$this->loadmenu();

		$this->load->model('Loaisanpham_model');
		$this->load->model('Sanpham_model');
		
		$dsloaisp = $this->Loaisanpham_model->getLoaiSanPham();
		$dsspnoibat = $this->Sanpham_model->getTatCaSanPhamNoiBat();
		$dssp = $this->Sanpham_model->getSanPham();
		
		$pagesize = 3;
		$sotrang_arr = array();
		foreach ($dsloaisp as $item) {
			$tatcasp = $this->Sanpham_model->getSPByIdLoaiSP($item['id']);
			if(is_null($tatcasp))
			{
				$sotrang = 0;
			}
			else
			{
				$sotrang = ceil(count($tatcasp) / $pagesize);
			}

			$temp = array(
				$item['id'] => $sotrang
			);
			array_push($sotrang_arr, $temp);
		}


		
		

		$dsloaisp = array(
			'dsloaisp' => $dsloaisp,
			'dsspnoibat' => $dsspnoibat,
			'dssp' =>$dssp,
			'sotrang_arr' => $sotrang_arr
		);

		$this->load->view('menu_view', $dsloaisp);
	}

	public function phantrang()
	{
		$maloaisp = $this->input->post('maloaisp');
		$pageindex = $this->input->post('pageindex');

		$this->load->model('Sanpham_model');
		$tatcasp = $this->Sanpham_model->getSPByIdLoaiSP($maloaisp);
		$pagesize = 3;
		if(is_null($tatcasp))
		{
			$sotrang = 0;
		}
		else
		{
			$sotrang = ceil(count($tatcasp) / $pagesize);
		}

		$dsspphantrang = $this->Sanpham_model->getsanphamphantrang($pagesize, $pageindex);

		$dl =array(
			'sotrang' => $sotrang,
			'dsspphantrang' => $dsspphantrang
		);

		echo json_encode($dl);
	}

	public function dangNhap()
	{
		$username = $this->input->post('username');
		$password = $this->input->post('password');

		$this->load->model('Thanhvien_model');
		$dsthanhvien = $this->Thanhvien_model->layThanhVien();
		$check = -1;
		$matv;
		$hoten;
		$diachi;
		$sodienthoai;
		foreach ($dsthanhvien as $item) {
			if($username == $item['taikhoan'])
			{
				if($password == $item['matkhau']){
					$maloaitv = $item['maloaitv'];
					$matv = $item['matv'];
					$hoten = $item['hoten'];
					$diachi = $item['diachi'];
					$sodienthoai = $item['sodienthoai'];
					$check = 1;
				}
				else{
					$check = 0;
				}
				break;
			}
		}
		
		if($check == -1){
			echo json_encode(-1);
			return; //không tồn tại username
		}
		else if($check == 0){
			echo json_encode(0);
		}
		else if($check == 1){

			$user = array();
			array_push($user, array(
				'username' => $username, 
				'matv'=> $matv,
				'hoten' => $hoten,
				'diachi' => $diachi,
				'sodienthoai'=>$sodienthoai
			));

			$userdata = array(
				'user' => $user,
				'quyen' => $this->Thanhvien_model->layQuyen($maloaitv)
			);

			//echo json_encode($userdata); die();
			$this->session->set_userdata( $userdata );
			echo json_encode(1); //đúng
		}
	}

	public function tudongdangnhap()
	{
		$matv = $this->input->post('matv');
		$this->load->model('Thanhvien_model');
		$tv = $this->Thanhvien_model->getTvById($matv);
		foreach ($tv as $item) {
			$username = $item['taikhoan'];
			$password = $item['matkhau'];
		}

		$dsthanhvien = $this->Thanhvien_model->layThanhVien();
		$check = -1;
		$matv;
		$hoten;
		$diachi;
		$sodienthoai;
		foreach ($dsthanhvien as $item) {
			if($username == $item['taikhoan'])
			{
				if($password == $item['matkhau']){
					$maloaitv = $item['maloaitv'];
					$matv = $item['matv'];
					$hoten = $item['hoten'];
					$diachi = $item['diachi'];
					$sodienthoai = $item['sodienthoai'];
					$check = 1;
				}
				else{
					$check = 0;
				}
				break;
			}
		}
		$user = array();
		array_push($user, array(
			'username' => $username, 
			'matv'=> $matv,
			'hoten' => $hoten,
			'diachi' => $diachi,
			'sodienthoai'=>$sodienthoai
		));
		if($check == -1){
			echo json_encode(-1); //không tồn tại username
		}
		else if($check == 0){
			echo json_encode(0);
		}
		else if($check == 1){
			$userdata = array(
				'user' => $user,
				'quyen' => $this->Thanhvien_model->layQuyen($maloaitv)
			);

			//echo json_encode($userdata); die();
			$this->session->set_userdata( $userdata );
			echo json_encode(1); //đúng
		}
	}

	public function dangXuat()
	{
		$this->session->unset_userdata('user');
		$this->session->unset_userdata('quyen');
		$this->session->unset_userdata('diachi');
		$this->session->unset_userdata('giohang');
	}

	public function dangky()
	{
		$this->loadmenu();
		
		$this->load->view('dangky_view');
	}

	public function themThanhVien()
	{
		$taikhoan = $this->input->post('taikhoan');
		$matkhau = $this->input->post('matkhau');
		$hoten = $this->input->post('hoten');
		$diachi = $this->input->post('diachi');
		$email = $this->input->post('email');
		if(!is_null($this->input->post('avatar')))
		{
			$avatar = base_url() . $this->uploadAnh('uploads', 'avatar');
		}
		else{
			$avatar = '';
		}
		$sodienthoai = $this->input->post('sodienthoai');
		$maloaitv = 'khachhang';

		$this->load->model('Thanhvien_model');
		$id = $this->Thanhvien_model->themThanhVien($taikhoan, $matkhau, $hoten, $diachi, $email, $avatar, $sodienthoai, $maloaitv);
		
		echo json_encode($id);
	}

	public function themGioHang()
	{
		$masp = $this->input->post('masp');
		$this->load->model('Sanpham_model');
		$sanpham = $this->Sanpham_model->getSanPhamById($masp);

		//kiểm tra số lượng tồn
		foreach ($sanpham as $item) {
			$soluongton = $item['soluongton'];
		}
		
		//kiểm tra sản phẩm này đã tồn tại trong giỏ hàng hay chưa
		$check = false; //true: đã tồn tại - false: chưa tồn tại
		$giohang = $this->session->userdata('giohang');

		if(is_null($giohang))
		{
			$giohang = array();	
		}
		else
		{
			foreach ($giohang as $key => $item) {
				if($item['masp'] == $masp)
				{
					//đã tồn tại
					$giohang[$key]['soluong'] += 1;
					$check = true;
					break;
				}
			}
		}
		if($check === false) //chưa tồn tại
		{
			foreach ($sanpham as $item) {
				$temp = array(
					'masp' => $masp,
					'tensp' => $item['tensp'],
					'soluong' => 1,
					'gia' => $item['gia'],
					'hinhanh' => $item['hinhanh']
				);
				array_push($giohang, $temp);
			}
		}

		$tongsoluong = 0;
		foreach ($giohang as $item) {
			$tongsoluong += $item['soluong'];
		}

		$giohang = array('giohang' => $giohang);
		$this->session->set_userdata( $giohang );

		$dl_giohang = array(
			'tongsoluong' => $tongsoluong
		);
		echo json_encode($dl_giohang);
	}

	public function xoagiohang()
	{
		$masp = $this->input->post('masp');
		$giohang = $this->session->userdata('giohang');

		$giohangmoi = array();
		foreach ($giohang as $key => $item) {
			if($masp == $item['masp'])
			{
				unset($giohang[$key]);
			}
			else
			{
				$temp = array(
					'masp' => $item['masp'],
					'tensp' => $item['tensp'],
					'soluong' => $item['soluong'],
					'gia' => $item['gia'],
					'hinhanh' => $item['hinhanh']
				);
				array_push($giohangmoi, $temp);
			}
		}
		if(count($giohang) <= 0)
		{
			$this->session->unset_userdata('giohang');
		}
		else
		{
			$this->session->set_userdata(array('giohang' => $giohangmoi));
		}
	}

	public function capnhatsoluongspgiohang()
	{
		$masp = $this->input->post('masp');
		$soluong = $this->input->post('soluong');

		//kiểm tra coi số lượng này có phù hợp không (phải nhỏ hơn hoặc bằng số lượng tồn của sản phẩm)
		$this->load->model('Sanpham_model');
		$sanpham = $this->Sanpham_model->getSanPhamById($masp);
		foreach ($sanpham as $item) {
			if($soluong > $item['soluongton'])
			{
				$giohang = $this->session->userdata('giohang');
				foreach ($giohang as $key => $value) {
					if($masp == $value['masp'])
					{
						$giohang[$key]['soluong'] = $item['soluongton'];
						break;
					}
				}

				$tongsoluong = 0;
				$tongthanhtien = 0;
				foreach ($giohang as $value) {
					$tongsoluong += $value['soluong'];
					$tongthanhtien += $value['soluong'] * $value['gia'];
				}	

				$giohang = array('giohang' => $giohang);
				$this->session->set_userdata( $giohang );

				$dl = array(
					'stt' => false,
					'soluongton' => $item['soluongton'],
					'tongsoluong' => $tongsoluong,
					'tongthanhtien' => $tongthanhtien
				);

				echo json_encode($dl);


				return;
			}
		}

		$giohang = $this->session->userdata('giohang');
		foreach ($giohang as $key => $item) {
			if($masp == $item['masp'])
			{
				$giohang[$key]['soluong'] = $soluong;
				break;
			}
		}

		$tongsoluong = 0;
		$tongthanhtien = 0;
		foreach ($giohang as $item) {
			$tongsoluong += $item['soluong'];
			$tongthanhtien += $item['soluong'] * $item['gia'];
		}	

		$giohang = array('giohang' => $giohang);
		$this->session->set_userdata( $giohang );

		$dl = array(
			'stt' => true,
			'tongsoluong' => $tongsoluong,
			'tongthanhtien' => $tongthanhtien
		);
		echo json_encode($dl);
	}

	public function giohang()
	{
		$this->loadmenu();

		$giohang = $this->session->userdata('giohang');
		$tongsoluong = 0;
		if(!is_null($giohang))
		{
			foreach ($giohang as $item) {
				$tongsoluong += $item['soluong'];
			}
		}
		else
		{
			$giohang = array();
		}
		$dl = array(
			'tongsoluong' => $tongsoluong,
			'giohang' => $giohang
		);
		$this->load->view('giohang_view', $dl);
	}

	public function thanhtoan()
	{
		$giohang = $this->session->userdata('giohang');
		$tongsoluong = 0;
		if(!is_null($giohang))
		{
			foreach ($giohang as $item) {
				$tongsoluong += $item['soluong'];
			}
		}
		else
		{
			$giohang = array();
		}
		$dl = array(
			'tongsoluong' => $tongsoluong,
			'giohang' => $giohang
		);
		$this->load->view('thanhtoan_view', $dl);
	}	

	public function donhang()
	{	
		//load menu
		$this->loadmenu();

		$user = $this->session->userdata('user');
		$diachi = $this->session->userdata('diachi'); 
		
		$this->load->model('Dondathang_model');
		$this->load->model('ChitietDDH_model');

		$giohang = $this->session->userdata('giohang');

		foreach ($user as $item) {
			$matv = $item['matv'];
		}
		if(!is_null($giohang) && !is_null($diachi))
		{
			$thanhtien = 0;
			
			foreach ($diachi as $item) {
				$diachigiao = $item['diachi'];
			}
			foreach ($giohang as $item) {
				$thanhtien += $item['soluong'] * $item['gia'];
			}
			
			$matinhtrang = 'chuaxacnhan';

			//thêm DDH vào CSDL
			
			$maddh = $this->Dondathang_model->them($matv, $diachigiao, $thanhtien);
			
			//thêm Chi tiết DDH vào CSDL
			foreach ($giohang as $item) {
				$dongia = $item['soluong'] * $item['gia'];
				$masp = $item['masp'];
				$soluong = $item['soluong'];
				$this->ChitietDDH_model->them($maddh, $dongia, $masp, $soluong, $matinhtrang);
			}

			//xóa session giỏ hàng + địa chỉ
			$this->session->unset_userdata('giohang');
			$this->session->unset_userdata('diachi');
		}

		$dsDDH = $this->ChitietDDH_model->layChiTietDDH($matv);
		$dsDDH = array('dsDDH' => $dsDDH);

		$this->load->view('donhang_view', $dsDDH);
	}

	public function huydondathang()
	{
		$matinhtrang = 'dahuy';
		$machitietddh = $this->input->post('machitietddh');

		$this->load->model('ChitietDDH_model');
		$rs = $this->ChitietDDH_model->capnhattinhtrang($machitietddh, $matinhtrang);
		echo json_encode($rs);
	}

	public function timkiem()
	{
		$strtimkiem = $this->input->post('strtimkiem');
		$this->load->model('Sanpham_model');

		$rs = $this->Sanpham_model->timkiem($strtimkiem);
		echo json_encode($rs);
	}

	public function chitietsanpham($bidanh)
	{
		$this->loadmenu();

		$this->load->model('Sanpham_model');
		$sanpham = $this->Sanpham_model->getSanPhamByBiDanh($bidanh);
		$masp = $sanpham[0]['masp'];
		
		$sanphamlienquan = $this->Sanpham_model->getSanPhamLienQuan($masp);

		$dulieu = array(
			'sanpham' => $sanpham,
			'sanphamlienquan' => $sanphamlienquan
		);
		$this->load->view('chitietsanpham_view', $dulieu);


	}

	public function quenmatkhau()
	{
		$email = $this->input->post('email');

		$this->load->model('Thanhvien_model');
		$kq = $this->Thanhvien_model->kiemtratontaiemail($email);
		echo json_encode($kq);

		if($kq)
		{
			$thanhvien = $this->Thanhvien_model->layTvByEmail($email);
			foreach ($thanhvien as $item) {
				$matkhau = $item['matkhau'];
				$taikhoan = $item['taikhoan'];
			}

			$noiDung = 'Tài khoản: '.$taikhoan.'<br>'.'Mật khẩu của bạn là: ' . $matkhau . '<br> Lần sau quên nữa thì khỏi lấy nha!!!';
			$mail = new PHPMailer(true);

			try {
			    //Server settings
			    $mail->SMTPDebug = 2;                                       // Enable verbose debug output
			    $mail->isSMTP();                                            // Set mailer to use SMTP
			    $mail->Host       = 'smtp.gmail.com';  // Specify main and backup SMTP servers
			    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
			    $mail->Username   = 'khoaanhdat1412@gmail.com';                     // SMTP username
			    $mail->Password   = 'ufuhexjkpwwjjnvf';                               // SMTP password
			    $mail->SMTPSecure = 'tls';                                  // Enable TLS encryption, `ssl` also accepted
			    $mail->Port       = 587;                                    // TCP port to connect to

			    //Recipients
			    $mail->CharSet = "UTF-8";
			    $mail->setFrom('khoa@KDT.com', 'Quản Trị Viên Website Bestcoffee');
			    $mail->addAddress($email, 'Khoa(tiêu đề)');     // Add a recipient
			    // $mail->addAddress('ellen@example.com');               // Name is optional
			    // $mail->addReplyTo('info@example.com', 'Information');
			    // $mail->addCC('cc@example.com');
			    // $mail->addBCC('bcc@example.com');

			    // // Attachments
			    // $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
			    // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

			    // Content
			    $mail->isHTML(true); 
			    $tieude = 'Lấy lại mật khẩu';                                 // Set email format to HTML
			    $mail->Subject = $tieude;
			    $mail->Body    = $noiDung;
			    //$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

			    $mail->send();
			    //echo 'Thư đã được gửi';
			} catch (Exception $e) {
			    //echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
			}
		}
	}

	public function laydiachi()
	{
		$hoten = $this->input->post('hoten');
		$dienthoai = $this->input->post('dienthoai');
		$diachi = $this->input->post('diachi');

		$thongtin = array(
			'hoten' => $hoten,
			'dienthoai' => $dienthoai,
			'diachi' => $diachi
		);

		$diachi = array();
		array_push($diachi, $thongtin);
		
		$this->session->set_userdata(array('diachi' => $diachi));
	}

	public function xoasessiondiachi()
	{
		$this->session->unset_userdata('diachi');
		echo json_encode($this->session->userdata('diachi'));
	}


	public function uploadAnh($file_dir, $file_name)
	{
		//xử lý lấy file ảnh
		$target_dir = $file_dir.'/';
		$target_file = $target_dir . basename($_FILES[$file_name]["name"]);
		$uploadOk = 1;
		$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
		// Check if image file is a actual image or fake image
		if(isset($_POST["submit"])) {
		    $check = getimagesize($_FILES[$file_name]["tmp_name"]);
		    if($check !== false) {
		        echo "File là một ảnh - " . $check["mime"] . ".";
		        $uploadOk = 1;
		    } else {
		        echo "File không phải là một ảnh.";
		        $uploadOk = 0;
		    }
		}
		// Check if file already exists
		// if (file_exists($target_file)) {
		//     return $target_file;
		// }
		// Check file size
		if ($_FILES[$file_name]["size"] > 50000000) {
		    echo "Kích thước file quá lớn.";
		    $uploadOk = 0;
		}
		// Allow certain file formats
		if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
		&& $imageFileType != "gif" ) {
		    echo "chỉ nhận file có đuôi JPG, JPEG, PNG & GIF.";
		    $uploadOk = 0;
		}
		// Check if $uploadOk is set to 0 by an error
		if ($uploadOk == 0) {
		    echo "Upload file thất bại.";
		    return '';
		// if everything is ok, try to upload file
		} else {
			move_uploaded_file($_FILES[$file_name]["tmp_name"], $target_file);
			return $target_file;
		}
	}

}

/* End of file User.php */
/* Location: ./application/controllers/User.php */