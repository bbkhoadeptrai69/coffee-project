<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Thanhvien_model extends CI_Model {

	public $variable;

	public function __construct()
	{
		parent::__construct();
		
	}

	public function layThanhVien()
	{
		$this->db->select('thanhvien.*, loaithanhvien.tenloaitv');
		$this->db->from('thanhvien');
		$this->db->join('loaithanhvien', 'loaithanhvien.id = thanhvien.maloaitv');
		$dl = $this->db->get();
		$dl = $dl->result_array();
		return $dl;
	}
	public function layQuyen($maloaitv)
	{
		$this->db->select('maquyen');
		$this->db->where('maloaithanhvien', $maloaitv);
		$quyen = $this->db->get('loaithanhvien_quyen');
		$quyen = $quyen->result_array();
		return $quyen;
	}

	public function themThanhVien($taikhoan, $matkhau, $hoten, $diachi, $email, $avatar, $sodienthoai, $maloaitv)
	{
		$dulieuthem = array(
			'taikhoan' => $taikhoan,
			'matkhau' => $matkhau,
			'hoten' => $hoten,
			'diachi' => $diachi, 
			'email' => $email,
			'avatar' => $avatar,
			'sodienthoai' => $sodienthoai,
			'maloaitv' => $maloaitv,
			'trangthai' => true
		);

		$this->db->insert('thanhvien', $dulieuthem);
		return $this->db->insert_id();
	}
	public function getTvById($matv)
	{
		$this->db->where('matv', $matv);
		$rs = $this->db->get('thanhvien');
		$rs = $rs->result_array();
		return $rs;
	}
	public function getTVByIdLoaiTV($maloaitv)
	{
		$this->db->where('maloaitv', $maloaitv);
		$dl = $this->db->get('thanhvien');
		$dl = $dl->result_array();
		return $dl;
	}
	public function xoaThanhVien($matv)
	{
		$this->db->where('matv', $matv);
		$this->db->delete('thanhvien');
		if($this->kiemTraTrong($matv))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	private function kiemTraTrong($matv)
	{
		$this->db->select('*');
		$this->db->where('matv', $matv);
		$dl = $this->db->get('thanhvien');
		$dl = $dl->result_array();
		if(is_null($dl))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	public function kiemtratontaiemail($email)
	{
		$this->db->select('*');
		$rs = $this->db->get('thanhvien');
		$rs = $rs->result_array();
		foreach ($rs as $item) {
			if($item['email'] == $email)
			{
				return true;
			}
		}
		return false;
	}
	public function layTvByEmail($email)
	{
		$this->db->where('email', $email);
		$rs = $this->db->get('thanhvien');
		$rs = $rs->result_array();
		return $rs;
	}

	public function laykhachhang()
	{
		$this->db->select('*');
		$this->db->where('maloaitv', 'khachhang');
		$rs = $this->db->get('thanhvien');
		$rs = $rs->result_array();
		return $rs;
	}

}

/* End of file Thanhvien_model.php */
/* Location: ./application/models/Thanhvien_model.php */