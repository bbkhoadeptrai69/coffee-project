<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dondathang_model extends CI_Model {

	public $variable;

	public function __construct()
	{
		parent::__construct();
		
	}

	public function them($matv, $diachigiao, $thanhtien)
	{
		$dlthem = array(
			'matv' =>$matv,
			'diachigiao' =>$diachigiao,
			'thanhtien' => $thanhtien
		);
		$this->db->insert('dondathang', $dlthem);
		return $this->db->insert_id();
	}
	public function get($matinhtrang)
	{
		$this->db->distinct();
		$this->db->select('dondathang.*, thanhvien.hoten');
		$this->db->from('dondathang');
		$this->db->join('chitietddh', 'chitietddh.maddh = dondathang.maddh');
		$this->db->join('thanhvien', 'thanhvien.matv = dondathang.matv');
		$this->db->where('chitietddh.matinhtrang', $matinhtrang);
		$rs = $this->db->get();
		$rs = $rs->result_array();
		return $rs;
	}

	public function layDDHByMatv($matv)
	{
		$this->db->where('matv', $matv);
		$this->db->get('dondathang');
		$rs = $rs->result_array();
		return $rs;
	}
}

/* End of file Dondathang_model.php */
/* Location: ./application/models/Dondathang_model.php */