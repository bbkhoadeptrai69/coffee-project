<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Loaithanhvien_model extends CI_Model {

	public $variable;

	public function __construct()
	{
		parent::__construct();
		
	}

	public function getLoaiThanhVien()
	{
		$this->db->select('*');
		$rs = $this->db->get('loaithanhvien');
		$rs = $rs->result_array();
		return $rs;
	}

	public function them($tenloaitv)
	{
		$dulieuthem = array(
			'tenloaitv' => $tenloaitv
		);
		$this->db->insert('loaithanhvien', $dulieuthem);
		return $this->db->insert_id();
	}
	public function luu($idcu, $idmoi, $tenloaitv)
	{
		$this->db->where('id', $idcu);
		$dulieuupdate = array(
			'id' => $idmoi,
			'tenloaitv' =>$tenloaitv
		);
		return 	$this->db->update('loaithanhvien', $dulieuupdate);
	}

	public function xoa($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('loaithanhvien');
	}

}

/* End of file Loaithanhvien_model.php */
/* Location: ./application/models/Loaithanhvien_model.php */