<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Homepage_model extends CI_Model {

	public $variable;

	public function __construct()
	{
		parent::__construct();
		
	}


	public function getSlide()
	{
		$this->db->select('giatrithuoctinh');
		$this->db->where('tenthuoctinh', 'slides_topbanner');
		$dl = $this->db->get('homepage');
		$dl = $dl->result_array();
		foreach ($dl as $item) {
			$rs = $item['giatrithuoctinh'];
		}
		return $rs;
	}

	public function updateSlide($dulieuupdate)
	{
		$dl = array(
					'tenthuoctinh' => 'slides_topbanner',
					'giatrithuoctinh' => $dulieuupdate
				);
		$this->db->where('tenthuoctinh', 'slides_topbanner');
		return $this->db->update('homepage', $dl);
	}

	public function getMenu()
	{
		$this->db->select('giatrithuoctinh');
		$this->db->where('tenthuoctinh', 'menu');
		$dl = $this->db->get('homepage');
		$dl = $dl->result_array();
		foreach ($dl as $item) {
			$rs = $item['giatrithuoctinh'];
		}
		return $rs;
	}

	public function getItemMenu()
	{
		$this->db->select('giatrithuoctinh');
		$this->db->where('tenthuoctinh', 'menu');
		$dl = $this->db->get('homepage');
		$dl = $dl->result_array();
		foreach ($dl as $item) {
			$rs = $item['giatrithuoctinh'];
		}
		$rs = json_decode($rs, true);
		if(!is_null($rs))
		{
			foreach ($rs as $item) {
				$rs = $item['item'];
			}
		}
		
		return $rs;
	}

	public function updateMenu($dulieuupdate)
	{
		$mangdulieu = array(
			'giatrithuoctinh' => $dulieuupdate
		);
		$this->db->where('tenthuoctinh', 'menu');
		return $this->db->update('homepage', $mangdulieu);
	}

	public function getFooter()
	{
		$this->db->select('giatrithuoctinh');
		$this->db->where('tenthuoctinh', 'footer');
		$dl = $this->db->get('homepage');
		$dl = $dl->result_array();
		foreach ($dl as $item) {
			$rs = $item['giatrithuoctinh'];
		}
		return $rs;
	}

	public function updateFooter($dulieuupdate)
	{
		$mangdulieu = array('giatrithuoctinh' => $dulieuupdate);
		$this->db->where('tenthuoctinh', 'footer');
		return $this->db->update('homepage', $mangdulieu);
	}
}

/* End of file Homepage_model.php */
/* Location: ./application/models/Homepage_model.php */