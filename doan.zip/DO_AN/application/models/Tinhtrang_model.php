<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tinhtrang_model extends CI_Model {

	public $variable;

	public function __construct()
	{
		parent::__construct();
		
	}

	public function get()
	{
		$this->db->select('*');
		$rs = $this->db->get('tinhtrang');
		$rs = $rs->result_array();
		return $rs;
	}

}

/* End of file Tinhtrang_model.php */
/* Location: ./application/models/Tinhtrang_model.php */