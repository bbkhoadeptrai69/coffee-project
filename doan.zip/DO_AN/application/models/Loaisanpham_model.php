<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Loaisanpham_model extends CI_Model {

	public $variable;

	public function __construct()
	{
		parent::__construct();
		
	}
	public function getLoaiSanPham()
	{
		$this->db->select('*');
		$rs = $this->db->get('loaisanpham');
		$rs = $rs->result_array();
		return $rs;
	}

	public function getLoaiSanPhamById($id)
	{
		$this->db->select('*');
		$this->db->where('id', $id);
		$dl = $this->db->get('loaisanpham');
		$dl = $dl->result_array();
		return $dl;
	}

	public function them($tenloaisp)
	{
		$dulieuthem = array(
			'tenloaisp' => $tenloaisp
		);
		$this->db->insert('loaisanpham', $dulieuthem);
		return $this->db->insert_id();
	}

	public function luu($id, $tenloaisp)
	{
		$this->db->where('id', $id);
		$dulieuupdate = array(
			'id' => $id,
			'tenloaisp' =>$tenloaisp
		);
		return 	$this->db->update('loaisanpham', $dulieuupdate);
	}
	public function xoa($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('loaisanpham');
	}

}

/* End of file Loaisanpham_model.php */
/* Location: ./application/models/Loaisanpham_model.php */