<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ChitietDDH_model extends CI_Model {

	public $variable;

	public function __construct()
	{
		parent::__construct();
		
	}
	public function them($maddh, $dongia, $masp, $soluong, $matinhtrang)
	{
		$dlthem = array(
			'maddh' => $maddh,
			'dongia' => $dongia,
			'masp' => $masp,
			'soluong' => $soluong,
			'matinhtrang' =>$matinhtrang
		);
		$this->db->insert('chitietddh', $dlthem);
		return $this->db->insert_id();
	}
	public function layChiTietDDH($matv)
	{
		$this->db->select('dondathang.*, chitietddh.*, sanpham.*, tinhtrang.tentinhtrang');
		$this->db->from('dondathang');
		$this->db->join('chitietddh', 'chitietddh.maddh = dondathang.maddh');
		$this->db->join('sanpham', 'sanpham.masp = chitietddh.masp');
		$this->db->join('tinhtrang', 'tinhtrang.matinhtrang = chitietddh.matinhtrang');
		$this->db->where('matv', $matv);
		$rs = $this->db->get();
		$rs = $rs->result_array();
		return $rs;
	}
	public function layChiTietDDHByMaDDH($maddh)
	{
		$this->db->select('chitietddh.*, sanpham.*, tinhtrang.*');
		$this->db->from('chitietddh');
		$this->db->join('sanpham', 'sanpham.masp = chitietddh.masp');
		$this->db->join('tinhtrang', 'tinhtrang.matinhtrang = chitietddh.matinhtrang');
		$this->db->where('chitietddh.maddh', $maddh);
		$rs = $this->db->get();
		$rs = $rs->result_array();
		return $rs;
	}

	public function capnhattinhtrang($machitietddh, $matinhtrang)
	{
		$this->db->where('machitietddh', $machitietddh);
		$dlcapnhat = array(
			'matinhtrang' => $matinhtrang
		);
		return $this->db->update('chitietddh', $dlcapnhat);
	}

	public function layChiTietDDHByMatinhtrang($matinhtrang)
	{
		$this->db->select('chitietddh.*, dondathang.*');
		$this->db->from('chitietddh');
		$this->db->join('dondathang', 'dondathang.maddh = chitietddh.maddh');
		$this->db->where('matinhtrang', $matinhtrang);
		$rs = $this->db->get();
		$rs = $rs->result_array();
		return $rs;
	}

	public function thongkedonhang()
	{
		$this->db->select('chitietddh.*, dondathang.*');
		$this->db->from('chitietddh');
		$this->db->join('dondathang', 'dondathang.maddh = chitietddh.maddh');
		$where = "matinhtrang != 'chuaxacnhan' and matinhtrang != 'dahuy'";
		$this->db->where($where);
		$rs = $this->db->get();
		$rs = $rs->result_array();
		return $rs;
	}

}

/* End of file ChitietDDH_model.php */
/* Location: ./application/models/ChitietDDH_model.php */