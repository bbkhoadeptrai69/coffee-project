<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Sanpham_model extends CI_Model {

	public $variable;

	public function __construct()
	{
		parent::__construct();
		
	}

	public function timkiem($strtimkiem)
	{
		$this->db->select('sanpham.*, loaisanpham.*');
		$this->db->from('sanpham');
		$this->db->join('loaisanpham', 'loaisanpham.id = sanpham.maloaisp');
		$where = "loaisanpham.tenloaisp LIKE '%".$strtimkiem."%' OR sanpham.tensp LIKE '%".$strtimkiem."%'";
		$this->db->where($where);
		$rs = $this->db->get();
		$rs = $rs->result_array();
		return $rs;
	}

	public function getSanPham()
	{
		$this->db->select('sanpham.*, loaisanpham.tenloaisp');
		$this->db->from('sanpham');
		$this->db->join('loaisanpham', 'loaisanpham.id = sanpham.maloaisp');
		$this->db->where('daxoa', '0');
		$dl = $this->db->get();
		$dl = $dl->result_array();
		return $dl;
	}
	public function getsanphamphantrang($pagesize, $pageindex)
	{
		$batdau = ($pageindex - 1) * $pagesize;
		//echo json_encode('bd: '.$batdau); die();
		$this->db->select('sanpham.*, loaisanpham.tenloaisp');
		$this->db->from('sanpham');
		$this->db->join('loaisanpham', 'loaisanpham.id = sanpham.maloaisp');
		$this->db->where('daxoa', '0');
		$dl = $this->db->get('',$pagesize, $batdau);
		$dl = $dl->result_array();
		return $dl;
	}
	public function getSanPhamById($masp)
	{
		$this->db->where('masp', $masp);
		$dl = $this->db->get('sanpham');
		$dl = $dl->result_array();
		return $dl;
	}

	public function getSanPhamByBiDanh($bidanh)
	{
		$this->db->where('bidanh', $bidanh);
		$dl = $this->db->get('sanpham');
		$dl = $dl->result_array();
		return $dl;
	}

	public function getSanPhamLienQuan($masp)
	{
		$sanpham = $this->getSanPhamById($masp);
		$maloaisp = $sanpham[0]['maloaisp'];
		$where = "maloaisp = ".$maloaisp." and masp != ".$masp;
		$this->db->where($where);
		$rs = $this->db->get('sanpham');
		$rs = $rs->result_array();
		return $rs;
	}

	public function getTatCaSanPhamNoiBat()
	{
		$this->db->select('sanpham.*, loaisanpham.tenloaisp');
		$this->db->from('sanpham');
		$this->db->join('loaisanpham', 'loaisanpham.id = sanpham.maloaisp');
		$this->db->where('daxoa', '0');
		$this->db->where('noibat', '1');
		$dl = $this->db->get();
		$dl = $dl->result_array();
		return $dl;
	}
	public function getSanPhamNoiBat($soluong)
	{
		$this->db->select('sanpham.*, loaisanpham.tenloaisp');
		$this->db->join('loaisanpham', 'loaisanpham.id = sanpham.maloaisp');
		$this->db->where('daxoa', '0');
		$this->db->where('noibat', '1');
		$dl = $this->db->get('sanpham',$soluong);
		$dl = $dl->result_array();
		return $dl;
	}

	public function getSPByIdLoaiSP($maloaisp)
	{
		$this->db->where('maloaisp', $maloaisp);
		$dl = $this->db->get('sanpham');
		$dl = $dl->result_array();
		return $dl;
	}
	public function getSPByIdLoaiSPphantrang($maloaisp, $pagesize, $pageindex)
	{
		$batdau = ($pageindex - 1) * $pagesize;
		
		$this->db->where('maloaisp', $maloaisp);
		$dl = $this->db->get('sanpham');
		$dl = $dl->result_array($pagesize, $batdau);
		return $dl;
	}

	public function themSanPham($tensp, $gia, $mota, $hinhanh, $maloaisp, $noibat, $soluongton)
	{
		$bidanh = mb_strtolower($tensp, 'UTF-8');
		
		$bidanh = $this->boDau($bidanh);
		
		$bidanh = str_replace(' ', '-', $bidanh);
		
		$mangdulieu = array(
			'tensp' => $tensp,
			'gia' => $gia, 
			'mota' =>$mota,
			'hinhanh' => $hinhanh,
			'maloaisp' => $maloaisp,
			'bidanh' => $bidanh, 
			'noibat' => $noibat,
			'soluongton' => $soluongton
		);

		$this->db->insert('sanpham', $mangdulieu);
		return $this->db->insert_id();
		//echo json_encode($mangdulieu); die();
	}

	public function xoaSanPham($masp)
	{
		$this->db->where('masp', $masp);
		$dulieuupdate = array('daxoa' => true);
		return $this->db->update('sanpham', $dulieuupdate);

	}
	
	public function capnhatsolanmuasp($masp, $solanmua)
	{
		$this->db->where('masp', $masp);
		$dulieucapnhat = array(
			'solanmua' =>$solanmua
		);
		return $this->db->update('sanpham', $dulieucapnhat);
	}

	private function boDau($str)
	{
	    if(!$str) return false;
	    $unicode = array(
	      'a'=>'á|à|ả|ã|ạ|ă|ắ|ặ|ằ|ẳ|ẵ|â|ấ|ầ|ẩ|ẫ|ậ',
	      'd'=>'đ',
	      'e'=>'é|è|ẻ|ẽ|ẹ|ê|ế|ề|ể|ễ|ệ',
	      'i'=>'í|ì|ỉ|ĩ|ị',
	      'o'=>'ó|ò|ỏ|õ|ọ|ô|ố|ồ|ổ|ỗ|ộ|ơ|ớ|ờ|ở|ỡ|ợ',
	      'u'=>'ú|ù|ủ|ũ|ụ|ư|ứ|ừ|ử|ữ|ự',
	      'y'=>'ý|ỳ|ỷ|ỹ|ỵ',
	   );
		foreach($unicode as $nonUnicode=>$uni) $str = preg_replace("/($uni)/i",$nonUnicode,$str);
		return $str;
	}

}

/* End of file Sanpham_model.php */
/* Location: ./application/models/Sanpham_model.php */