<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Thông tin giao hàng</title>
	<?php include 'addLib.php' ?>
</head>
<body>
	<div class="header">
		<div class="container">
			<div class="row">
				<div class="col-2"><div class="logo"></div></div>
				<div class="col-10">
					<div class="tientrinh">
						<div class="so1 active">1</div>
						<div class="so2">2</div>
						<div class="so3">3</div>
						<div class="thanh1"></div>
						<div class="thanh2"></div>
						<div class="dn text-muted">Đăng Nhập</div>
						<div class="dc text-muted">Địa Chỉ Giao Hàng</div>
						<div class="tt text-muted">Thanh Toán & Đặt Mua</div>
					</div>
				</div>
			</div>
		</div>
	</div> <!-- end header -->
	<?php if (is_null($this->session->userdata('user'))): ?>
		<div class="khachhang-dangnhap mt-5">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<p class="font-weight-bold">1. Khách hàng mới / Đăng nhập</p>
					</div>
					<div class="col-8">
						<div class="row thongtinkhachhang">
							<div class="col-4 trai">
								<ul>
									<li data-id="#dangnhap" class="text-center dangnhap-thanhtoan active">
										<h6 class="text-uppercase">đăng nhập</h6>
										<p>Đã là thành viên</p>
									</li>
									<li data-id="#dangky" class="text-center dangky-thanhtoan">
										<h6 class="text-uppercase">Tạo tài khoản</h6>
										<p>Dành cho khách hàng mới</p>
									</li>
								</ul>
							</div>
							<div class="col-8 phai">
								<div id="dangnhap" class="user">
									<fieldset class="form-group">
										<label class="font-weight-bold" for="">Username</label>
										<input type="text" class="username form-control" placeholder="nhập username">
										<div class="text-danger font-weight-bold validationUsername valid"></div>
									</fieldset>
									<fieldset class="form-group">
										<label class="font-weight-bold" for="">Password</label>
										<input type="password" class="password form-control" placeholder="nhập password">
										<div class="text-danger font-weight-bold validationPassword valid"></div>
									</fieldset>
									<fieldset class="form-group">
										<p>Quên mật khẩu? Khôi phục mật khẩu <a class="btnQuenmatkhau" href="">tại đây</a></p>
									</fieldset>
									<div class="form-group col-12">
								      <div class="text-danger font-weight-bold thongbaouser"></div>
								    </div>
									<fieldset class="form-group">
										<button class="form-control btn btn-info mb-3 btnDangNhap">Đăng nhập</button>
									</fieldset>
								</div>
								<div id="dangky" class="d-none user">
									<fieldset class="form-group">
										<label>Họ tên</label>
										<input type="text" class="form-control hoten" placeholder="nhập họ tên">
										<div class="text-danger validHoTen tb"></div>
									</fieldset>
									<fieldset class="form-group">
										<label>Tài khoản</label>
										<input type="text" class="form-control taikhoan" placeholder="nhập tài khoản">
										<div class="text-danger validTaiKhoan tb"></div>
									</fieldset>
									<fieldset class="form-group">
										<label>Mật khẩu</label>
										<input type="password" class="form-control matkhau" placeholder="nhập mật khẩu">
										<div class="text-danger validMatKhau tb"></div>
									</fieldset>
									<fieldset class="form-group">
										<label>Nhập lại mật khẩu</label>
										<input type="password" class="form-control nhaplai" placeholder="nhập lại mật khẩu">
										<div class="text-danger validNhapLai tb"></div>
									</fieldset>
									<fieldset class="form-group">
										<label>Địa chỉ</label>
										<input type="text" class="form-control diachi" placeholder="nhập địa chỉ">
									</fieldset>
									<fieldset class="form-group">
										<label>Email</label>
										<input type="email" class="form-control email" placeholder="nhập email">
										<div class="validEmail"></div>
									</fieldset>
									<fieldset class="form-group">
										<label>Avatar</label>
										<input id="avatar" type="file" class="form-control-file">
										<div class="validAvatar"></div>
									</fieldset>
									<fieldset class="form-group">
										<label>Số điện thoại</label>
										<input type="number" class="form-control sodienthoai" placeholder="nhập số điện thoại">
									</fieldset>
									<fieldset class="form-group">
										<button class="form-control btn btn-warning btnDangKy">Đăng ký</button>
									</fieldset>
								</div>
							</div>
						</div>
					</div>
					<div class="col-4 ">
						<div class="thongtindonhang">
							<div class="donhang">
								<p class="float-left">Đơn hàng (<?php echo $tongsoluong ?> sản phẩm)</p>
								<a href="<?php echo base_url() ?>User/giohang" class="btn btn-outline-warning btn-sm float-right">Sửa</a>
								<div class="clearfix"></div>
								<hr>
							</div>
							<div class="danhsachsanpham">
								<?php $tongtien = 0; ?>
								<?php foreach ($giohang as $item): ?>
									<?php $tongtien += $item['gia'] * $item['soluong'] ?>
									<div class="motsanpham mt-2">
										<p class="float-left"><?= $item['soluong'] ?> x <a href=""><?= $item['tensp'] ?></a></p>
										<p class="gia float-right"><?php  echo number_format($item['gia']) ?> đ</p>
									</div>
								<?php endforeach ?>
							</div>
							<div class="thanhtien mt-3">
								<strong class="float-left">Thành tiền: </strong>
								<h5 class="float-right text-danger"><?php echo number_format($tongtien) ?> đ</h5>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div> <!-- end khachhang-dangnhap -->
	<?php else: ?>
		<div class="diachigiaohang mt-5">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<p class="font-weight-bold">2. Địa chỉ giao hàng</p>
					</div>
					<div class="col-12">
						<p>Chọn địa chỉ giao hàng có sẵn bên dưới:</p>
					</div>
					
						<?php foreach ($this->session->userdata('user') as $item): ?>
							<?php if ($item['diachi']!= ''): ?>
								<div class="col-6 thongtin">
									<strong class="tenkhachhang"><?= $item['hoten'] ?></strong>
									<p>Địa chỉ:<span class="diachi"> <?= $item['diachi'] ?></span></p>
									Điện thoại: <span class="dienthoai"><?= $item['sodienthoai'] ?></span>
									<br>
									<button class="btn btn-primary btn-sm mt-2 btnGiaodiachi">Giao đến địa chỉ này</button>
									<button class="btn btn-outline-dark btn-sm mt-2">Sửa</button>
									<button class="btn btn-outline-dark btn-sm mt-2">Xóa</button>
								</div>
							<?php else: ?>
								<div class="col-6 thongtin">Bạn không có địa chỉ nào. Xin vui lòng cập nhật địa chỉ hoặc thêm địa chỉ trực tiếp bên dưới.</div>
							<?php endif ?>
							
						<?php endforeach ?>
					
					<div class="col-12 mt-5 ">
						<p>Bạn muốn giao hàng đến địa chỉ khác? <a href="" class="btnThemdiachimoi">Thêm địa chỉ giao hàng mới</a></p>
						<div style="display: none" class="row diachigiaohangmoi justify-content-center" >
							<div class="col-7 mt-4">
								<div class="form-group row">
								    <label class="col-5 col-form-label">Họ tên</label>
								    <div class="col-7">
								      <input type="text" class="form-control hoten" placeholder="nhập họ tên">
								      <div class="text-danger valid validationHoTen"></div>
								    </div>
							    </div>
							    <div class="form-group row">
								    <label class="col-5 col-form-label">Điện thoại</label>
								    <div class="col-7">
								      <input type="number" class="form-control dienthoai" placeholder="nhập điện thoại">
								      <div class="text-danger valid validationDienThoai"></div>
								    </div>
							    </div>
							    <div class="form-group row">
								    <label class="col-5 col-form-label">Địa chỉ</label>
								    <div class="col-7">
								      <input type="text" class="form-control diachi" placeholder="nhập địa chỉ">
								      <div class="text-danger valid validationDiaChi"></div>
								    </div>
							    </div>
							    <div class="form-group row mt-5">
								    <div class="col-6">
								      <button class="text-center btn btn-outline-secondary form-control btnHuybodiachimoi">Hủy bỏ</button>
								    </div>
								    <div class="col-6">
								      <button class="text-center btn btn-info form-control btnGiaodiachimoi">Giao đến địa chỉ này</button>
								    </div>
							    </div>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>
	<?php endif ?>
	<?php if ($this->session->has_userdata('diachi')): ?>
		<div class="thanhtoan-datmua mt-5">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<p class="font-weight-bold">Chọn hình thức thanh toán</p>
					</div>
					<div class="col-6">
						<div class="hinhthucgiaohang">
							<div class="custom-control custom-radio">
							  <input type="radio" id="customRadio1" name="customRadio" class="custom-control-input" checked>
							  <label class="custom-control-label" for="customRadio1">Thanh toán tiền mặt khi nhận hàng</label>
							</div>
						</div>
					</div>
					<div class="col-6">
						<div class="diachigiaohangthanhtoan">
							<div>
								<p class="float-left">Địa chỉ giao hàng</p>
								<button class="btn btn-outline-warning btn-sm float-right btnSuadiachi">Sửa</button>
								<div class="clearfix"></div>
								<hr>
							</div>
							<div class="thongtinkhachhangthanhtoan">
								<?php foreach ($this->session->userdata('diachi') as $item): ?>
									<strong class="tenkhachhang"><?= $item['hoten'] ?></strong>
									<p>Địa chỉ: <span class="diachi"><?= $item['diachi'] ?></span></p>
									<p>Điện thoại: <span class="dienthoai"> <?= $item['dienthoai'] ?></span></p>
								<?php endforeach ?>
							</div>
						</div>

						<div class="thongtindonhang">
							<div class="donhang">
								<p class="float-left">Đơn hàng (<?php echo $tongsoluong ?> sản phẩm)</p>
								<a href="<?php echo base_url() ?>User/giohang" class="btn btn-outline-warning btn-sm float-right">Sửa</a>
								<div class="clearfix"></div>
								<hr>
							</div>
							<div class="danhsachsanpham">
								<?php $tongtien = 0; ?>
								<?php foreach ($giohang as $item): ?>
									<?php $tongtien += $item['gia'] * $item['soluong'] ?>
									<div class="motsanpham mt-2">
										<p class="float-left"><?= $item['soluong'] ?> x <a href=""><?= $item['tensp'] ?></a></p>
										<p class="gia float-right"><?php  echo number_format($item['gia']) ?> đ</p>
									</div>
								<?php endforeach ?>
							</div>
							<div class="thanhtien mt-3">
								<strong class="float-left">Thành tiền: </strong>
								<h5 class="float-right text-danger"><?php echo number_format($tongtien) ?> đ</h5>
							</div>
						</div>
					</div>
					<div class="col-12">
						<div class="col-4">
							<button class="form-control btn btn-danger btn-lg text-uppercase text-center btnDatMua">đặt mua</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	<?php endif ?>	

	<div style="display: none" class="quenmatkhau thanhtoan">
		<div class="text-success thanhcong font-weight-bold"></div>
		<div class="form-group row justify-content-center mt-4">
			<div class="nutx">X</div>
			<label class="col-3" for="">Nhập email đăng ký</label>
			<div class="col-9">
				<input type="email" class="form-control emaillaylaimk">
				<div class="valid vlemail text-danger"></div>
			</div>
			<br>
			<button class="btnGuiemail btn btn-outline-danger">Gửi</button>
		</div>
	</div>

	<?php include 'footer.php' ?>

	<script type="text/javascript">
		$(document).ready(function() {
			if($('div').hasClass('diachigiaohang')){
				$('.so2').addClass('active');
				$('.thanh1').addClass('active');
			}
			if($('div').hasClass('thanhtoan-datmua')){
				$('.so3').addClass('active');
				$('.thanh2').addClass('active');
				$('.diachigiaohang').addClass('d-none');
			}

			//xử lý sự kiện đăng nhập khi đang ở trang thanh toán
			$('.khachhang-dangnhap #dangnhap .btnDangNhap').click(function(event) {
				$('.valid').text('');
				if($('.username').val() == '')
				{
					$('#dangnhap .validationUsername').text('Vui lòng không bỏ trống ô này');
					$('#dangnhap .username').focus();
				}
				else if($('.password').val() == '')
				{
					$('#dangnhap .validationPassword').text('Vui lòng không bỏ trống ô này');
					$('#dangnhap .password').focus();
				}

				else
				{
					$.ajax({
						url: '/DO_AN/User/dangNhap',
						type: 'POST',
						dataType: 'json',
						data: {
							username: $('.username').val(),
							password: $('.password').val()
						},
					})
					.done(function() {
						console.log("success");
					})
					.fail(function() {
						console.log("error");
					})
					.always(function(res) {
						console.log("complete");
						if(res == -1){
							$('#dangnhap .thongbaouser').text('Username này không tồn tại.');
							$('.username').select().focus();
						}
						else if(res == 0){
							$('#dangnhap .thongbaouser').text('Sai mật khẩu');
							$('.password').select().focus();	
						}
						else if(res == 1){
							//đăng nhập thành công
							location.reload();
						}
					});
				}		
			});	

			$('.khachhang-dangnhap #dangky .btnDangKy').click(function(event) {
				$('.tb').text('');
				if($('.hoten').val() == ''){
					$('.validHoTen').text('Vui lòng không bỏ trống họ tên');
					$('.hoten').focus();
				}
				else if($('.taikhoan').val() == ''){
					$('.validTaiKhoan').text('Vui lòng không bỏ trống tài khoản');
					$('.taikhoan').focus();
				}
				else if($('.matkhau').val() == ''){
					$('.validMatKhau').text('Vui lòng không bỏ trống mật khẩu');
					$('.matkhau').focus();
				}
				else if($('.nhaplai').val() == ''){
					$('.validNhapLai').text('Vui lòng nhập lại mật khẩu');
					$('.nhaplai').focus();
				}
				else if($('.nhaplai').val() != $('.matkhau').val()){
					$('.validNhapLai').text('Nhập lại mật khẩu không khớp');
					$('.nhaplai').focus();
				}
				else{
					var check = true;
					var form_data = new FormData();
					if($('#avatar').val() != '')
					{
						var file_data = $('#avatar').prop('files')[0];
						var type = file_data.type;
	        			var match = ["image/gif", "image/png", "image/jpg", "image/jpeg"];

	        			if (type == match[0] || type == match[1] || type == match[2] || type == match[3]) {
	        				check = true;
	        				form_data.append('avatar', file_data);
	        			}
	        			else{
	        				$('.validAvatar').text('Ảnh không đúng định dạng');
	        				check = false;
	        			}
					}
					
					if(check)
					{
						form_data.append('hoten', $('.hoten').val());
						form_data.append('taikhoan', $('.taikhoan').val());
						form_data.append('matkhau', $('.matkhau').val());
						form_data.append('diachi', $('.diachi').val());
						form_data.append('email', $('.email').val());
						form_data.append('sodienthoai', $('.sodienthoai').val());


						$.ajax({
							url: '<?php echo base_url() ?>User/themThanhVien',
							type: 'POST',
							dataType: 'json',
							cache: false,
			                contentType: false,
			                processData: false,
							data: form_data
						})
						.done(function() {
							console.log("success");
						})
						.fail(function() {
							console.log("error");
						})
						.always(function(res) {
							console.log("complete");
							if(res)
							{
								$('input').val('');
								$.ajax({
									url: '<?php echo base_url() ?>User/tudongdangnhap',
									type: 'POST',
									dataType: 'json',
									data: {matv: res},
								})
								.done(function() {
									console.log("success");
								})
								.fail(function() {
									console.log("error");
								})
								.always(function() {
									console.log("complete");
									location.reload();
									$('body').animate({scrollTop: 0}, 300);
								});
								
							}
							else
							{

							}
						});
					}
				}
			});

			$('.diachigiaohang .btnThemdiachimoi').click(function(event) {
				$('.diachigiaohangmoi').slideToggle('slow');
				return false;
			});

			$('.diachigiaohang .btnHuybodiachimoi').click(function(event) {
				$('.diachigiaohangmoi').slideUp('slow');
			});

			$('.diachigiaohang .btnGiaodiachimoi').click(function(event) {
				$('.valid').text('');
				if($('input.hoten').val() == '')
				{
					$('input.hoten').focus();
					$('.validationHoTen').text('Không bỏ trống họ tên');
				}
				else if($('input.dienthoai').val() == '')
				{
					$('input.dienthoai').focus();
					$('.validationDienThoai').text('Không bỏ trống điện thoại');
				}
				else if($('input.diachi').val() == '')
				{
					$('input.diachi').focus();
					$('.validationDiaChi').text('Không bỏ trống địa chỉ');
				}
				else
				{
					$.ajax({
						url: 'laydiachi',
						type: 'POST',
						dataType: 'json',
						data: {
							hoten: $('input.hoten').val(),
							dienthoai: $('input.dienthoai').val(),
							diachi: $('input.diachi').val()
						},
					})
					.done(function() {
						console.log("success");
					})
					.fail(function() {
						console.log("error");
					})
					.always(function() {
						console.log("complete");
						location.reload();
					});
				}
			});

			$('.diachigiaohang .btnGiaodiachi').click(function(event) {
				$.ajax({
					url: 'laydiachi',
					type: 'POST',
					dataType: 'json',
					data: {
						hoten: $('.tenkhachhang').text(),
						dienthoai: $('.dienthoai').text(),
						diachi: $('.diachi').text()
					},
				})
				.done(function() {
					console.log("success");
				})
				.fail(function() {
					console.log("error");
				})
				.always(function() {
					console.log("complete");
					location.reload();
				});
			});
			$('.diachigiaohangthanhtoan .btnSuadiachi').click(function(event) {
				$.ajax({
					url: 'xoasessiondiachi',
					type: 'POST',
					dataType: 'json'
				})
				.done(function() {
					console.log("success");
				})
				.fail(function() {
					console.log("error");
				})
				.always(function() {
					console.log("complete");
					location.reload();
				});
			});

			$('.thanhtoan-datmua .btnDatMua').click(function(event) {
				console.log("ok");
				$.ajax({
					url: 'donhang',
					type: 'POST',
					dataType: 'json'
				})
				.done(function() {
					console.log("success");
				})
				.fail(function() {
					console.log("error");
				})
				.always(function() {
					console.log("complete");
					$(location).attr('href', '<?php echo base_url() ?>User/donhang');
				});
				
			});

			$('.btnQuenmatkhau').click(function(event) {
				event.preventDefault();
				$('.quenmatkhau').slideDown('fast');
			});
			$('.nutx').click(function(event) {
				$('.quenmatkhau').slideUp('fast');
			});

			$('.quenmatkhau .btnGuiemail').click(function(event) {
				$('.valid').text('');
				if($('.emaillaylaimk').val() == '')
				{
					$('.vlemail').text('không bỏ trống email');
					$('.emaillaylaimk').focus();
				}

				else
				{
					$.ajax({
						url: '<?php echo base_url() ?>User/quenmatkhau',
						type: 'POST',
						dataType: 'json',
						data: {
							email: $('.emaillaylaimk').val()
						},
					})
					.done(function() {
						console.log("success");
					})
					.fail(function() {
						console.log("error");
					})
					.always(function(res) {
						console.log("complete");
						if (res) 
						{
							$('.emaillaylaimk').val('');
							$('.thanhcong').text('Chúng tôi đã gửi mật khẩu cho bạn. Kiểm tra email ngay');
						}
						else
						{
							$('.vlemail').text('Email này không tồn tại. Xin kiểm tra lại');
							$('.emaillaylaimk').focus().select();
						}
					});
					
				}
			});
		});
	</script>
</body>
</html>