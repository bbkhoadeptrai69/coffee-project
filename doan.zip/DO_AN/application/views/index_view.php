<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Coffee Daklak - Trang Chủ</title>
	<!-- <?php //include 'addLib.php' ?> -->
</head>
<body>
	<?php include 'dangnhap.php' ?>	

	
	<div class="slide-top">
		<div class="bd-example">
		  <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel" data-interval="7000">
		    <ol class="carousel-indicators">
		      <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
		      <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
		    </ol>
		    <div class="carousel-inner">
		    	<?php $i = 1; ?>
				<?php foreach ($slide as $item): ?>
					<?php if($i == 1): ?>
						<div class="carousel-item active anh">
					        <img src="<?= $item['anh'] ?>" class="d-block w-100" alt="...">
					        <div class="carousel-caption d-none d-md-block noidung">
					            <h2 class="text-uppercase font-weight-bold layer1"><?= $item['tieude1'] ?></h2> 
								<h2 class="text-uppercase font-weight-bold layer2"><?= $item['tieude2'] ?></h2>
					          	<p class="text-muted layer3"><?= $item['mota'] ?></p>
					        </div>
				      	</div>
				    <?php else: ?>
				    	<div class="carousel-item anh">
					        <img src="<?= $item['anh'] ?>" class="d-block w-100" alt="...">
					        <div class="carousel-caption d-none d-md-block noidung">
					            <h2 class="text-uppercase font-weight-bold layer1"><?= $item['tieude1'] ?></h2> 
								<h2 class="text-uppercase font-weight-bold layer2"><?= $item['tieude2'] ?></h2>
					          	<p class="text-muted layer3"><?= $item['mota'] ?></p>
					        </div>
				      	</div>	
					<?php endif ?>
			      	<?php $i++; ?>
		      	<?php endforeach ?>

		    </div>
		    <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
		      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
		      <span class="sr-only">Previous</span>
		    </a>
		    <a class="carousel-control-next btnnext" href="#carouselExampleCaptions" role="button" data-slide="next">
		      <span class="carousel-control-next-icon" aria-hidden="true"></span>
		      <span class="sr-only">Next</span>
		    </a>
		  </div>
		</div>
	</div> <!-- end slide-top -->


	<div class="product-menu mt-5 pt-5">
		<div class="container">
			<div class="row">
				<div class="col-sm-6 wow rollIn" data-wow-duration="1s" data-wow-offset="150">
					<h2 class="text-uppercase">sản phẩm</h2>
					<div class="vachngan"></div>
				</div>
				<div class="col-sm-6 text-right">
					<div class="thongbaoquasoluong">
						Bạn đã chọn tối đa số lượng của sản phẩm này.
					</div>
					<a href="<?php echo base_url() ?>User/menu" class="btn btn-secondary text-uppercase mt-1 btnxemthem wow bounceInRight" data-wow-duration="1s" data-wow-delay="0.5s" data-wow-offset="150">
						<span class="layer1">xem tất cả sản phẩm</span>
						<span class="layer2"></span>
						<span class="layer3"></span>
					</a>
				</div>
			</div>
			<div class="row mt-5 products">
				<?php foreach ($dsspnoibat as $item): ?>
					<div class="col-sm-6 col-md-4 pt-3 motsanpham" data-wow-offset="20">
						<a href="<?php echo base_url() ?>User/chitietsanpham/<?php echo $item['bidanh'] ?>" class="anhsanpham">
							<img src="<?= $item['hinhanh'] ?>" class="img-fluid rounded" alt="">
							<div class="nen rounded"></div>
							<div class="thanh1"></div>
							<div class="thanh2"></div>
						</a>
						<a href="" class="tensanpham text-uppercase"><?= $item['tensp'] ?></a>
						<h4 class="giatien mt-4 mb-3 text-orange"><?= number_format($item['gia']) ?> đ</h4>
						
						<a href="<?php echo base_url() ?>User/chitietsanpham/<?php echo $item['masp'] ?>" target="_blank" class="btn btn-primary text-uppercase mr-3 mt-4 nut1">
							<span class="layer1">mua ngay</span>
							<span class="layer2"></span>
							<span class="layer3"></span>
						</a>
						<button data-id="<?= $item['masp'] ?>" type="button" class="btn btn-outline-primary text-uppercase mt-4 nut2 themgiohang">
							<span class="layer1"><i class="fas fa-cart-plus"></i> Thêm vào giỏ hàng</span>
							<span class="layer2"></span>
						</button>
					</div> <!-- end motsanpham -->
					
				<?php endforeach ?>
			</div>
		</div> <!-- end container -->
	</div> <!-- end product-menu -->

	<div class="blog mt-5 pt-5 pb-5">
		<div class="container">
			<div class="row">
				<div class="col-sm-6">
					<h2 class="text-uppercase">tin tức</h2>
					<div class="vachngan"></div>
				</div>
				<div class="col-sm-6 text-right">
					<a href="" class="btn btn-secondary text-uppercase mt-1 btnxemthem">
						<span class="layer1">xem thêm</span>
						<span class="layer2"></span>
						<span class="layer3"></span>
					</a>
				</div>
			</div>
			<div class="khoitren">
				<div class="card-deck mt-5">
					<div class="col-lg-8">
						<div class="card">
							<a href=""><img src="<?php echo base_url() ?>images/carousel-lon.png" class="card-img-top anh-to" alt="..."></a>
							<div class="card-body">
							<h5>
								<a href="" class="text-uppercase font-weight-bold tieude">Ưu đãi cho thành viên mới - Nhận ngay 100K khi nhập mã HELLO</a>
							</h5>
							<p class="card-text noidung">Ưu đãi 100K với mã HELLO chính là món quà dành riêng cho các thành viên mới của The Coffee House trong tháng 5 này!Từ 25/04/2019 đến hết 25/05/2019, chỉ...</p>
							<a href="" class="btn btn-primary text-uppercase mr-3 nut1">
								<span class="layer1">Xem Thêm</span>
								<span class="layer2"></span>
								<span class="layer3"></span>
							</a>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="card nho">
							<img class="anh-carousel" src="<?php echo base_url() ?>images/carousel1.jpg" class="card-img-top" alt="...">
							<div class="card-body">
							<h5>
								<a href="" class="text-uppercase font-weight-bold tieude">THE COFFEE HOUSE THAM GIA DỰ ÁN XÃ HỘI “BÀN TAY ROBOT” UPLIFT</a>
							</h5>
							<p class="card-text noidung">THE COFFEE HOUSE THAM GIA DỰ ÁN XÃ HỘI “BÀN TAY ROBOT” UPLIFT,LAN TOẢ TINH THẦN TÔN TRỌNG SỰ KHÁC BIỆTCuối tháng 3 vừa qua, The Coffee House đã chính...</p>
							<a href="" class="btn btn-primary text-uppercase mr-3 nut1">
								<span class="layer1">Xem Thêm</span>
								<span class="layer2"></span>
								<span class="layer3"></span>
							</a>
							</div>
						</div>
					</div>
				</div>		
			</div> <!-- hết khối trên -->
			<div class="khoiduoi">
				<div class="card-deck mt-5">
					<div class="col-md-6 col-lg-4">
						<div class="card nho">
							<img class="anh-carousel" src="<?php echo base_url() ?>images/carousel2.jpg" class="card-img-top" alt="...">
							<div class="card-body">
							<h5>
								<a href="" class="text-uppercase font-weight-bold tieude">THE COFFEE HOUSE THAM GIA DỰ ÁN XÃ HỘI “BÀN TAY ROBOT” UPLIFT</a>
							</h5>
							<p class="card-text noidung">THE COFFEE HOUSE THAM GIA DỰ ÁN XÃ HỘI “BÀN TAY ROBOT” UPLIFT,LAN TOẢ TINH THẦN TÔN TRỌNG SỰ KHÁC BIỆTCuối tháng 3 vừa qua, The Coffee House đã chính...</p>
							<a href="" class="btn btn-primary text-uppercase mr-3 nut1">
								<span class="layer1">Xem Thêm</span>
								<span class="layer2"></span>
								<span class="layer3"></span>
							</a>
							</div>
						</div>
					</div>
					<div class="col-md-6 col-lg-4">
						<div class="card nho">
							<img class="anh-carousel" src="<?php echo base_url() ?>images/carousel3.jpg" class="card-img-top" alt="...">
							<div class="card-body">
							<h5>
								<a href="" class="text-uppercase font-weight-bold tieude">THE COFFEE HOUSE THAM GIA DỰ ÁN XÃ HỘI “BÀN TAY ROBOT” UPLIFT</a>
							</h5>
							<p class="card-text noidung">THE COFFEE HOUSE THAM GIA DỰ ÁN XÃ HỘI “BÀN TAY ROBOT” UPLIFT,LAN TOẢ TINH THẦN TÔN TRỌNG SỰ KHÁC BIỆTCuối tháng 3 vừa qua, The Coffee House đã chính...</p>
							<a href="" class="btn btn-primary text-uppercase mr-3 nut1">
								<span class="layer1">Xem Thêm</span>
								<span class="layer2"></span>
								<span class="layer3"></span>
							</a>
							</div>
						</div>
					</div>
					<div class="col-md-6 col-lg-4">
						<div class="card nho">
							<img class="anh-carousel" src="<?php echo base_url() ?>images/carousel4.jpg" class="card-img-top" alt="...">
							<div class="card-body">
							<h5>
								<a href="" class="text-uppercase font-weight-bold tieude">THE COFFEE HOUSE THAM GIA DỰ ÁN XÃ HỘI “BÀN TAY ROBOT” UPLIFT</a>
							</h5>
							<p class="card-text noidung">THE COFFEE HOUSE THAM GIA DỰ ÁN XÃ HỘI “BÀN TAY ROBOT” UPLIFT,LAN TOẢ TINH THẦN TÔN TRỌNG SỰ KHÁC BIỆTCuối tháng 3 vừa qua, The Coffee House đã chính...</p>
							<a href="" class="btn btn-primary text-uppercase mr-3 nut1">
								<span class="layer1">Xem Thêm</span>
								<span class="layer2"></span>
								<span class="layer3"></span>
							</a>
							</div>
						</div>
					</div>
				</div> 
			</div> <!-- hết khối dưới -->
		</div>
	</div> <!-- end blog -->

	<div class="diachi">
		<div class="container">
			<div class="row">
				<div class="col-12 bando">
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3918.487677767577!2d106.75835301462318!3d10.850463792271348!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x317527a299ddd1b3%3A0x4877d8f15a35aa0a!2sThe+coffee+house!5e0!3m2!1svi!2s!4v1557732964267!5m2!1svi!2s" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
				</div>
			</div>
		</div>
	</div> <!-- end diachi -->
	
	<?php include 'footer.php' ?>

	<script>
		$(document).ready(function() {
			$('body').on('click', '.themgiohang', function(event) {
				event.preventDefault();
				
				$.ajax({
					url: '<?php echo base_url() ?>User/themGioHang',
					type: 'POST',
					dataType: 'json',
					data: {
						masp: $(this).data('id')
					},
				})
				.done(function() {
					console.log("success");
				})
				.fail(function() {
					console.log("error");
				})
				.always(function(res) {
					console.log("complete");
					console.log(res);
					$('.thongbaonho').text(res['tongsoluong']);
					$('.thongbaogiohang').addClass('hienlen');
				});
				
			});
		});
	</script>
</body>
</html>