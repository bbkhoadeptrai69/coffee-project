<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Giỏ hàng</title>
</head>
<body>
	<?php include 'dangnhap.php' ?>
	<?php include 'slide-menu.php' ?>
	 <?php include 'loading.php' ?>
	
	<div class="chitietgiohang">
		<div class="container">
			<div class="row ">
				<div class="col-12">
					<h4 class="text-uppercase mt-4">giỏ hàng (<?= $tongsoluong ?> sản phẩm)</h4>
				</div>
				<?php if ($this->session->has_userdata('giohang')): ?>
					<div class="col-8 trai danhsachsanpham">
						<?php $tongtien = 0; ?>
						<?php foreach ($giohang as $item): ?>
							<?php $tongtien += $item['gia'] * $item['soluong']; ?>
							<div class="motsanpham">
								<div class="row">
									<div class="col-3"><img class="hinhanh" src="<?= $item['hinhanh'] ?>" alt=""></div>
									<div class="col-5 tensp">
										<a class="ten text-uppercase" href=""><?= $item['tensp'] ?></a>
										<hr>
										<a data-masp="<?= $item['masp'] ?>" href="" class="btnXoagiohang">Xóa</a>
									</div>
									<div class="col-4">
										<div class="row">
											<div class="col-8">
												<p class="gia"><?php echo number_format($item['gia']) ?> đ</p>
											</div>
											<div class="col-4">
												<div class="tuychinhsoluong">
													<span data-masp="<?= $item['masp'] ?>" class="tru">-</span>
													<input data-masp="<?= $item['masp'] ?>" class="soluong" type="text" value="<?= $item['soluong'] ?>">
													<span data-masp="<?= $item['masp'] ?>" class="cong">+</span>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div> <!-- end motsanpham -->
						<?php endforeach ?>
					</div> <!-- end trai -->
					<div class="col-4 phai">
						<div class="thanhtien">
							<span>Thành tiền: </span>
							<strong class="text-danger tongthanhtien"><?php echo number_format($tongtien) ?> đ</strong>
						</div>
						<fieldset class="form-group mt-4">
							<button class="btn btn-danger form-control thanhtoan">Tiến hành đặt hàng</button>
						</fieldset>
					</div>
				<?php else: ?>
					<div class="col-12 justify-content-center">
						<div class="giohangtrong text-center">
							<img src="<?php echo base_url() ?>images/mascot.png" alt="">
							<p>Không có sản phẩm nào trong giỏ hàng của bạn.</p>
							<a href="<?php echo base_url() ?>" class=" btn btn-warning">Tiếp tục mua sắm</a>
						</div>
					</div>
				<?php endif ?>
				
			</div>
		</div>
	</div>
	<div class="thongbaoquasoluong">
		Bạn đã chọn tối đa số lượng của sản phẩm này.
	</div>
	<?php include 'footer.php' ?>

	<script type="text/javascript">
		$(document).ready(function() {
			$('.tru').click(function(event) {
				var soluonghientai = $(this).next().val();
				if(soluonghientai > 1)
				{
					var soluongmoi = soluonghientai - 1;
					$(this).next().val(soluongmoi);

					var masp = $(this).data('masp');


					$.ajax({
						url: '<?php echo base_url() ?>User/capnhatsoluongspgiohang',
						type: 'POST',
						dataType: 'json',
						data: {
							masp: masp,
							soluong: soluongmoi
						},
					})
					.done(function() {
						console.log("success");
					})
					.fail(function() {
						console.log("error");
					})
					.always(function(res) {
						console.log("complete");
						$('.thongbaonho').text(res['tongsoluong']);
						$('.tongthanhtien').text(res['tongthanhtien'].toLocaleString('en') + ' đ');
					});
					
				}
				
			});

			$('.cong').click(function(event) {
				var soluonghientai = parseInt($(this).prev().val());
				var soluongmoi = (soluonghientai + 1);
				var txtsoluong = $(this).prev();
				$(this).prev().val(soluongmoi);

				var masp = $(this).data('masp');

				$.ajax({
					url: '<?php echo base_url() ?>User/capnhatsoluongspgiohang',
					type: 'POST',
					dataType: 'json',
					data: {
						masp: masp,
						soluong: soluongmoi
					},
				})
				.done(function() {
					console.log("success");
				})
				.fail(function() {
					console.log("error");
				})
				.always(function(res) {
					console.log("complete");
					if(res['stt'] == false)
					{
						txtsoluong.val(soluongmoi - 1);
						$('.thongbaoquasoluong').addClass('hienlen').one('webkitTransitionEnd', function(event) {
							$(this).removeClass('hienlen');
						});
					}
					else
					{
						$('.thongbaonho').text(res['tongsoluong']);
						$('.tongthanhtien').text(res['tongthanhtien'].toLocaleString('en') + ' đ');
					}
				});
			});

			$('.soluong').blur(function(event) {
				if($(this).val() == '' || $(this).val() == '0' || $(this).val() < 0)
				{
					$(this).val(1);
				}
				var txtsoluong = $(this);
				var masp = $(this).data('masp');
				var soluongmoi = $(this).val();

				$.ajax({
					url: '<?php echo base_url() ?>User/capnhatsoluongspgiohang',
					type: 'POST',
					dataType: 'json',
					data: {
						masp: masp,
						soluong: soluongmoi
					},
				})
				.done(function() {
					console.log("success");
				})
				.fail(function() {
					console.log("error");
				})
				.always(function(res) {
					console.log("complete");
					if(res['stt'] == false)
					{
						txtsoluong.val(res['soluongton']);
						$('.thongbaonho').text(res['tongsoluong']);
						$('.tongthanhtien').text(res['tongthanhtien'].toLocaleString('en') + ' đ');
						$('.thongbaoquasoluong').addClass('hienlen').one('webkitTransitionEnd', function(event) {
							$(this).removeClass('hienlen');
						});
					}
					else
					{
						$('.thongbaonho').text(res['tongsoluong']);
						$('.tongthanhtien').text(res['tongthanhtien'].toLocaleString('en') + ' đ');
					}
					
				});
			});

			$('.thanhtoan').click(function(event) {
				$(location).attr('href', '<?php echo base_url() ?>User/thanhtoan');
			});

			$('.btnXoagiohang').click(function(event) {
				event.preventDefault();

				$.ajax({
					url: 'xoagiohang',
					type: 'POST',
					dataType: 'json',
					data: {
						masp: $(this).data('masp')
					},
				})
				.done(function() {
					console.log("success");
				})
				.fail(function() {
					console.log("error");
				})
				.always(function() {
					console.log("complete");
					location.reload();
				});
				
			});
		});
	</script>
</body>
</html>