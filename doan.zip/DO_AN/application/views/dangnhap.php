<div class="dangnhap">
	<div class="nen"></div>
	<div class="khoi">
	  <div class="form-row">
	  	<div class="col-6">
	  		<h3 class="text-uppercase">đăng nhập</h3>
	  	</div>
	  	<div class="col-6 text-right">
	  		<a href="" class="text-uppercase btnclose">x</a>
	  	</div>
	    <div class="form-group col-12">
	      <label for="inputEmail4">Username</label>
	      <input type="text" class="form-control username" id="inputEmail4" placeholder="Username">
	      <div class="text-danger font-weight-bold validationUsername valid"></div>
	    </div>
	    <div class="form-group col-12">
	      <label for="inputPassword4">Password</label>
	      <input type="password" class="form-control password" id="inputPassword4" placeholder="Password">
	      <div class="text-danger font-weight-bold validationPassword valid"></div>
	    </div>
	    <div class="form-group col-12">
	      <div class="text-danger font-weight-bold thongbao"></div>
	    </div>
	  </div>
	  <fieldset class="form-group">
			<p>Quên mật khẩu? Khôi phục mật khẩu <a class="btnQuenmatkhau" href="">tại đây</a></p>
		</fieldset>
	  <button type="button" class="btn btn-primary btnDangNhapNgay">Đăng Nhập Ngay</button>
	</div>
</div> <!-- end dangnhap -->

<div style="display: none" class="quenmatkhau">
	<div class="text-success thanhcong font-weight-bold"></div>
	<div class="form-group row justify-content-center mt-4">
		<div class="nutx">X</div>
		<label class="col-3" for="">Nhập email đăng ký</label>
		<div class="col-9">
			<input type="email" class="form-control email">
			<div class="valid vlemail text-danger"></div>
		</div>
		<br>
		<button class="btnGuiemail btn btn-outline-danger">Gửi</button>
	</div>
</div>

<script type="text/javascript">
	$(document).ready(function() {
		$('.btnQuenmatkhau').click(function(event) {
			event.preventDefault();
			$('.quenmatkhau').slideDown('fast');
		});
		$('.nutx').click(function(event) {
			$('.quenmatkhau').slideUp('fast');
		});

		$('.quenmatkhau .btnGuiemail').click(function(event) {
			console.log("aa");
			$('.valid').text('');
			if($('.email').val() == '')
			{
				$('.vlemail').text('không bỏ trống email');
				$('.email').focus();
			}

			else
			{
				$.ajax({
					url: '<?php echo base_url() ?>User/quenmatkhau',
					type: 'POST',
					dataType: 'json',
					data: {
						email: $('.email').val()
					},
				})
				.done(function() {
					console.log("success");
				})
				.fail(function() {
					console.log("error");
				})
				.always(function(res) {
					console.log("complete");
					if (res) 
					{
						$('.email').val('');
						$('.thanhcong').text('Chúng tôi đã gửi mật khẩu cho bạn. Kiểm tra email ngay');
					}
					else
					{
						$('.vlemail').text('Email này không tồn tại. Xin kiểm tra lại');
						$('.email').focus().select();
					}
				});
				
			}
		});
	});
</script>