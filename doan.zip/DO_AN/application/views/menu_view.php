<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>MENU</title>
</head>
<body data-spy="scroll" data-target="#menu-trai" data-offset="150">
	<?php include 'loading.php' ?>
	<?php include 'dangnhap.php' ?>

	<div class="slide-menu">
		<div class="container-fluid">
			<div class="anh"></div>
		</div>
	</div> <!-- end slide-menu -->
	
	<div class="content-menu mt-5 pt-5">
		<div class="container">
			<div class="row content">
				<div class="col-lg-3">
					<div class="sidebar" id="menu-trai">
						<ul class="nav">
							<?php $i = 0; ?>
							<?php foreach ($dsloaisp as $item): ?>
								<?php $i++; ?>
								<li class="text-uppercase"><a class="nav-link" href="#danhmuc_<?php echo $i ?>"><?= $item['tenloaisp'] ?></a></li>
							<?php endforeach ?>
						</ul>
					</div>
				</div>
				<div class="col-lg-9">
					<div class="search row mb-5">
						<div class="col-8">
							<input type="text" class="form-control strTimkiem" placeholder="Tìm sản phẩm, danh mục mong muốn ...">
						</div>
						<div class="col-4">
							<button class="btn btn-info btnTimKiem">Tìm kiếm</button>
						</div>
						
					</div>
					<div class="sanpham">
						
						<?php $i = 0; ?>
						<?php foreach ($dsloaisp as $item): ?>
							<?php $i++; ?>
							<div data-maloaisp="<?php echo $item['id'] ?>" id="danhmuc_<?php echo $i; ?>" class="motdanhmuc mb-5">
								<div class="row tendanhmuc">
									<div class="col-sm-6">
										<h3 class="text-uppercase font-weight-bold"><?= $item['tenloaisp'] ?></h3>
										<div class="vachngan"></div>
									</div>
								</div>
								<div class="row sanpham mt-4">
									<?php foreach ($dssp as $value): ?>
										<?php if ($value['maloaisp'] == $item['id']): ?>
											<div class="col-sm-4 motsanpham mb-4">
												<a href="<?php echo base_url() ?>User/chitietsanpham/<?php echo $value['bidanh'] ?>" class="anhsanpham">
													<img src="<?= $value['hinhanh'] ?>" class="img-fluid rounded" alt="">
													<span class="nen"></span>
												</a>
												<a href="" class="tensanpham text-uppercase ml-3"><?= $value['tensp'] ?></a>
												<h4 class="giatien mt-4 mb-3 "><?= number_format($value['gia']) ?> Đ</h4>
												
												<a href="<?php echo base_url() ?>User/chitietsanpham/<?php echo $value['bidanh'] ?>" class="btn btn-primary text-uppercase mr-3 mt-4 ml-4 nut1">
													<span class="layer1">mua ngay</span>
													<span class="layer2"></span>
													<span class="layer3"></span>
												</a>
												<a data-id="<?= $value['masp'] ?>" href="" class="btnThemVaoGioHang"><i class="fas fa-cart-plus"></i></a>
											</div>
										<?php endif ?>
									<?php endforeach ?>
								</div>
							</div>
						<?php endforeach ?>
					</div> <!-- end sanpham -->
					
				</div>
			</div>
			
		</div>
	</div> <!-- end content-menu -->

	<?php include 'footer.php' ?>

	<script type="text/javascript">
		$(document).ready(function() {
			$('.content-menu .sidebar ul li a').click(function(event) {
				
				var id = $(this).attr('href');

				var khoangcach = $(id).offset().top - 100;

				$('body').animate({scrollTop: khoangcach}, 1000, "easeOutCirc");

				return false;
			});

			$('body').on('click', '.btnThemVaoGioHang', function(event) {
				event.preventDefault();
				
				$.ajax({
					url: '<?php echo base_url() ?>User/themGioHang',
					type: 'POST',
					dataType: 'json',
					data: {
						masp: $(this).data('id')
					},
				})
				.done(function() {
					console.log("success");
				})
				.fail(function() {
					console.log("error");
				})
				.always(function(res) {
					console.log("complete");
					console.log(res);
					$('.thongbaonho').text(res['tongsoluong']);
					$('.thongbaogiohang').addClass('hienlen');
				});
			});

			$('.search .btnTimKiem').click(function(event) {
				$.ajax({
					url: 'timkiem',
					type: 'POST',
					dataType: 'json',
					data: {
						strtimkiem: $('.strTimkiem').val()
					},
				})
				.done(function() {
					console.log("success");
				})
				.fail(function() {
					console.log("error");
				})
				.always(function(res) {
					console.log("complete");
					$('.sanpham').children().remove();
					var noidung ='<div class="motdanhmuc mb-5">';
					noidung += '<div class="row tendanhmuc">';
					noidung += '<div class="col-sm-6">';
					noidung += '<h3  class="text-uppercase font-weight-bold">'+ res[0]['tenloaisp'] +'</h3>';
					noidung += '<div class="vachngan"></div>';
					noidung += '</div>';
					noidung += '</div>';
					noidung += '<div class="row sanpham mt-4">';
					
					for(var i = 0; i < res.length; ++i)
					{
						//console.log(res[i]['masp']);
						noidung += '<div class="col-sm-4 motsanpham mb-4">';
						noidung += '<a href="<?php echo base_url() ?>User/chitietsanpham/'+ res[i]['bidanh'] +'" class="anhsanpham">';
						noidung += '<img src="'+ res[i]['hinhanh'] +'" class="img-fluid rounded" alt="">';
						noidung += '<span class="nen"></span>';
						noidung += '</a>';
						noidung += '<a href="" class="tensanpham text-uppercase ml-3">'+ res[i]['tensp'] +'</a>';
						noidung += '<h4 class="giatien mt-4 mb-3 ">'+ res[i]['gia'].toLocaleString('en') +' Đ</h4>';
						noidung += '<a href="<?php echo base_url() ?>User/chitietsanpham/'+ res[i]['bidanh'] +'"" class="btn btn-primary text-uppercase mr-3 mt-4 ml-4 nut1">';
						noidung += '<span class="layer1">mua ngay</span>';
						noidung += '<span class="layer2"></span>';
						noidung += '<span class="layer3"></span>';
						noidung += '</a>';
						noidung += '<a data-id="'+ res[i]['masp'] +'" href="" class="btnThemVaoGioHang"><i class="fas fa-cart-plus"></i></a>';
						noidung += '</div> <!-- end motsanpham -->';			
					}
					noidung += '</div>';
					noidung += '</div>';

					$('.sanpham').append(noidung);
				});
				
			});

			$('.phantrang ul li.pageindex').click(function(event) {
				$('.phantrang ul li').removeClass('active');
				$(this).addClass('active');

				var maloaisp = $(this).data('maloaisp');
				var pageindex = $(this).text();
				$.ajax({
					url: 'phantrang',
					type: 'POST',
					dataType: 'json',
					data: {
						maloaisp: maloaisp,
						pageindex: pageindex
					},
				})
				.done(function() {
					console.log("success");
				})
				.fail(function() {
					console.log("error");
				})
				.always(function(res) {
					console.log("complete");
					$('.motdanhmuc').each(function(index, el) {
						console.log('a');
						if($(this).data('maloaisp') == res['dsspphantrang'][0]['maloaisp'])
						{
							$(this).children().next().children().remove();

							for(var i = 0; i< res['dsspphantrang'].length; i++)
							{
								var noidung = '<div class="col-sm-4 motsanpham mb-4">';
								noidung += '<a href="single.html" class="anhsanpham">';
								noidung += '<img src="'+ res['dsspphantrang'][i]['hinhanh'] +'" class="img-fluid rounded" alt="">';
								noidung += '<span class="nen"></span>';
								noidung += '</a>';
								noidung += '<a href="" class="tensanpham text-uppercase ml-3">'+ res['dsspphantrang'][i]['tensp'] +'</a>';
								noidung += '<h4 class="giatien mt-4 mb-3 ">'+ res['dsspphantrang'][i]['gia'].toLocaleString('en') +' Đ</h4>';
								noidung += '<a href="single.html" class="btn btn-primary text-uppercase mr-3 mt-4 ml-4 nut1">';
								noidung += '<span class="layer1">mua ngay</span>';
								noidung += '<span class="layer2"></span>';
								noidung += '<span class="layer3"></span>';
								noidung += '</a>';
								noidung += '<a data-id="'+ res['dsspphantrang'][i]['masp'] +'" href="" class="btnThemVaoGioHang"><i class="fas fa-cart-plus"></i></a>';
								noidung += '</div>';
								$(this).children().next().first().append(noidung);	
							}

							$(this).children().next().next().children().remove();
							var noidungphantrang = '<ul>';
							noidungphantrang += '<li class="prev"><<</li>';
							for(var i = 0; i<res['sotrang']; i++)
							{
								noidungphantrang += '<li data-maloaisp="<?= $item['id'] ?>" class="pageindex active">1</li>';
							}
							noidungphantrang += '<li class="next">>></li>';
							noidungphantrang += '</ul>';
							$(this).children().next().next().append(noidungphantrang);
						}
					});
				});
				
			});
		});	
	</script>
</body>
</html>