<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Quản lý thành viên</title>
</head>
<body>

	<div class="main">
		<div class="container-fluid">
			<?php include('sidebar.php') ?>
			
			<div class="content mt-5">
				<div class="thanhvien"> 
					<div class="container">
						<nav aria-label="breadcrumb">
						  <ol class="breadcrumb">
						    <li class="breadcrumb-item"><a class="font-weight-bold" href="#themmoi">Thêm thành viên mới</a></li>
						    <li class="breadcrumb-item" aria-current="page"><a href="#danhsach">Danh sách thành viên</a></li>
						  </ol>
						</nav>
						<div class="row justify-content-center">
							<div id="themmoi" class="col-7 themthanhvien">
								<div class="jumbotron">
									<h3 class="text-center text-uppercase">Thêm thành viên mới</h3>
									<fieldset class="form-group">
										<label for=""> Họ tên thành viên</label>
										<input type="text" class="form-control hoten" placeholder="nhập tên thành viên">
										<div class="validationHoTen text-danger"></div>
									</fieldset>
									<fieldset class="form-group">
										<label for=""> Tài khoản</label>
										<input type="text" class="form-control taikhoan" placeholder="nhập tên tài khoản">
									</fieldset>
									<fieldset class="form-group">
										<label for=""> Mật khẩu</label>
										<input type="password" class="form-control matkhau">
									</fieldset>
									<fieldset class="form-group">
										<label for="">Nhập lại mật khẩu</label>
										<input type="password" class="form-control nhaplaimatkhau">
									</fieldset>
									<fieldset class="form-group">
										<label for="">Địa chỉ</label>
										<input type="text" class="form-control diachi" placeholder="nhập địa chỉ">
									</fieldset>
									<fieldset class="form-group">
										<label for="">Email</label>
										<input type="email" class="form-control email" placeholder="nhập email">
										<div class="text-danger validateEmail"></div>
									</fieldset>
									<fieldset class="form-group">
										<label for="">Số điện thoại</label>
										<input type="number" class="form-control sodienthoai" placeholder="nhập số điện thoại">
									</fieldset>
									<fieldset class="form-group">
										<label for="">Avatar</label>
										<input id="file" type="file" name="avatar" class="form-control-file">
										<div class="validationAvatar"></div>
									</fieldset>

									<fieldset class="form-group">
										<label for="">Loại thành viên</label>
										<select name="" id="maloaitv" class="form-control">
											<?php foreach ($loaithanhvien as $item): ?>
												<option class="text-uppercase" value="<?= $item['id'] ?>"><?= $item['tenloaitv'] ?></option>
											<?php endforeach ?>
										</select>
									</fieldset>
									<div class="text-center mt-4">
										<button type="button" class="btnThemMoi btn btn-outline-info">Thêm Mới</button>
									</div>
								</div> <!-- end jumbotron -->
							</div> <!-- end themsanpham -->
							<div id="danhsach" class="col-12 danhsachthanhvien d-none">
								<div class="jumbotron">
									<h2 class="text-center text-uppercase">Danh sách thành viên</h2>
								</div>
								<div class="table-responsive">
									<table class="table table-striped table-dark">
									  <thead>
									    <tr>
									      <th scope="col">Mã TV</th>
									      <th scope="col">Tài Khoản</th>
									      <th scope="col">Họ Tên</th>
									      <th scope="col">Địa Chỉ</th>
									      <th scope="col">Email</th>
									      <th scope="col">Avatar</th>
									      <th scope="col">Số Điện Thoại</th>
									      <th scope="col">Loại Thành Viên</th>
									      <th scope="col">Trạng Thái</th>
									      <th></th>
									    </tr>
									  </thead>
									  <tbody>
									  	<?php foreach ($dsthanhvien as $item): ?>
										    <tr>
										      <th scope="row"><?= $item['matv'] ?></th>
										      <td>
										      	<p class="ptaikhoan"><?= $item['taikhoan'] ?></p>
										      	<input type="text" class="iptaikhoan form-control d-none" value="<?= $item['taikhoan'] ?>">	
										      </td>
										      <td>
										      	<p class="photen"><?= $item['hoten'] ?></p>
										      	<input type="text" class="iphoten form-control d-none" value="<?= $item['hoten'] ?>">
										      	<div class="validationHoTen2"></div>	
										      </td>
										      <td>
										      	<p class="pdiachi"><?= $item['diachi'] ?></p>
										      	<input type="text" class="ipdiachi form-control d-none" value="<?= $item['diachi'] ?>">	
										      </td>
										      <td>
										      	<p class="pemail"><?= $item['email'] ?></p>
										      	<input type="text" class="ipemail form-control d-none" value="<?= $item['email'] ?>">
										      	<div class="validateEmail2"></div>		
										      </td>
										      <td>
										      	<img class="img-50" src="<?= $item['avatar'] ?>" alt="">
										      	<input type="hidden" class="avatarcu" value="<?= $item['avatar'] ?>">
										      	<input id="avatarmoi" type="file" class="form-control-file d-none">
										      </td>
										      <td>
										      	<p class="psodienthoai"><?= $item['sodienthoai'] ?></p>
										      	<input type="text" class="ipsodienthoai form-control d-none" value="<?= $item['sodienthoai'] ?>">	
										      </td>
										      <td>
										      	<p class="ptenloaitv"><?= $item['tenloaitv'] ?></p>
										      	<select name="" id="selecttenloaitv" class="form-control d-none">
										      		<?php foreach ($loaithanhvien as $item1): ?>
														<option class="text-uppercase" value="<?= $item1['id'] ?>"><?= $item1['tenloaitv'] ?></option>
													<?php endforeach ?>
										      	</select>	
										      </td>
										      <?php if ($item['trangthai'] == 1): ?>
										      		<td>
										      			<p class="ptrangthai">Hoạt động</p>
										      			<input type="checkbox" class="chktrangthai d-none" checked>
										      		</td>
										      <?php else: ?>
										      		<td>
										      			<p class="ptrangthai">Không hoạt động</p>
										      			<input type="checkbox" class="chktrangthai d-none">
										      		</td>
										      <?php endif ?>
										     
										      <td>
										      	<a data-matv="<?= $item['matv'] ?>" href="" class="btnEdit btn btn-outline-warning"><i class="fas fa-pen"></i></a>
										      	<a data-matv="<?= $item['matv'] ?>" href="" class="btnSave btn btn-outline-success d-none"><i class="fas fa-check"></i></a>
										      	<a data-matv="<?= $item['matv'] ?>" href="" class="btnDelete btn btn-outline-danger"><i class="fas fa-times"></i></a>
										      </td>
										    </tr>
									    <?php endforeach ?>
									  </tbody>
									</table>
								</div>
							</div> <!-- end danhsachthanhvien -->
						</div>
					</div>
				</div>
			</div><!--  end content -->

		</div>
	</div> <!-- end main -->

	<div class="menuthongbao thanhcong thongbao bg-info">
		<p><i class="fas fa-check-circle mr-3" style="font-size: 20px"></i>Thành công</p>
	</div>

	<div class="menuthongbao thatbai thongbao bg-danger">
		<p><i class="fas fa-times-circle mr-3" style="font-size: 20px"></i>Thất Bại</p>
	</div>

	<script>
		$(document).ready(function() {
			function validateEmail($email) {
			  var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
			  return emailReg.test( $email );
			}
			//xử lý sự kiện click nút thêm mới
			$('.btnThemMoi').click(function(event) {	
				var email = $('.email').val();
				if(!validateEmail(email))
				{
					$('.validateEmail').text('Email không đúng định dạng');
					return false;
				}
				if($('.hoten').val() == '')
				{
					$('.validationHoTen').append('Họ tên thành viên không được bỏ trống');
					$('html').animate({scrollTop: $('.validationHoTen').offset().top - 70}, 500)
					return false;
				}
				var file_data = $('#file').prop('files')[0];
				if(file_data != null)
				{
					//lấy kiểu file
					var type = file_data.type;
					var match = ["image/gif", "image/png", "image/jpg", "image/jpeg"];
					if (type == match[0] || type == match[1] || type == match[2] || type == match[3]) {

						//khởi tạo đối tượng form data
			            var form_data = new FormData();

			             //thêm files vào trong form data
			            form_data.append('avatar', file_data);
			            form_data.append('hoten', $('.hoten').val());
			            form_data.append('taikhoan', $('.taikhoan').val());
			            form_data.append('matkhau', $('.matkhau').val());
			            form_data.append('diachi', $('.diachi').val());
			            form_data.append('email', $('.email').val());
			            form_data.append('sodienthoai', $('.sodienthoai').val());
			            form_data.append('maloaitv', $('#maloaitv').val());
					
						$.ajax({
							url: 'themThanhVien',
							type: 'POST',
							dataType: 'json',
							cache: false,
			                contentType: false,
			                processData: false,
							data: form_data
						})
						.done(function() {
							console.log("success");
						})
						.fail(function() {
							console.log("error");
						})
						.always(function(res) {
							console.log("complete");
							location.reload();
							
							//cập nhật các ô input thành trống
							$('#file').val('');
							$('input').each(function(index, el) {
								$(this).val('');
							});
							
							//hiện thị thông báo thành công thất bại
							if(res)
							{
								$('.thanhcong').addClass('hienlen').one('webkitTransitionEnd', function(event) {
									$(this).addClass('matdi').one('webkitTransitionEnd', function(event) {
										$(this).removeClass('matdi').removeClass('hienlen');
									});
								});
							}
							else
							{
								$('.thatbai').addClass('hienlen').one('webkitTransitionEnd', function(event) {
									$(this).addClass('matdi').one('webkitTransitionEnd', function(event) {
										$(this).removeClass('matdi').removeClass('hienlen');
									});
								});
							}
						});
					}
				}
				else
				{
					$('.validationAvatar').append('<p class="text-danger">Vui lòng chọn phần tử này</p>');
					var vitriAvatar = $('.validationAvatar').offset().top - 70;
					$('html').animate({scrollTop: vitriAvatar}, 700);	
				}	
			});

			//xử lý sự kiện click breadcrumb
			$('.thanhvien nav ol li a').click(function(event) {
				event.preventDefault();

				$('#danhsach').addClass('d-none');
				$('#themmoi').addClass('d-none');
				$('nav ol li a').removeClass('font-weight-bold');
				$(this).addClass('font-weight-bold');
				var id = $(this).attr('href');
				$(id).removeClass('d-none');
			});


			//xử lý sự kiện click xóa thành viên
			$('body').on('click', '.btnDelete', function(event) {
				event.preventDefault();
				if(confirm("Bạn có chắc chắn muốn xóa thành viên này không?")){
					var matv = $(this).data('matv');
					$.ajax({
						url: 'xoaThanhVien',
						type: 'POST',
						dataType: 'json',
						data: {
							matv: matv
						},
					})
					.done(function() {
						console.log("success");
					})
					.fail(function() {
						console.log("error");
					})
					.always(function() {
						console.log("complete");
					});
					
				}
				else{
					return false;
				}
			});

			//xử lý sự kiện click sửa thành viên
			$('body').on('click', '.btnEdit', function(event) {
				event.preventDefault();
				//ẩn hiện tài khoản
				$('.iptaikhoan').removeClass('d-none');
				$('.ptaikhoan').addClass('d-none');

				//ẩn hiện họ tên
				$('.iphoten').removeClass('d-none');
				$('.photen').addClass('d-none');

				//ẩn hiện địa chỉ
				$('.ipdiachi').removeClass('d-none');
				$('.pdiachi').addClass('d-none');

				//ẩn hiện email
				$('.ipemail').removeClass('d-none');
				$('.pemail').addClass('d-none');

				//xử lý và ẩn hiện avatar
				$('#avatarmoi').removeClass('d-none');

				//ẩn hiện sodienthoai
				$('.ipsodienthoai').removeClass('d-none');
				$('.psodienthoai').addClass('d-none');

				//ẩn hiện tenloaitv
				$('#selecttenloaitv').removeClass('d-none');
				$('.ptenloaitv').addClass('d-none');

				//ẩn hiện tên cấp độ
				$('#selecttencapdo').removeClass('d-none');
				$('.ptencapdo').addClass('d-none');

				//ẩn hiện trạng thái
				$('.chktrangthai').removeClass('d-none');
				$('.ptrangthai').addClass('d-none');

				//ẩn hiện nút
				$('.btnEdit').addClass('d-none');
				$('.btnSave').removeClass('d-none');

			});

			//xử lý sự kiện khi click Lưu
			$('body').on('click', '.btnSave', function(event) {
				event.preventDefault();
				//khởi tạo đối tượng form data
	            var form_data = new FormData();
				var avatar;
				//xử lý ảnh
				
				// if($('#avatarmoi').val() == '')
				// {
				// 	//trường họp không chọn ảnh => lấy lại ảnh cũ
				// 	avatarcu = $('.avatarcu').val();
				// 	form_data.append('avatarcu', avatarcu);

				// }
				// else
				// {
				// 	var email = $('.email').val();
				// 	if(!validateEmail(email))
				// 	{
				// 		$('.validateEmail2').text('Email không đúng định dạng');
				// 		return false;
				// 	}

				// 	//trường hợp chọn ảnh => lấy ảnh mới
				// 	var file_data = $('#avatarmoi').prop('files')[0];
				// 	var type = file_data.type;
				// 	var match = ["image/gif", "image/png", "image/jpg", "image/jpeg"];
				// 	if (type == match[0] || type == match[1] || type == match[2] || type == match[3]) {
				// 		form_data.append('avatarmoi', file_data);
				// 	}
				// }
				avatarcu = $('.avatarcu').val();
				form_data.append('avatarcu', avatarcu);
				var file_data = $('#avatarmoi').prop('files')[0];
				form_data.append('avatarmoi', file_data);
				//kiểm tra họ tên
				if($('.iphoten').val() == '')
				{
					$('.validationHoTen2').append('Họ tên thành viên không được bỏ trống');
					$('html').animate({scrollTop: $('.validationHoTen').offset().top - 70}, 500)
					return false;
				}

				$.ajax({
					url: 'luuThanhVien',
					type: 'POST',
					dataType: 'json',
					cache: false,
	                contentType: false,
	                processData: false,
					data: form_data
				})
				.done(function() {
					console.log("success");
				})
				.fail(function() {
					console.log("error");
				})
				.always(function() {
					console.log("complete");
				});
				
			});

		});
	</script>
</body>
</html>