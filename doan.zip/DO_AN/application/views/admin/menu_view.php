<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Quản lý menu</title>
</head>
<body>

	<div class="main">
		<div class="container-fluid">
			<?php include('sidebar.php') ?>
			
			<div class="content mt-5">
				<div class="container">
					<nav aria-label="breadcrumb">
					  <ol class="breadcrumb">
					    <li class="breadcrumb-item"><a class="font-weight-bold" href="#themmoi">Thêm phần tử menu</a></li>
					    <li class="breadcrumb-item" aria-current="page"><a href="#danhsach">Danh sách phần tử menu</a></li>
					  </ol>
					</nav>
					
					<div id="themmoi" class="row justify-content-center themmoiphantumenu">
						<div class="col-8 ">
							<div class="jumbotron">
								<?php if (is_null($danhsachmenu)): ?>
									<fieldset class="form-group">
										<label for="">Văn bản logo</label>
										<input type="text" class="form-control textlogo" placeholder="nhập văn bản logo">
									</fieldset>
								<?php else: ?>
									<?php foreach ($danhsachmenu as $item): ?>
										<fieldset class="form-group">
											<label for="">Văn bản logo</label>
											<input type="text" class="form-control textlogo" placeholder="nhập văn bản logo" value="<?php echo $item['textlogo'] ?>">
										</fieldset>
									<?php endforeach ?>
								<?php endif ?>
								
								<hr>
								<h3 class="text-center text-uppercase">Thêm mới phần tử menu</h3>
								
								<div class="phantumenu">
									<h3>Thông tin phần tử menu</h3>
									<fieldset class="form-group">
										<label for="">Text</label>
										<input type="text" class="form-control textmenu" placeholder="nhập text">
									</fieldset>
									<fieldset class="form-group">
										<label for="">Link</label>
										<input type="text" class="form-control linkmenu" placeholder="nhập link">
									</fieldset>
									<h3>Menu phụ</h3>
									<div class="phantumenuphu ml-5">

									</div> <!-- end phantumenuphu -->
									<button type="button" class="btn btn-outline-primary btnThemmenuphu ml-5"><i class="fas fa-plus"></i></button>
									<button type="button" class="btn btn-outline-primary btnXoamenuphu"><i class="fas fa-minus"></i></button>
								</div><!--  end phantumenu -->

								<div class="text-center mt-4">
									<button type="button" class="btn btn-outline-info btnThemMoi">Thêm Mới</button>
								</div>
							</div> <!-- end jumbotron -->
						</div> <!-- end .col-5 -->
					</div><!--  end row themmoiphantumenu-->

					<div id="danhsach" class="row danhsachmenu d-none">
						<div class="col-12">
							<div class="jumbotron">
								<h2 class="text-center text-uppercase">Danh sách các phần tử menu</h2>
							</div>
						</div>
						<?php if (!is_null($danhsachitemmenu)): ?>
							<?php foreach ($danhsachitemmenu as $value): ?>
								<div class="col-6">
									<div class="jumbotron">
										<?php $j = 0; ?>
											<?php $j++; ?>
											<div class="phantumenu">
												<h3>Thông tin phần tử menu: <?php echo $j; ?></h3>
												<fieldset class="form-group">
													<label for="">Text</label>
													<input type="text" class="form-control" placeholder="nhập text" value="<?= $value['textmenu'] ?>">
												</fieldset>
												<fieldset class="form-group">
													<label for="">Link</label>
													<input type="text" class="form-control" placeholder="nhập link" value="<?= $value['linkmenu'] ?>">
												</fieldset>
												<h3>Menu phụ</h3>
												<div class="dsphantumenuphu ml-5">
													<?php $i = 0; ?>
													<?php foreach ($value['menuphu'] as $value2): ?>
														<?php $i++; ?>
														<h4>Phần tử menu phụ: <?php echo $i ?></h4>	
														<fieldset class="form-group">	
															<label for="">Text</label>
															<input type="text" class="form-control textmenuphu" placeholder="nhập text" value="<?= $value2['textmenuphu'] ?>">
														</fieldset>
														<fieldset class="form-group">
															<label for="">Link</label>
															<input type="text" class="form-control linkmenuphu" placeholder="nhập link" value="<?= $value2['linkmenuphu'] ?>">
														</fieldset>
													<?php endforeach ?>			
												</div> <!-- end phantumenuphu -->
												<button type="button" class="btn btn-outline-primary btnThemmenuphu ml-5"><i class="fas fa-plus"></i></button>
												<button type="button" class="btn btn-outline-primary btnXoamenuphu"><i class="fas fa-minus"></i></button>
											</div>  <!-- end phantumenu -->

										<div class="text-center mt-4">
											
										</div>
									</div> <!-- end jumbotron -->
								</div> <!-- end .col-6 -->
							<?php endforeach ?>
						<?php else: ?>
							<p class="thongbaotrong">Danh sách trống</p>
						<?php endif ?>
					</div>
					

				</div> <!-- end container -->
			</div><!--  end content -->

		</div>
	</div> <!-- end main -->

	<script>
		$(document).ready(function(){
			var i = 0;
			$('.btnThemmenuphu').click(function(event) {
				event.preventDefault();

				i++;
				var	noidungmenuphu = '<div class="nd">';
				noidungmenuphu += '<h4>Phần tử menu phụ thứ: '+ i +'</h4>';
				noidungmenuphu += '<fieldset class="form-group">';
				noidungmenuphu += '<label for="">Text</label>';
				noidungmenuphu += '<input type="text" class="form-control iptextmenuphu" placeholder="nhập text">';
				noidungmenuphu += '</fieldset>';
				noidungmenuphu += '<fieldset class="form-group">';
				noidungmenuphu += '<label for="">Link</label>';
				noidungmenuphu += '<input type="text" class="form-control iplinkmenuphu" placeholder="nhập link">';
				noidungmenuphu += '</fieldset>';
				noidungmenuphu += '</div>';

				$('.phantumenuphu').append(noidungmenuphu);					
			});

			$('.btnXoamenuphu').click(function(event) {
				$('.nd:last-child').remove();
				if(i>0)
					i--;
			});	


			$('nav ol li a').click(function(event) {
				event.preventDefault();

				$('#danhsach').addClass('d-none');
				$('#themmoi').addClass('d-none');
				$('nav ol li a').removeClass('font-weight-bold');
				$(this).addClass('font-weight-bold');
				var id = $(this).attr('href');
				$(id).removeClass('d-none');

			});

			$('body').on('click', '.btnThemMoi', function(event) {
				event.preventDefault();
				$('.thongbaotrong').remove();

				var textmenuphu = [];
				var linkmenuphu = [];

				var j = 0;
				$('.iptextmenuphu').each(function(index, el) {			
					textmenuphu[j] = $(this).val();
					j++;
				});

				j = 0;
				$('.iplinkmenuphu').each(function(index, el) {
					linkmenuphu[j] = $(this).val();
					j++;
				});

				$.ajax({
					url: 'themMenu',
					type: 'POST',
					dataType: 'json',
					data: {
						textlogo: $('.textlogo').val(),
						textmenu: $('.textmenu').val(),
						linkmenu: $('.linkmenu').val(),
						textmenuphu: textmenuphu,
						linkmenuphu: linkmenuphu
					}
				})
				.done(function() {
					console.log("success");
				})
				.fail(function() {
					console.log("error");
				})
				.always(function() {
					console.log("complete");
					$(location).attr('href', '<?php echo base_url() ?>Admin/menu');
				});
			});
			
		});
	</script>
</body>
</html>