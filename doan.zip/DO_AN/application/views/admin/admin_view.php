<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Admin - Trang chủ</title>
	
</head>
<body>
	<!-- <?php //include('menu-top.php') ?> -->

	<div class="main">
		<div class="container-fluid">
			<?php include('sidebar.php') ?>
			
			<div class="content mt-5">
				<div class="tren">
					<div class="container">
						<div class="row">
							<div class="col-3">
								<div class="doanhthu">
									<span class="icon"><i class="fas fa-dollar-sign"></i></span>
									<span class="tien"><?php echo number_format($tongdoanhthu) ?> Đ</span>
									<span class="ten">Doanh Thu</span>
								</div>
							</div>
							<div class="col-3">
								<div class="loinhuan">
									<!-- <span class="icon"><i class="far fa-money-bill-alt"></i></span>
									<span class="tien">100,000,000 Đ</span>
									<span class="ten">Lợi Nhuận</span> -->
								</div>
							</div>
							<div class="col-3">
								<div class="online">
									
								</div>
							</div>
							<div class="col-3">
								<div class="thanhvien">
									
								</div>
							</div>
						</div>
					</div> <!-- end container -->
				</div> <!-- end tren -->
					
				<div class="duoi mt-5">
					<div class="container">
						<div class="row justify-content-center">
							<div class="col-8">
								<div class="thongke">
									<div class="form-group row">
										<label for="" class="col-5">Thống kê theo từng tháng của năm: </label>
										<div class="col-3">
											<select name="" class="form-control namthongke">
												<option value="">Chọn năm</option>
												<?php $nam = date('Y') ?>
												<?php for ($i = $nam; $i >= 2000; $i--) { ?>
													<option value="<?= $i ?>"><?= $i ?></option>
												<?php } ?>
											</select>
											
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="row justify-content-end">
							<div class="col-12 noidungtable">
								<table id="tb" class="table table-striped d-none">
								  <thead>
								  	<tr class="text-center">
								  		<th colspan="13" scope="col">Thông kê trong năm 2019</th>
								  	</tr>
								    <tr>
								      <th scope="col"></th>
								      <th scope="col">Tháng 1</th>
								      <th scope="col">Tháng 2</th>
								      <th scope="col">Tháng 3</th>
								      <th scope="col">Tháng 4</th>
								      <th scope="col">Tháng 5</th>
								      <th scope="col">Tháng 6</th>
								      <th scope="col">Tháng 7</th>
								      <th scope="col">Tháng 8</th>
								      <th scope="col">Tháng 9</th>
								      <th scope="col">Tháng 10</th>
								      <th scope="col">Tháng 11</th>
								      <th scope="col">Tháng 12</th>
								    </tr>
								  </thead>
								  <tbody>
								    <tr>
								      <th scope="row">Doanh thu</th>
								      <td>0</td>
								      <td>0</td>
								      <td>0</td>
								      <td>0</td>
								      <td>0</td>
								      <td>0</td>
								      <td>0</td>
								      <td>0</td>
								      <td>0</td>
								      <td>0</td>
								      <td>0</td>
								      <td>0</td>
								    </tr>
								    <tr>
								      <th scope="row">Khách hàng</th>
								      <td>0</td>
								      <td>0</td>
								      <td>0</td>
								      <td>0</td>
								      <td>0</td>
								      <td>0</td>
								      <td>0</td>
								      <td>0</td>
								      <td>0</td>
								      <td>0</td>
								      <td>0</td>
								      <td>0</td>
								    </tr>
								    <tr>
								      <th scope="row">Đơn hàng</th>
								      <td>0</td>
								      <td>0</td>
								      <td>0</td>
								      <td>0</td>
								      <td>0</td>
								      <td>0</td>
								      <td>0</td>
								      <td>0</td>
								      <td>0</td>
								      <td>0</td>
								      <td>0</td>
								      <td>0</td>
								    </tr>
								  </tbody>
								</table>
								<div class="col-3 d-none">
									<button class="form-control btn btn-outline-secondary btnXuatfile">Xuất file excel</button>
								</div>
							</div>
						</div>
					</div> <!-- end container -->
				</div> <!-- end duoi -->
			</div><!--  end content -->

		</div>
	</div> <!-- end main -->
	<script type="text/javascript">
		$(document).ready(function() {
			$('body').on('click', '.btnXuatfile', function(event) {
				event.preventDefault();
				$("#tb").table2excel({
				    // exclude CSS class
				    exclude: ".noExl",
				    name: "Worksheet Name",
				    filename: "SomeFile", //do not include extension
				    fileext: ".xls" // file extension
			    }); 
			});

			$('.content .namthongke').change(function(event) {
				$('.noidungtable').children().remove();
				var namchon = $(this).val();
				if($(this).val() != '')
				{
					$.ajax({
						url: '<?php echo base_url() ?>Admin/thongke',
						type: 'POST',
						dataType: 'json',
						data: {
							namthongke: $(this).val()
						},
					})
					.done(function() {
						console.log("success");
					})
					.fail(function() {
						console.log("error");
					})
					.always(function(res) {
						console.log("complete");
						console.log(res['doanhthutheonam']['thang6']);
						var noidung = '';
						noidung += '<table id="tb" class="table table-striped">';
						noidung += '<thead>';
						noidung += '<tr class="text-center">';
						noidung += '<th colspan="13" scope="col">Thông kê trong năm '+ namchon +'</th>';
						noidung += '</tr>';
						noidung += '<tr>';
						noidung += '<th scope="col"></th>';
						noidung += '<th scope="col">Tháng 1</th>';
						noidung += '<th scope="col">Tháng 2</th>';
						noidung += '<th scope="col">Tháng 3</th>';
						noidung += '<th scope="col">Tháng 4</th>';
						noidung += '<th scope="col">Tháng 5</th>';
						noidung += '<th scope="col">Tháng 6</th>';
						noidung += '<th scope="col">Tháng 7</th>';
						noidung += '<th scope="col">Tháng 8</th>';
						noidung += '<th scope="col">Tháng 9</th>';
						noidung += '<th scope="col">Tháng 10</th>';
						noidung += '<th scope="col">Tháng 11</th>';
						noidung += '<th scope="col">Tháng 12</th>';
						noidung += '</tr>';
						noidung += '</thead>';
						noidung += '<tbody>';
						noidung += '<tr>';
						noidung += '<th scope="row">Doanh thu</th>';
						noidung += '<td>'+ res['doanhthutheonam']['thang1'].toLocaleString('en') +'</td>';
						noidung += '<td>'+ res['doanhthutheonam']['thang2'].toLocaleString('en') +'</td>';
						noidung += '<td>'+ res['doanhthutheonam']['thang3'].toLocaleString('en') +'</td>';
						noidung += '<td>'+ res['doanhthutheonam']['thang4'].toLocaleString('en') +'</td>';
						noidung += '<td>'+ res['doanhthutheonam']['thang5'].toLocaleString('en') +'</td>';
						noidung += '<td>'+ res['doanhthutheonam']['thang6'].toLocaleString('en') +'</td>';
						noidung += '<td>'+ res['doanhthutheonam']['thang7'].toLocaleString('en') +'</td>';
						noidung += '<td>'+ res['doanhthutheonam']['thang8'].toLocaleString('en') +'</td>';
						noidung += '<td>'+ res['doanhthutheonam']['thang9'].toLocaleString('en') +'</td>';
						noidung += '<td>'+ res['doanhthutheonam']['thang10'].toLocaleString('en') +'</td>';
						noidung += '<td>'+ res['doanhthutheonam']['thang11'].toLocaleString('en') +'</td>';
						noidung += '<td>'+ res['doanhthutheonam']['thang12'].toLocaleString('en') +'</td>';
						noidung += '</tr>';
						noidung += '<tr>';
						noidung += '<th scope="row">Khách hàng</th>';
						noidung += '<td>'+ res['khachhangtheonam']['thang1'] +'</td>';
						noidung += '<td>'+ res['khachhangtheonam']['thang2'] +'</td>';
						noidung += '<td>'+ res['khachhangtheonam']['thang3'] +'</td>';
						noidung += '<td>'+ res['khachhangtheonam']['thang4'] +'</td>';
						noidung += '<td>'+ res['khachhangtheonam']['thang5'] +'</td>';
						noidung += '<td>'+ res['khachhangtheonam']['thang6'] +'</td>';
						noidung += '<td>'+ res['khachhangtheonam']['thang7'] +'</td>';
						noidung += '<td>'+ res['khachhangtheonam']['thang8'] +'</td>';
						noidung += '<td>'+ res['khachhangtheonam']['thang9'] +'</td>';
						noidung += '<td>'+ res['khachhangtheonam']['thang10'] +'</td>';
						noidung += '<td>'+ res['khachhangtheonam']['thang11'] +'</td>';
						noidung += '<td>'+ res['khachhangtheonam']['thang12'] +'</td>';
						noidung += '</tr>';
						noidung += '<tr>';
						noidung += '<th scope="row">Đơn hàng</th>';
						noidung += '<td>'+ res['donhangtheonam']['thang1'] +'</td>';
						noidung += '<td>'+ res['donhangtheonam']['thang2'] +'</td>';
						noidung += '<td>'+ res['donhangtheonam']['thang3'] +'</td>';
						noidung += '<td>'+ res['donhangtheonam']['thang4'] +'</td>';
						noidung += '<td>'+ res['donhangtheonam']['thang5'] +'</td>';
						noidung += '<td>'+ res['donhangtheonam']['thang6'] +'</td>';
						noidung += '<td>'+ res['donhangtheonam']['thang7'] +'</td>';
						noidung += '<td>'+ res['donhangtheonam']['thang8'] +'</td>';
						noidung += '<td>'+ res['donhangtheonam']['thang9'] +'</td>';
						noidung += '<td>'+ res['donhangtheonam']['thang10'] +'</td>';
						noidung += '<td>'+ res['donhangtheonam']['thang11'] +'</td>';
						noidung += '<td>'+ res['donhangtheonam']['thang12'] +'</td>';
						noidung += '</tr>';
						noidung += '</tbody>';
						noidung += '</table>';
						noidung += '<div class="col-3">';
						noidung += '<button class="form-control btn btn-outline-secondary btnXuatfile">Xuất file excel</button>';
						noidung += '</div>';

						$('.noidungtable').append(noidung);	
					});
					
				}
			});
		});
	</script>
</body>
</html>