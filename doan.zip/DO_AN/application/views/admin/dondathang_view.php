<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Quản lý đơn đặt hàng</title>
</head>
<body>

	<div class="main">
		<div class="container-fluid">
			<?php include('sidebar.php') ?>
			
			<div class="content mt-5">
				<div class="container">
					<div class="row justify-content-end">
						<div class="col-6 col-sm-8 col-md-10 col-lg-11">
							<nav aria-label="breadcrumb">
							  <ol class="breadcrumb">
							    <li class="breadcrumb-item"><a class="active" href="#donhangchuaxacnhan">Đơn hàng chưa xác nhận</a></li>
							    <li class="breadcrumb-item"><a href="#donhangchuagiao">Đơn hàng chưa giao</a></li>
							    <li class="breadcrumb-item"><a href="#donhangchuathanhtoan">Đơn hàng chưa thanh toán</a></li>
							    <li class="breadcrumb-item"><a href="#donhangdathanhtoan">Đơn hàng đã thanh toán</a></li>
							    <li class="breadcrumb-item"><a href="#donhangdahuy">Đơn hàng đã hủy</a></li>
							  </ol>
							</nav>
						</div>
					</div>

					<div id="donhangchuaxacnhan" class="nd">
						<table class="table table-hover">
						  <thead>
						    <tr>
						      <th scope="col">Tên khách hàng</th>
						      <th scope="col">Mã DDH</th>
						      <th scope="col">Ngày đặt</th>
						      <th scope="col">Địa chỉ giao</th>
						      <th scope="col">Thành tiền</th>
						      <th scope="col"></th>
						    </tr>
						  </thead>
						  <tbody>
						  	<?php foreach ($DDHChuaxacnhan as $item): ?>
							    <tr>
							      <td><?= $item['hoten'] ?></td>
							      <td><?= $item['maddh'] ?></td>
							      <td><?= date('d/m/Y', $item['ngaydat']) ?></td>
							      <td><?= $item['diachigiao'] ?></td>
							      <td><?= number_format($item['thanhtien']) ?> đ</td>
							      <td><a href="<?php echo base_url() ?>Admin/chitietddh/<?= $item['maddh'] ?>">Xem chi tiết</a></td>
							      <td><a href="">Hủy</a></td>
							    </tr>
						    <?php endforeach ?>
						  </tbody>
						</table>
					</div> <!-- end donhangchuaxacnhan -->

					<div id="donhangchuagiao" class="d-none nd">
						<table class="table table-hover">
						  <thead>
						    <tr>
						      <th scope="col">Tên khách hàng</th>
						      <th scope="col">Mã DDH</th>
						      <th scope="col">Ngày đặt</th>
						      <th scope="col">Địa chỉ giao</th>
						      <th scope="col">Thành tiền</th>
						      <th scope="col"></th>
						    </tr>
						  </thead>
						  <tbody>
						  	<?php foreach ($DDHChuagiao as $item): ?>
							    <tr>
							      <td><?= $item['hoten'] ?></td>
							      <td><?= $item['maddh'] ?></td>
							      <td><?= date('d/m/Y', $item['ngaydat']) ?></td>
							      <td><?= $item['diachigiao'] ?></td>
							      <td><?= number_format($item['thanhtien']) ?> đ</td>
							      <td><a href="<?php echo base_url() ?>Admin/chitietddh/<?= $item['maddh'] ?>">Xem chi tiết</a></td>
							      <td><a href="">Hủy</a></td>
							    </tr>
						    <?php endforeach ?>
						  </tbody>
						</table>
					</div> <!-- end donhangchuagiao -->

					<div id="donhangchuathanhtoan" class="d-none nd">
						<table class="table table-hover">
						  <thead>
						    <tr>
						      <th scope="col">Tên khách hàng</th>
						      <th scope="col">Mã DDH</th>
						      <th scope="col">Ngày đặt</th>
						      <th scope="col">Địa chỉ giao</th>
						      <th scope="col">Thành tiền</th>
						      <th scope="col"></th>
						    </tr>
						  </thead>
						  <tbody>
						  	<?php foreach ($DDHChuathanhtoan as $item): ?>
							    <tr>
							      <td><?= $item['hoten'] ?></td>
							      <td><?= $item['maddh'] ?></td>
							      <td><?= date('d/m/Y', $item['ngaydat']) ?></td>
							      <td><?= $item['diachigiao'] ?></td>
							      <td><?= number_format($item['thanhtien']) ?> đ</td>
							      <td><a href="<?php echo base_url() ?>Admin/chitietddh/<?= $item['maddh'] ?>">Xem chi tiết</a></td>
							      <td><a href="">Hủy</a></td>
							    </tr>
						    <?php endforeach ?>
						  </tbody>
						</table>
					</div> <!-- end donhangchuathanhtoan -->

					<div id="donhangdathanhtoan" class="d-none nd">
						<table class="table table-hover">
						  <thead>
						    <tr>
						      <th scope="col">Tên khách hàng</th>
						      <th scope="col">Mã DDH</th>
						      <th scope="col">Ngày đặt</th>
						      <th scope="col">Địa chỉ giao</th>
						      <th scope="col">Thành tiền</th>
						      <th scope="col"></th>
						    </tr>
						  </thead>
						  <tbody>
						  	<?php foreach ($DDHDathanhtoan as $item): ?>
							    <tr>
							      <td><?= $item['hoten'] ?></td>
							      <td><?= $item['maddh'] ?></td>
							      <td><?= date('d/m/Y', $item['ngaydat']) ?></td>
							      <td><?= $item['diachigiao'] ?></td>
							      <td><?= number_format($item['thanhtien']) ?> đ</td>
							      <td><a href="<?php echo base_url() ?>Admin/chitietddh/<?= $item['maddh'] ?>">Xem chi tiết</a></td>
							      <td><a href="">Hủy</a></td>
							    </tr>
						    <?php endforeach ?>
						  </tbody>
						</table>
					</div> <!-- end donhangdathanhtoan -->

					<div id="donhangdahuy" class="d-none nd">
						<table class="table table-hover">
						  <thead>
						    <tr>
						      <th scope="col">Tên khách hàng</th>
						      <th scope="col">Mã DDH</th>
						      <th scope="col">Ngày đặt</th>
						      <th scope="col">Địa chỉ giao</th>
						      <th scope="col">Thành tiền</th>
						      <th scope="col"></th>
						    </tr>
						  </thead>
						  <tbody>
						  	<?php foreach ($DDHDahuy as $item): ?>
							    <tr>
							      <td><?= $item['hoten'] ?></td>
							      <td><?= $item['maddh'] ?></td>
							      <td><?= date('d/m/Y', $item['ngaydat']) ?></td>
							      <td><?= $item['diachigiao'] ?></td>
							      <td><?= number_format($item['thanhtien']) ?> đ</td>
							      <td><a href="<?php echo base_url() ?>Admin/chitietddh/<?= $item['maddh'] ?>">Xem chi tiết</a></td>
							      <td><a href="">Hủy</a></td>
							    </tr>
						    <?php endforeach ?>
						  </tbody>
						</table>
					</div> <!-- end donhangdathanhtoan -->

				</div> <!-- end container -->
			</div><!--  end content -->

		</div>
	</div> <!-- end main -->

	<script type="text/javascript">
		$(document).ready(function() {
			$('.breadcrumb li a').click(function(event) {
				event.preventDefault();
				$('.breadcrumb li a').removeClass('active');
				$(this).addClass('active');

				var id = $(this).attr('href');
				$('.nd').addClass('d-none');
				$(id).removeClass('d-none');
			});
		});
	</script>
</body>
</html>