<div class="sidebar">
				<div class="logo mt-3">
					<a href="<?php echo base_url() ?>Admin">
						<i class="fas fa-mug-hot"></i>
						<h2>COFFEE ADMIN</h2>
					</a>
				</div> <!-- end logo -->
				
				<div class="vachngan"><strong>CHỨC NĂNG</strong></div>

				<div class="chucnang">
					<ul>
						<li class="quanly page">
							<strong>Quản Lý Page</strong>
							<i class="fas fa-angle-right float-right"></i>
							<div class="popup">
								<ul>
									<li><a href="<?php echo base_url() ?>Admin/slide">Slide</a></li>
									<li><a href="<?php echo base_url() ?>Admin/menu">Menu</a></li>
									<li><a href="<?php echo base_url() ?>Admin/footer">Footer</a></li>
								</ul>
							</div>
						</li>
						<li class="quanly sanpham">
							<strong>Quản Lý Sản Phẩm</strong>
							<i class="fas fa-angle-right float-right"></i>
							<div class="popup">
								<ul>
									<li><a href="<?php echo base_url() ?>Admin/sanpham">Sản Phẩm</a></li>
									<li><a href="<?php echo base_url() ?>Admin/loaisanpham">Loại Sản Phẩm</a></li>
									<li><a href="<?php echo base_url() ?>Admin/nguyenlieu">Nguyên Liệu</a></li>
								</ul>
							</div>
						</li>
						<li class="quanly thanhvien">
							<strong>Quản Lý Thành Viên</strong>
							<i class="fas fa-angle-right float-right"></i>
							<div class="popup">
								<ul>
									<li><a href="<?php echo base_url() ?>Admin/thanhvien">Thành Viên</a></li>
									<li><a href="<?php echo base_url() ?>Admin/loaithanhvien">Loại Thành Viên</a></li>
								</ul>
							</div>
						</li>
						<li class="quanly dondathang">
							<strong>Quản Lý Đơn Hàng</strong>
							<i class="fas fa-angle-right float-right"></i>
							<div class="popup">
								<ul>
									<li><a href="<?php echo base_url() ?>Admin/dondathang">Đơn Đặt Hàng</a></li>
								</ul>
							</div>
						</li>
					</ul>
				</div> <!-- end chucnang -->
			</div> <!-- end sidebar -->	