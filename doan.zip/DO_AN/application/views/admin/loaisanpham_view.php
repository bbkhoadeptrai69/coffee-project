<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Loại sản phẩm</title>
</head>
<body>

	<div class="main">
		<div class="container-fluid">
			<?php include('sidebar.php') ?>	
			
			<div class="content mt-5">
				<div class="container">
					<div class="row">
						<div class="col-5 themloaisanpham">
							<div class="jumbotron">
								<h3 class="text-center text-uppercase">Thêm loại sản phẩm</h3>
								<fieldset class="form-group">
									<input type="text" class="form-control tenloaisp" placeholder="nhập tên loại sản phẩm">
								</fieldset>
								<div class="text-center mt-4">
									<button type="button" class="btn btn-info btnThemMoi">Thêm Mới</button>
								</div>
							</div> <!-- end jumbotron -->
						</div> <!-- end .col-4.themloaisanpham -->
						<div class="col-7 danhsachloaisanpham justify-content-center">
							<div class="jumbotron">
								<h2 class="text-center text-uppercase">Danh sách loại sản phẩm</h2>
							</div>
							<ul class="list-group ml-5 pl-5">
								<?php foreach ($dsloaisanpham as $item): ?>
								  	<li class="list-group-item">
								  		<div class="row">
								  			<div class="col-6">
								  				<h3 class="text-uppercase ml-4 ten"><?= $item['tenloaisp'] ?></h3>
								  				<input type="text" class="form-control d-none ipten" value="<?= $item['tenloaisp'] ?>">
								  			</div>
								  			<div class="col-6">
								  				<a data-id="<?= $item['id'] ?>" class="btn btn-outline-success btnLuu d-none"><i style="font-size: 30px" class="fas fa-check"></i></a>
												<a data-id="<?= $item['id'] ?>" class="btn btn-outline-warning btnSua"><i style="font-size: 30px" class="fas fa-pen-square"></i></a>
												<a data-id="<?= $item['id'] ?>" class="btn btn-outline-danger btnXoa"><i style="font-size: 30px" class="fas fa-times"></i></a>
								  			</div>
								  		</div>
									</li>
								<?php endforeach ?>
							</ul>
							
						</div> <!-- end .col-8.danhsachloaisanpham -->
					</div> <!-- end row -->
				</div>
			</div><!--  end content -->

		</div>
	</div> <!-- end main -->

	<div class="menuthongbao thanhcong thongbao bg-info">
		<p><i class="fas fa-check-circle mr-3" style="font-size: 20px"></i>Thành công</p>
	</div>

	<div class="menuthongbao thatbai thongbao bg-danger">
		<p><i class="fas fa-times-circle mr-3" style="font-size: 20px"></i>Thất Bại</p>
	</div>

	<script>
		$(document).ready(function() {
			$('.btnThemMoi').click(function(event) {
				$.ajax({
					url: 'themLoaiSanPham',
					type: 'POST',
					dataType: 'json',
					data: {
						tenloaisp: $('.tenloaisp').val()
					},
				})
				.done(function() {
					console.log("success");
				})
				.fail(function() {
					console.log("error");
				})
				.always(function(res) {
					console.log("complete");

					//thêm trên giao diện
					var noidung = '<li class="list-group-item">';
					noidung += '<div class="row">';
					noidung += '<div class="col-6">';
					noidung += '<h3 class="text-uppercase ml-4 ten">'+ $('.tenloaisp').val() +'</h3>';
					noidung += '<input type="text" class="form-control d-none ipten" value="'+ $('.tenloaisp').val() +'">';
					noidung += '</div>';
					noidung += '<div class="col-6">';
					noidung += '<a data-id="'+ res +'" class="btn btn-outline-success btnLuu d-none"><i style="font-size: 30px" class="fas fa-check"></i></a>';
					noidung += '<a data-id="'+ res +'" class="btn btn-outline-warning btnSua"><i style="font-size: 30px" class="fas fa-pen-square"></i></a>';
					noidung += '<a data-id="' + res + '" class="btn btn-outline-danger btnXoa"><i style="font-size: 30px" class="fas fa-times"></i></a>';
					noidung += '</div>';
					noidung += '</div>';
					noidung += '</li>';

					$('.list-group').append(noidung);
								  		  					
				});
				
			});

			$('body').on('click', '.btnSua', function(event) {
				event.preventDefault();
				//ẩn
				$(this).addClass('d-none'); //ẩn nút sửa
				$(this).parent().prev().children().first().addClass('d-none'); //ẩn h3 tên

				//hiện
				$(this).prev().removeClass('d-none'); //hiện nút lưu
				$(this).parent().prev().children().next().removeClass('d-none'); //hiện input
				

			});
			$('body').on('click', '.btnLuu', function(event) {
				event.preventDefault();
				//ẩn
				$(this).addClass('d-none');
				$(this).parent().prev().children().next().addClass('d-none'); //ẩn input


				//hiện
				$(this).next().removeClass('d-none'); //nút chỉnh sửa
				$(this).parent().prev().children().first().removeClass('d-none'); //h3 tên
				$(this).parent().prev().children().first().text($(this).parent().prev().children().next().val());

				//xử lý lưu
				$.ajax({
					url: 'luuLoaiSanPham',
					type: 'POST',
					dataType: 'json',
					data: {
						id: $(this).data('id'),
						tenloaisp: $(this).parent().prev().children().first().text()
					},
				})
				.done(function() {
					console.log("success");
				})
				.fail(function() {
					console.log("error");
				})
				.always(function(res) {
					console.log("complete");
					if(res)
					{
						$('.thanhcong').addClass('hienlen').one('webkitTransitionEnd', function(event) {
							$(this).addClass('matdi').one('webkitTransitionEnd', function(event) {
								$(this).removeClass('matdi').removeClass('hienlen');
							});
						});
					}
					else
					{
						$('.thatbai').addClass('hienlen').one('webkitTransitionEnd', function(event) {
							$(this).addClass('matdi').one('webkitTransitionEnd', function(event) {
								$(this).removeClass('matdi').removeClass('hienlen');
							});
						});
					}
				});
				
				
			});

			$('body').on('click', '.btnXoa', function(event) {
				event.preventDefault();
				var phantuxoa = $(this).parent().parent().parent();
				if(confirm("Bạn có chắc chắn muốn xóa loại sản phẩm này không? Hãy chắc chắn rằng không sản phẩm thuộc loại sản phẩm này"))
				{
					$.ajax({
						url: 'xoaLoaiSanPham',
						type: 'POST',
						dataType: 'json',
						data: {
							id: $(this).data('id')
						},
					})
					.done(function() {
						console.log("success");
					})
					.fail(function() {
						console.log("error");
					})
					.always(function(res) {
						console.log("complete");

						if(res)
						{
							$('.thanhcong').addClass('hienlen').one('webkitTransitionEnd', function(event) {
								$(this).addClass('matdi').one('webkitTransitionEnd', function(event) {
									$(this).removeClass('matdi').removeClass('hienlen');
								});
							});
							phantuxoa.remove();
						}
						else
						{
							$('.thatbai').addClass('hienlen').one('webkitTransitionEnd', function(event) {
								$(this).addClass('matdi').one('webkitTransitionEnd', function(event) {
									$(this).removeClass('matdi').removeClass('hienlen');
								});
							});
						}
					});
					
				}
				else
				{
					return false;
				}
			});
		});
	</script>
</body>
</html>