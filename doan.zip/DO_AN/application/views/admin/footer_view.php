<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Admin - Trang chủ</title>
</head>
<body>

	<div class="main">
		<div class="container-fluid">
			<?php include('sidebar.php') ?>
			
			<div class="content mt-5">
				<div class="container">
					<div class="row justify-content-center">
						<div class="col-7">
							<div class="jumbotron">
								<h3 class="text-center">Quản lý footer</h3>
								<div class="mt-5">
									<h5 class="text-uppercase float-left">Text logo: </h5>
									<h4 class="text-uppercase float-left ml-5 textlogo">Best coffee </h4>
									<input type="text" class="form-control d-none" value="" placeholder="nhập text logo">
									<button type="button" class="btnEdit btn btn-outline-secondary float-right mr-5"><i class="fas fa-pencil-alt"></i></button>
									<button type="button" class="btnSave btn btn-outline-success float-right mr-5 mt-1 d-none"><i class="fas fa-check"></i></button>
								</div>
								<div class="clearfix"></div>
								<hr>
								<div>
									<h5 class="text-uppercase float-left">giới thiệu: </h5>
									<p class="ml-5 float-left gioithieu">Tại The Coffee House, chúng tôi luôn trân trọng những câu chuyện và đề cao giá trị Kết nối con người</p>
									<input type="text" class="form-control d-none" value="" placeholder="nhập phần giới thiệu">
									<button type="button" class="btnEdit btn btn-outline-secondary float-right mr-5"><i class="fas fa-pencil-alt"></i></button>
									<button type="button" class="btnSave btn btn-outline-success float-right mr-5 mt-1 d-none"><i class="fas fa-check"></i></button>
								</div>
								<div class="clearfix"></div>
								<hr>
								<div>
									<h5 class="text-uppercase float-left">địa chỉ: </h5>
									<p class="ml-5 float-left diachi">114 Võ Văn Ngân, Bình Thọ, Thủ Đức, Hồ Chí Minh</p>
									<input type="text" class="form-control d-none" value="" placeholder="">
									<button type="button" class="btnEdit btn btn-outline-secondary float-right mr-5"><i class="fas fa-pencil-alt"></i></button>
									<button type="button" class="btnSave btn btn-outline-success float-right mr-5 mt-1 d-none"><i class="fas fa-check"></i></button>
								</div>
								<div class="clearfix"></div>
								<hr>
								<div>
									<h5 class="text-uppercase float-left">điện thoại: </h5>
									<p class="ml-5 float-left dienthoai">035 703 7064</p>
									<input type="text" class="form-control d-none" value="" placeholder="">
									<button type="button" class="btnEdit btn btn-outline-secondary float-right mr-5"><i class="fas fa-pencil-alt"></i></button>
									<button type="button" class="btnSave btn btn-outline-success float-right mr-5 mt-1 d-none"><i class="fas fa-check"></i></button>
								</div>
								<div class="clearfix"></div>
								<hr>
								<div>
									<h5 class="text-uppercase float-left">email: </h5>
									<p class="ml-5 float-left email">Admin@bestcoffee.com</p>
									<input type="text" class="form-control d-none" value="" placeholder="">
									<button type="button" class="btnEdit btn btn-outline-secondary float-right mr-5"><i class="fas fa-pencil-alt"></i></button>
									<button type="button" class="btnSave btn btn-outline-success float-right mr-5 mt-1 d-none"><i class="fas fa-check"></i></button>
								</div>
								<div class="clearfix"></div>
								<hr>
								<div>
									<h5 class="text-uppercase float-left">Thứ 2 - Thứ 6: </h5>
									<p class="ml-5 float-left t2-t6">8:00 am - 22:30 pm</p>
									<input type="text" class="form-control d-none" value="" placeholder="">
									<button type="button" class="btnEdit btn btn-outline-secondary float-right mr-5"><i class="fas fa-pencil-alt"></i></button>
									<button type="button" class="btnSave btn btn-outline-success float-right mr-5 mt-1 d-none"><i class="fas fa-check"></i></button>
								</div>
								<div class="clearfix"></div>
								<hr>
								<div>
									<h5 class="text-uppercase float-left">Thứ 7: </h5>
									<p class="ml-5 float-left t7">8:00 am - 21:30 pm</p>
									<input type="text" class="form-control d-none" value="" placeholder="">
									<button type="button" class="btnEdit btn btn-outline-secondary float-right mr-5"><i class="fas fa-pencil-alt"></i></button>
									<button type="button" class="btnSave btn btn-outline-success float-right mr-5 mt-1 d-none"><i class="fas fa-check"></i></button>
								</div>
								<div class="clearfix"></div>
								<hr>
								<div>
									<h5 class="text-uppercase float-left">Chủ Nhật: </h5>
									<p class="ml-5 float-left cn">7:00 am - 22:30 pm</p>
									<input type="text" class="form-control d-none" value="" placeholder="">
									<button type="button" class="btnEdit btn btn-outline-secondary float-right mr-5"><i class="fas fa-pencil-alt"></i></button>
									<button type="button" class="btnSave btn btn-outline-success float-right mr-5 mt-1 d-none"><i class="fas fa-check"></i></button>
								</div>
								<div class="clearfix"></div>
								<hr>
							</div>
						</div>
					</div>
				</div>
			</div><!--  end content -->

		</div>
	</div> <!-- end main -->
	
	<div class="footerthongbao thongbao bg-info">
		<p><i class="fas fa-check-circle mr-3" style="font-size: 20px"></i>Thành công</p>
	</div>
	<script>
		$(document).ready(function() {
			//click button chỉnh sửa
			$('.btnEdit').click(function(event) {
				//ẩn
				$(this).addClass('d-none'); //ẩn nút chỉnh sửa
				$(this).prev().prev().addClass('d-none'); //ẩn nội dung
				$(this).prev().prev().prev().addClass('d-none'); //ẩn label

				//hiện
				$(this).next().removeClass('d-none'); //hiện nút lưu
				$(this).prev().removeClass('d-none').val($(this).prev().prev().text()); //hiện input và tự động lấy nội dung

			});

			//click button lưu
			$('.btnSave').click(function(event) {
				//ẩn
				$(this).addClass('d-none'); //ẩn nút lưu
				$(this).prev().prev().addClass('d-none'); //ẩn ôn input

				//hiện
				$(this).prev().prev().prev().prev().removeClass('d-none'); //hiện nhãn
				$(this).prev().prev().prev().removeClass('d-none').text($(this).prev().prev().val()); //hiện nội dung và lấy val() ở input
				$(this).prev().removeClass('d-none'); //hiện nút chỉnh sửa

				//hiệu ứng thành công
				$('.footerthongbao').addClass('hienlen').one('webkitTransitionEnd', function(event) {
					$(this).addClass('matdi');
					$(this).removeClass('hienlen').one('webkitTransitionEnd', function(event) {
						$(this).removeClass('matdi').removeClass('hienlen');
					});
				});

				//hiệu ứng thất bại

			
				$.ajax({
					url: 'updateFooter',
					type: 'POST',
					dataType: 'json',
					data: {
						textlogo: $('.textlogo').text(),
						gioithieu: $('.gioithieu').text(),
						diachi: $('.diachi').text(),
						dienthoai: $('.dienthoai').text(),
						email: $('.email').text(),
						t2_t6: $('.t2-t6').text(),
						t7: $('.t7').text(),
						cn: $('.cn').text()
					},
				})
				.done(function() {
					console.log("success");
				})
				.fail(function() {
					console.log("error");
				})
				.always(function() {
					console.log("complete");
				});
				
			});


		});
	</script>
</body>
</html>