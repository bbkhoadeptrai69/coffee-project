<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Danh sách slide</title>
</head>
<body>
	<div id="thongbaothanhcong" class="alert alert-success text-center" style="display: none">
		Thành công
	</div>
	<div id="thongbaothatbai" class="alert alert-danger text-center" style="display: none">
		Thất bại
	</div>

	<div class="main">
		<div class="container-fluid">
			<?php include('sidebar.php') ?>	
			
			<div class="content mt-5">
				<div class="quanlyslide">
					<div class="container">
						<div class="row">
							<div class="col-4 themmoislide">
								<div class="jumbotron">
									<h3 class="text-center">Thêm mới slide</h3>
									<fieldset class="form-group">
										<label for="">Tiêu đề 1</label>
										<input type="input" class="form-control tieude1">
									</fieldset>
									<fieldset class="form-group">
										<label for="">Tiêu đề 2</label>
										<input type="input" name="" class="form-control tieude2">
									</fieldset>
									<fieldset class="form-group">
										<label for="">Ảnh</label>
										<input id="file" type="file" class="form-control">
									</fieldset>
									<fieldset class="form-group">
										<label for="">Mô tả</label>
										<textarea class="form-control mota" rows="5" placeholder="Nhập mô tả ..."></textarea>
									</fieldset>
									<div class="chucnang text-center">
										<button type="button" class="btn btn-success btnThemMoi">Thêm mới</button>
									</div>
								</div> <!-- end jumbotron -->
							</div> <!-- end col-4.themmoislide -->

							<div class="col-8 danhsachslide">
								<div class="row">
									<div class="col-12">
										<div class="jumbotron">
											<h2 class="text-center text-uppercase">Danh sách slide</h2>
										</div>
									</div>
								</div>
								<div class="row">
									<?php $i = 0; ?>
									<?php if (!is_null($slide)): ?>
										<?php foreach ($slide as $item): ?>
											<?php $i++; ?>
											<div class="col-6 slideitem">
												<div class="jumbotron">
													<h3 class="text-center">Quản lý slide thứ <?= $i ?></h3>
													<fieldset class="form-group">
														<label for="">Tiêu đề 1</label>
														<input type="input" name="" class="form-control txttieude1" value="<?= $item['tieude1'] ?>">
													</fieldset>
													<fieldset class="form-group">
														<label for="">Tiêu đề 2</label>
														<input type="input" name="" class="form-control txttieude2" value="<?= $item['tieude2'] ?>">
													</fieldset>
													<fieldset class="form-group">
														<label for="">Ảnh</label>
														<img class="txtanh" style="width: 300px; height: 70px" src="<?= $item['anh'] ?>" alt="">
														<input id="anhmoi" type="file" name="" class="form-control-file">
													</fieldset>
													<fieldset class="form-group">
														<label for="">Mô tả</label>
														<textarea class="form-control txtmota" rows="5"><?= $item['mota'] ?></textarea>
													</fieldset>
													<div class="chucnang text-center">
														<button type="button" class="btn btn-success btnLuu"><i class="fas fa-check"></i></button>
														<button type="button" class="btn btn-danger btnXoa"><i class="fas fa-times"></i></button>
													</div>
												</div> <!-- end jumbotron -->
											</div> <!-- end slideitem -->
										<?php endforeach ?>
									<?php else: ?>
										<p class="thongbaotrong">Danh sách trống</p>
									<?php endif ?>
								</div>
							</div> <!-- end danhsachslide -->
						</div>
					</div>
				</div> <!-- end quanlyslide -->
			</div> <!-- end content -->

		</div>
	</div> <!-- end main -->

	<script>
		$(document).ready(function() {
			$('.btnThemMoi').click(function(event) {
				$('.thongbaotrong').remove();
				<?php $i++; ?>

				//Lấy ra files
      			var file_data = $('#file').prop('files')[0];
      			//lấy ra kiểu file
        		var type = file_data.type;
        		var match = ["image/gif", "image/png", "image/jpg", "image/jpeg"];

        		if (type == match[0] || type == match[1] || type == match[2] || type == match[3]) {
        			//khởi tạo đối tượng form data
		            var form_data = new FormData();
		            //thêm files vào trong form data
		            form_data.append('anh', file_data);


		            form_data.append('tieude1', $('.tieude1').val());
		            form_data.append('tieude2', $('.tieude2').val());
		            form_data.append('mota', $('.mota').val());
		            //sử dụng ajax post


		            $.ajax({
		                url: 'themSlide',
		                dataType: 'json',
		                cache: false,
		                contentType: false,
		                processData: false,
		                data: form_data,
		                type: 'post'
		            })
		            .done(function() {
		            	console.log("success");
		                
		            })
		            .fail(function() {
		            	console.log("error");
		            })
		            .always(function(res) {
		            	console.log("complete");
		            	
		                if(res.stt == true){
		                	$('#thongbaothanhcong').slideDown(500).delay(2000).slideUp(400);
		                }
		                else{
		                	$('#thongbaothatbai').slideDown(500).delay(2000).slideUp(400);
		                }

		                //thêm nội dung slide
		                var noidung = '<div class="col-6 slideitem">'
		                noidung += '<div class="jumbotron">';
		                noidung += '<h3 class="text-center">Quản lý slide thứ <?= $i ?></h3>';
		                noidung += '<fieldset class="form-group">';
		                noidung += '	<label for="">Tiêu đề 1</label>';
		                noidung += '	<input type="input" name="" class="form-control txttieude1" value="'+ $('.tieude1').val() +'">';
		                noidung += '</fieldset>';
		                noidung += '<fieldset class="form-group">';
		                noidung += '	<label for="">Tiêu đề 2</label>';
		                noidung += '	<input type="input" name="" class="form-control txttieude2" value="'+ $('.tieude2').val() +'">';
		                noidung += '</fieldset>';
		                noidung += '<fieldset class="form-group">';
		                noidung += '	<label for="">Ảnh</label>';
		                noidung += '	<img class="txtanh" style="width: 300px; height: 70px" src="'+res.anh+'" alt="">';
		                noidung += '	<input type="file" name="" class="form-control-file ">';
		                noidung += '</fieldset>';
		                noidung += '<fieldset class="form-group">';
		                noidung += '	<label for="">Mô tả</label>';
		                noidung += '	<textarea class="form-control txtmota" rows="5">'+ $('.mota').val() +'</textarea>';
		                noidung += '</fieldset>';
		                noidung += '<div class="chucnang text-center">';
		                noidung += '	<button type="button" class="btn btn-success btnLuu"><i class="fas fa-check"></i></button>';
		                noidung += '	<button type="button" class="btn btn-danger btnXoa"><i class="fas fa-times"></i></button>';
		                noidung += '</div>';
		                noidung += '</div> <!-- end jumbotron -->';
		                noidung += '</div>';
		                
		                $('.danhsachslide').children().next().append(noidung);	






		                //cập nhật lại các ô text	
													
		            });
				}	
			});

			$('body').on('click', '.btnLuu', function(event) {
				event.preventDefault();
				var tieude1 = [];
				var tieude2 = [];
				var anh = [];
				var mota = [];
				//console.log(arr[0]);
				var i = 0;
				$('.txttieude1').each(function(index, el) {
					tieude1[i] = $(this).val();	
					i++;  
				});
				i = 0;
				$('.txttieude2').each(function(index, el) {
					tieude2[i] = $(this).val();
					i++;
				});
				i = 0;
				
				$('.txtanh').each(function(index, el) {
					anh[i] = $(this).attr('src');
					i++;
				});
				i = 0;
				$('.txtmota').each(function(index, el) {
					mota[i] = $(this).val();
					i++;
				});
				
				$.ajax({
					url: 'luuSlide',
					type: 'POST',
					dataType: 'json',
					data: {
						tieude1: tieude1,
						tieude2: tieude2,
						anh: anh,
						mota: mota
					},
				})
				.done(function() {
					console.log("success");
				})
				.fail(function() {
					console.log("error");
				})
				.always(function(res) {
					console.log("complete");
					$('html').animate({scrollTop: 0}, 500);

					if(res.stt == true){
	                	$('#thongbaothanhcong').slideDown(1000).delay(2000).slideUp(400);
	                }
	                else{
	                	$('#thongbaothatbai').slideDown(1000).delay(2000).slideUp(400);
	                }
				});
				
			});

			$('body').on('click', '.btnXoa', function(event) {
				event.preventDefault();
				$(this).parent().parent().parent().remove();
				
				if($('.btnLuu').length != 0){
					$('.btnLuu').trigger('click');

				}
				else{
					$.ajax({
						url: 'luuSlide',
						type: 'POST',
						dataType: 'json',
						data: {
							tieude1: '',
							tieude2: '',
							anh: '',
							mota: ''
						},
					})
					.done(function() {
						console.log("success");
					})
					.fail(function() {
						console.log("error");
					})
					.always(function(res) {
						console.log("complete");
						$('html').animate({scrollTop: 0}, 500);

						if(res.stt == true){
		                	$('#thongbaothanhcong').slideDown(1000).delay(2000).slideUp(400);
		                }
		                else{
		                	$('#thongbaothatbai').slideDown(1000).delay(2000).slideUp(400);
		                }
					});
				}
				
			});
		});
	</script>
</body>
</html>