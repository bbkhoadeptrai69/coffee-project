<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Quản lý loại thành viên</title>
</head>
<body>
	<div class="main">
		<div class="container-fluid">
			<?php include('sidebar.php') ?>	
			
			<div class="content mt-5">
				<div class="container">
					<div class="row">
						<div class="col-5 themloaithanhvien">
							<div class="jumbotron">
								<h3 class="text-center text-uppercase">Thêm loại thành viên</h3>
								<fieldset class="form-group">
									<label for="">Mã loại thành viên</label>
									<input type="text" class="form-control id" placeholder="chucuahang">
								</fieldset>
								<fieldset class="form-group">
									<label for="">Tên loại thành viên</label>
									<input type="text" class="form-control tenloaitv" placeholder="chủ cửa hàng">
								</fieldset>
								<div class="text-center mt-4">
									<button type="button" class="btn btn-info btnThemMoi">Thêm Mới</button>
								</div>
							</div> <!-- end jumbotron -->
						</div> <!-- end .col-4.themloaisanpham -->
						<div class="col-7 danhsachloaithanhvien justify-content-center">
							<div class="jumbotron">
								<h2 class="text-center text-uppercase">Danh sách loại thành viên</h2>
							</div>
							<ul class="list-group">
								<?php foreach ($dsloaithanhvien as $item): ?>
								  	<li class="list-group-item">
								  		<div class="row">
								  			<div class="col-4">
								  				<h5 class="text-uppercase ml-4 id"><?= $item['id'] ?></h5>
								  				<input type="text" class="form-control d-none ipid" value="<?= $item['id'] ?>">
								  			</div>
								  			<div class="col-4">
								  				<h5 class="text-uppercase ml-4 ten"><?= $item['tenloaitv'] ?></h5>
								  				<input type="text" class="form-control d-none ipten" value="<?= $item['tenloaitv'] ?>">
								  			</div>
								  			<div class="col-4 text-right">
								  				<a data-id="<?= $item['id'] ?>" class="btn btn-outline-success btnLuu d-none"><i style="font-size: 30px" class="fas fa-check"></i></a>
												<a data-id="<?= $item['id'] ?>" class="btn btn-outline-warning btnSua"><i style="font-size: 30px" class="fas fa-pen-square"></i></a>
												<a data-id="<?= $item['id'] ?>" class="btn btn-outline-danger btnXoa"><i style="font-size: 30px" class="fas fa-times"></i></a>
								  			</div>
								  		</div>
									</li>
								<?php endforeach ?>
							</ul>
							
						</div> <!-- end .col-8.danhsachloaisanpham -->
					</div> <!-- end row -->
				</div>
			</div><!--  end content -->

		</div>
	</div> <!-- end main -->

	<div class="menuthongbao thanhcong thongbao bg-info">
		<p><i class="fas fa-check-circle mr-3" style="font-size: 20px"></i>Thành công</p>
	</div>

	<div class="menuthongbao thatbai thongbao bg-danger">
		<p><i class="fas fa-times-circle mr-3" style="font-size: 20px"></i>Thất Bại</p>
	</div>

	<script>
		$(document).ready(function() {
			$('.btnThemMoi').click(function(event) {
				$.ajax({
					url: 'themLoaiThanhVien',
					type: 'POST',
					dataType: 'json',
					data: {
						tenloaitv: $('.tenloaitv').val()
					},
				})
				.done(function() {
					console.log("success");
				})
				.fail(function() {
					console.log("error");
				})
				.always(function(res) {
					console.log("complete");
					
								  				
								  				
								  			
					//thêm trên giao diện
					var noidung = '<li class="list-group-item">';
					noidung += '<div class="row">';
					noidung += '<div class="col-4">';
					noidung += '<h5 class="text-uppercase ml-4 id">'+ $('.id').val() +'</h5>';
					noidung += '<input type="text" class="form-control d-none ipid" value="<?= $item['id'] ?>">';
					noidung += '</div>';
					noidung += '<div class="col-4">';
					noidung += '<h5 class="text-uppercase ml-4 ten">'+ $('.tenloaitv').val() +'</h5>';
					noidung += '<input type="text" class="form-control d-none ipten" value="'+ $('.tenloaitv').val() +'">';
					noidung += '</div>';
					noidung += '<div class="col-4 text-right">';
					noidung += '<a data-id="'+ res +'" class="btn btn-outline-success btnLuu d-none"><i style="font-size: 30px" class="fas fa-check"></i></a>';
					noidung += '<a data-id="'+ res +'" class="btn btn-outline-warning btnSua"><i style="font-size: 30px" class="fas fa-pen-square"></i></a>';
					noidung += '<a data-id="' + res + '" class="btn btn-outline-danger btnXoa"><i style="font-size: 30px" class="fas fa-times"></i></a>';
					noidung += '</div>';
					noidung += '</div>';
					noidung += '</li>';

					$('.list-group').append(noidung);
								  		  					
				});
				
			});

			$('body').on('click', '.btnSua', function(event) {
				event.preventDefault();
				//ẩn
				$(this).addClass('d-none'); //ẩn nút sửa
				$(this).parent().prev().children().first().addClass('d-none'); //ẩn h5 tên
				$(this).parent().prev().prev().children().first().addClass('d-none'); //ẩn h5 mã

				//hiện
				$(this).prev().removeClass('d-none'); //hiện nút lưu
				$(this).parent().prev().children().next().removeClass('d-none'); //hiện input
				$(this).parent().prev().prev().children().next().removeClass('d-none'); // hiện input

			});

			$('body').on('click', '.btnLuu', function(event) {
				event.preventDefault();
				//ẩn
				$(this).addClass('d-none');
				$(this).parent().prev().children().next().addClass('d-none'); //ẩn input
				$(this).parent().prev().prev().children().next().addClass('d-none');

				//hiện
				$(this).next().removeClass('d-none'); //nút chỉnh sửa
				$(this).parent().prev().children().first().removeClass('d-none'); //h3 tên
				$(this).parent().prev().prev().children().first().removeClass('d-none'); //h3 mã
				$(this).parent().prev().children().first().text($(this).parent().prev().children().next().val());
				$(this).parent().prev().prev().children().first().text($(this).parent().prev().prev().children().next().val());

				//xử lý lưu
				$.ajax({
					url: 'luuLoaiThanhVien',
					type: 'POST',
					dataType: 'json',
					data: {
						idcu: $(this).data('id'),
						idmoi: $(this).parent().prev().prev().children().first().text(),
						tenloaitv: $(this).parent().prev().children().first().text()
					},
				})
				.done(function() {
					console.log("success");
				})
				.fail(function() {
					console.log("error");
				})
				.always(function(res) {
					console.log("complete");
					if(res)
					{
						$('.thanhcong').addClass('hienlen').one('webkitTransitionEnd', function(event) {
							$(this).addClass('matdi').one('webkitTransitionEnd', function(event) {
								$(this).removeClass('matdi').removeClass('hienlen');
							});
						});
					}
					else
					{
						$('.thatbai').addClass('hienlen').one('webkitTransitionEnd', function(event) {
							$(this).addClass('matdi').one('webkitTransitionEnd', function(event) {
								$(this).removeClass('matdi').removeClass('hienlen');
							});
						});
					}
				});
				
				
			});

			$('body').on('click', '.btnXoa', function(event) {
				event.preventDefault();
				var phantuxoa = $(this).parent().parent().parent();
				if(confirm("Bạn có chắc chắn muốn xóa loại sản phẩm này không? Hãy chắc chắn rằng không thành viên nào thuộc loại thành viên này"))
				{
					$.ajax({
						url: 'xoaLoaiThanhVien',
						type: 'POST',
						dataType: 'json',
						data: {
							id: $(this).data('id')
						},
					})
					.done(function() {
						console.log("success");
					})
					.fail(function() {
						console.log("error");
					})
					.always(function(res) {
						console.log("complete");

						if(res)
						{
							$('.thanhcong').addClass('hienlen').one('webkitTransitionEnd', function(event) {
								$(this).addClass('matdi').one('webkitTransitionEnd', function(event) {
									$(this).removeClass('matdi').removeClass('hienlen');
								});
							});
							phantuxoa.remove();
						}
						else
						{
							$('.thatbai').addClass('hienlen').one('webkitTransitionEnd', function(event) {
								$(this).addClass('matdi').one('webkitTransitionEnd', function(event) {
									$(this).removeClass('matdi').removeClass('hienlen');
								});
							});
						}
					});
					
				}
				else
				{
					return false;
				}
			});
		});
	</script>
</body>
</html>