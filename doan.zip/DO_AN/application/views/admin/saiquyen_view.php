<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Error</title>
</head>
<body>

	<h1>Xin lỗi. Có lẽ đây là nơi bạn không nên đến. Mời bạn <a href="<?php echo base_url() ?>">quay lại</a></h1>
</body>
</html>
