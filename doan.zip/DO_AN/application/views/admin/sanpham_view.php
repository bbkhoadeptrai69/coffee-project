<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Quản lý sản phẩm</title>
</head>
<body>

	<div class="main">
		<div class="container-fluid">
			<?php include('sidebar.php') ?>
			
			<div class="content mt-5">
				<div class="sanpham">
					<div class="container">
						<div class="row">
							<div class="col-4 themsanpham">
								<div class="jumbotron">
									<h3 class="text-center text-uppercase">Thêm mới sản phẩm</h3>
									<fieldset class="form-group">
										<label for="">Tên sản phẩm</label>
										<input type="text" class="form-control tensp" placeholder="nhập tên sản phẩm">
										<div class="valid vltensp text-danger"></div>
									</fieldset>
									<fieldset class="form-group">
										<label for="">Đơn giá</label>
										<input type="number" class="form-control gia" placeholder="nhập giá sản phẩm" value="0">
									</fieldset>
									<fieldset class="form-group">
										<label for="">Số lượng </label>
										<input type="number" class="form-control soluongton" placeholder="nhập số lượng" value="0">
									</fieldset>
									<fieldset class="form-group">
										<label for="">Mô tả</label>
										<textarea placeholder="Nhập mô tả sản phẩm ...." class="form-control mota" rows="5"></textarea>
									</fieldset>
									<fieldset class="form-group">
										<label for="">Hình Ảnh</label>
										<input id="file" type="file" name="hinhanh" class="form-control-file">
										<div class="validation"></div>
									</fieldset>
									<fieldset class="form-group">
										<label for="">Loại sản phẩm</label>
										<select name="" id="maloaisp" class="form-control">
											<?php foreach ($loaisanpham as $item): ?>
												<option class="text-uppercase" value="<?= $item['id'] ?>"><?= $item['tenloaisp'] ?></option>
											<?php endforeach ?>
										</select>
									</fieldset>
									<div class="form-check">
									  <input class="form-check-input noibat" type="checkbox" value="true" id="" name="noibat">
									  <label class="form-check-label" for="">Nổi Bật</label>
									</div>
									<div class="text-center mt-4">
										<button type="button" class="btnThemMoi btn btn-outline-info">Thêm Mới</button>
									</div>
								</div> <!-- end jumbotron -->
							</div> <!-- end themsanpham -->
							<div class="col-8 danhsachsanpham">
								<div class="jumbotron">
									<h2 class="text-center text-uppercase">Danh sách sản phẩm</h2>
								</div>
								<div class="table-responsive">
									<table class="table table-striped table-dark">
									  <thead>
									    <tr>
									      <th scope="col">Id</th>
									      <th scope="col">Tên Sản phẩm</th>
									      <th scope="col">Đơn Giá</th>
									      <th scope="col">Số lượng tồn</th>
									      <th scope="col">Hình Ảnh</th>
									      <th scope="col">Loại Sản Phẩm</th>
									      <th></th>
									    </tr>
									  </thead>
									  <tbody>
									  	<?php foreach ($dssanpham as $item): ?>
										    <tr>
										      <th scope="row"><?= $item['masp'] ?></th>
										      <td class="text-uppercase"><?= $item['tensp'] ?></td>
										      <td class="text-uppercase"><?= number_format($item['gia']) ?> đ</td>
										      <td class="text-uppercase"><?= $item['soluongton'] ?></td>
										      <td class="text-uppercase text-center"><img src="<?= $item['hinhanh'] ?>" class="img-50" alt=""></td>
										      <td class="text-uppercase"><?= $item['tenloaisp'] ?></td>
										      <td>
										      	<a data-masp="<?= $item['masp'] ?>" href="" class="btnEdit btn btn-outline-warning"><i class="fas fa-pen"></i></a>
										      	<a data-masp="<?= $item['masp'] ?>" href="" class="btnDelete btn btn-outline-danger"><i class="fas fa-times"></i></a>
										      </td>
										    </tr>
									    <?php endforeach ?>
									  </tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>	

		</div>
	</div> <!-- end main -->

	<div class="menuthongbao thanhcong thongbao bg-info">
		<p><i class="fas fa-check-circle mr-3" style="font-size: 20px"></i>Thành công</p>
	</div>

	<div class="menuthongbao thatbai thongbao bg-danger">
		<p><i class="fas fa-times-circle mr-3" style="font-size: 20px"></i>Thất Bại</p>
	</div>

	<script>
		$(document).ready(function(){
			//xử lý khi click vào nút xóa
			$('body').on('click', '.btnDelete', function(event) {
				event.preventDefault();

				if(confirm("Bạn có chắc chắn muốn xóa sản phẩm này không?")){
					event.preventDefault();
		       	 	// $(".btnXoa").attr("href", "<?php //echo base_url() ?>/Admin/xoa");

		       	 	//sử dụng ajax để xóa ở đây
		       	 	$.ajax({
		       	 		url: 'xoaSanPham',
		       	 		type: 'POST',
		       	 		dataType: 'json',
		       	 		data: {masp : $(this).data('masp')}
		       	 	})
		       	 	.done(function() {
		       	 		console.log("success");
		       	 	})
		       	 	.fail(function() {
		       	 		console.log("error");
		       	 	})
		       	 	.always(function(res) {
		       	 		console.log("complete");
		       	 		if(res){
		       	 			$('.thanhcong').addClass('hienlen').one('webkitTransitionEnd', function(event) {
		       	 				$(this).addClass('matdi').one('webkitTransitionEnd', function(event) {
		       	 					$(this).removeClass('hienlen').removeClass('matdi');
		       	 				});
		       	 			});	
		       	 		}
		       	 		else{
		       	 			$('.thatbai').addClass('hienlen').one('webkitTransitionEnd', function(event) {
		       	 				$(this).addClass('matdi').one('webkitTransitionEnd', function(event) {
		       	 					$(this).removeClass('hienlen').removeClass('matdi');
		       	 				});
		       	 			});	
		       	 		}
		       	 	});
		       	 	

		       	 	//xóa trên giao diện
		       	 	$(this).parent().parent().remove();
			    }
			    else{
			        return false;
			    }
			});
			
			//xử lý sự kiện khi click vào nút chỉnh sửa
			$('body').on('click', '.btnEdit', function(event) {
				event.preventDefault();
				$(location).attr('href', '<?php echo base_url() ?>Admin/chinhSuaSanPham/'+ $(this).data('masp') +'');
			});

			//xử lý khi click vào nút THÊM MỚI
			$('.btnThemMoi').click(function(event) {
				//kiểm tra checkbox cách 1
				// if($('input[name="noibat"]:checked').length > 0)
				// 	console.log($('.noibat').val());
				$('.valid').text('');
				if($('.tensp').val() == '')
				{
					$('.vltensp').text('không bỏ trống tên sản phẩm');
					$('.tensp').focus();
				}
				else
				{
					//lấy file
					var file_data = $('#file').prop('files')[0];
					if(file_data != null)
					{
						console.log(file_data);
						//lấy kiểu file
						var type = file_data.type;
						var match = ["image/gif", "image/png", "image/jpg", "image/jpeg"];
						if (type == match[0] || type == match[1] || type == match[2] || type == match[3]) {

							//khởi tạo đối tượng form data
				            var form_data = new FormData();

				             //thêm files vào trong form data
				            form_data.append('hinhanh', file_data);
				            form_data.append('tensp', $('.tensp').val());
				            form_data.append('gia', $('.gia').val());
				            form_data.append('mota', $('.mota').val());
				            form_data.append('maloaisp', $('#maloaisp').val());
				            form_data.append('soluongton', $('.soluongton').val());
				            //kiểm tra checkbox cách 2
							if($('.noibat').is(':checked'))
								form_data.append('noibat', true);
							else
								form_data.append('noibat', false);
						}

						$.ajax({
							url: 'themSanPham',
							type: 'POST',
							dataType: 'json',
							cache: false,
			                contentType: false,
			                processData: false,
							data: form_data
						})
						.done(function() {
							console.log("success");
						})
						.fail(function() {
							console.log("error");
						})
						.always(function(res) {
							console.log("complete");

							//thêm vào bên danh sách sản phẩm
							var noidung = '<tr>';
							noidung += '<th scope="row">'+res.id+'</th>';
							noidung += '<td class="text-uppercase">'+ $('.tensp').val() +'</td>';
							noidung += '<td class="text-uppercase">' + res['gia'].toLocaleString('en') + ' đ</td>';
							noidung += '<td class="text-uppercase">' + $('.soluongton').val() + '</td>';
							noidung += ' <td class="text-uppercase text-center"><img src="'+ res.hinhanh  +'" class="img-50" alt=""></td>';
							noidung += '<td class="text-uppercase">'+ res.tenloaisp+'</td>';
							noidung += '<td>';
							noidung += '<a href="" class="btnEdit btn btn-outline-warning"><i class="fas fa-pen"></i></a>';
							noidung += '<a data-masp="'+ res.id +'" href="" class="btnDelete btn btn-outline-danger"><i class="fas fa-times"></i></a>';
							noidung += '</td>';
							noidung += '</tr>';
							$('tbody').append(noidung);


							//cập nhật các ô input thành trống
							$('#file').val('');
							$('.tensp').val('');
							$('.gia').val('');
							$('.mota').val('');
						});
					}
					else
					{
						$('.validation').append('<p class="text-danger">Vui lòng chọn hình ảnh sản phẩm</p>');	
					}
				}	
			});
		});
		
	</script>
</body>
</html>