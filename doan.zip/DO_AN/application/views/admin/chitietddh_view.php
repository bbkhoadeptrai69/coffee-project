<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Chi tiết đơn hàng</title>
</head>
<body>
	<div class="main">
		<div class="container-fluid">
			<?php include('sidebar.php') ?>
			
			<div class="content mt-5">
				<div class="container">
					<div class="row">
						<div class="col-8">
							<?php foreach ($dschitietDDH as $item): ?>
								<div class="motdonhang mb-3">
									<div class="row justify-content-center pt-3">
										<div class="col-12">
											<hr>
											<div class="row">
												<div class="col-3">
													<img class="img-fluid anhsp" src="<?= $item['hinhanh'] ?>" alt="">
												</div>
												<div class="col-6">
													<a href="" class="tensp text-uppercase"><?= $item['tensp'] ?></a>
													<p class="giasp"><?= number_format($item['gia']) ?> đ</p>
													<p class="soluong">số lượng: <?= $item['soluong'] ?></p>
													<p>Đơn giá: <?= number_format($item['dongia']) ?> đ</p>
												</div>
												<div class="col-3">
													<p>Tình trạng</p>
													<?php if (($item['matinhtrang'] == 'dathanhtoan') || ($item['matinhtrang'] == 'dahuy')) : ?>
														<p><?php echo $item['tentinhtrang'] ?></p>
													<?php else: ?>
														<select name="" class="form-control matinhtrang">
															<?php foreach ($dstinhtrang as $value): ?>
																<?php if ($value['matinhtrang'] == $item['matinhtrang']): ?>
																	<option selected value="<?= $value['matinhtrang'] ?>"><?= $value['tentinhtrang'] ?></option>
																<?php else: ?>
																	<option value="<?= $value['matinhtrang'] ?>"><?= $value['tentinhtrang'] ?></option>
																<?php endif ?>
															<?php endforeach ?>
														</select>

														<button data-masp="<?= $item['masp'] ?>" data-machitietddh="<?= $item['machitietddh'] ?>" class="btn btn-secondary form-control mt-4 btnDuyet">Duyệt</button>
													<?php endif ?>
												</div>
											</div>
										</div>							
									</div>
								</div> <!-- end motdonhang -->
							<?php endforeach ?>
						</div>
					</div>

					<a href="<?php echo base_url() ?>Admin/dondathang"><< quay lại danh sách đơn hàng</a>
				</div>
			</div><!--  end content -->

		</div>
	</div> <!-- end main -->

	<script type="text/javascript">
		$(document).ready(function() {
			$('.btnDuyet').click(function(event) {
				$machitietddh = $(this).data('machitietddh');
				$masp = $(this).data('masp');

				$.ajax({
					url: '<?php echo base_url() ?>/Admin/duyetdonhang',
					type: 'POST',
					dataType: 'json',
					data: {
						machitietddh: $machitietddh,
						matinhtrang: $('.matinhtrang').val(),
						masp: $masp
					},
				})
				.done(function() {
					console.log("success");
				})
				.fail(function() {
					console.log("error");
				})
				.always(function(res) {
					console.log("complete");
					location.reload();
				});
				
			});
		});
	</script>
</body>
</html>