<?php include('addLib.php') ?>

<div class="menu-top">
	<div class="container">
		<div class="row">
			<div class="col-6">
				<div class="trai">
					<ul>
						<li class="icon-bar icon">
							<span class="layer1"><a href=""><i class="fas fa-bars btnbar"></i></a></span>
							<span class="layer2"></span>
						</li>
						<!-- <li class="icon-sms icon">
							<span class="layer1"><a href=""><i class="fas fa-envelope"></i></a></span>
							<span class="layer2"></span>
							<span class="thongbaonho">1</span>
						</li> -->
						<li class="icon-info icon">
							<span class="layer1"><a href="" class="tb"><i class="fas fa-bell"></i></a></span>
							<span class="layer2"></span>
							<?php if (count($dsDDHChuaxacnhan) > 0): ?>
								<span class="thongbaonho"><?php echo count($dsDDHChuaxacnhan) ?></span>
								<div style="display: none" class="popup-thongbao p-2">
									<p>Bạn có <span class="text-danger"><?php echo count($dsDDHChuaxacnhan) ?></span> đơn hàng chưa xác nhận. <a href="<?php echo base_url() ?>Admin/dondathang">Xác nhận ngay</a> không bỏ lỡ</p>
								</div>
							<?php endif ?>
						</li>
					</ul>
				</div> <!-- end trai -->
			</div> <!-- end col-sm-6 -->
			<div class="col-6">
				<div class="phai">
					<ul>
						<li class="search">
							<input type="text">
							<i class="fas fa-search"></i>
						</li>
						<li class="user">
							<div class="anh"><img src="" alt=""></div>
							<span class="ten">Admin Name</span>
							<div class="muiten">
								<i class="fas fa-angle-down"></i>
								<div class="popup">
									<a href="">aa</a>
									<a href="">bbb</a>
								</div>
							</div>
						</li>
					</ul>
				</div>
			</div> <!-- end col-sm-6 -->
		</div> <!-- end row -->
	</div>
</div> <!-- end menu-top -->

<script type="text/javascript">
	$(document).ready(function() {
		$('.menu-top .tb').click(function(event) {
			event.preventDefault();

			$('.popup-thongbao').toggle(200);
		});
	});
</script>