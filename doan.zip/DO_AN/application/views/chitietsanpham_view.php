<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Chi tiết sản phẩm</title>
	<?php include 'addLib.php' ?>

	<script type="text/javascript">
		$(document).ready(function() {
			$('.menu').addClass('bg_menu');
		});
	</script>
</head>
<body>
	<!-- <?php include 'loading.php' ?> -->

	<div class="content-main">
	<?php include 'dangnhap.php' ?>	

		
		<div class="product-info mt-5 pt-5">
			<div class="container">
				<div class="row">
					<?php foreach ($sanpham as $item): ?>
						<div class="col-sm-5">
							<div class="tren">
								<img src="<?= $item['hinhanh'] ?>" class="img-fluid active" alt="">
							</div>
							<div class="duoi">
								<a class="active" href=""><img src="<?= $item['hinhanh'] ?>" class="img-fluid" alt=""></a>
							</div>
						</div>
						<div class="col-sm-7">
							<h3 class="text-uppercase font-weight-bold mt-5 pt-5"><?= $item['tensp'] ?></h3>
							<div class="vachngan"></div>
							<p class="gioithieu mt-5"><?= $item['mota'] ?></p>
							<h3 class="giatien mt-4 mb-4"><?= number_format($item['gia']) ?> Đ</h3>
							<a data-id="<?= $item['masp'] ?>" href="" class="btn btn-outline-danger text-uppercase themgiohang"><i class="fas fa-cart-plus "></i> Thêm vào giỏ</a>
						</div>
					<?php endforeach ?>
				</div>
			</div>
		</div> <!-- end product-info -->
		
		<div class="mota-danhgia mt-5">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<div class="tren">
							<ul>
								<li class="text-uppercase"><a class="text-orange active" href="#item1">Mô tả</a></li>
								<li class="text-uppercase"><a class="text-orange" href="#item2">Đánh giá</a></li>
							</ul>
						</div>
						<div class="duoi">
							<ul>
								<li id="item1" class="active mota">
									<p>
										<?= $item['motachitiet'] ?>
									</p>
								</li>
								<li id="item2" class="danhgia">
									<div id="carousel-danhgia" class="carousel slide" data-ride="carousel" data-interval="2000">
									  <div class="carousel-inner">
									    <div class="carousel-item active">
									    	<div class="row mt-5">
									    		<div class="col-sm-2">
									    			<img src="images/admin.jpg" alt="">
									    		</div>
									    		<div class="col-sm-10">
									    			<h4 class="tenkhachhang">ADMIN</h4>
									    			<i class="fas fa-star"></i>
									    			<i class="fas fa-star"></i>
									    			<i class="fas fa-star"></i>
									    			<i class="fas fa-star"></i>
									    			<i class="far fa-star"></i>
									    			<p class="mt-4 loidanhgia">Lorem ipsum dolor sit amet, consectetur adipisicing elPellentesque vehicula augue eget.Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit.</p>
									    		</div>
									    	</div>
									    </div> <!-- end carousel item -->

									    <div class="carousel-item">
									    	<div class="row mt-5">
									    		<div class="col-sm-2">
									    			<img src="images/admin.jpg" alt="">
									    		</div>
									    		<div class="col-sm-10">
									    			<h4 class="tenkhachhang">Nguyễn Văn A</h4>
									    			<i class="fas fa-star"></i>
									    			<i class="fas fa-star"></i>
									    			<i class="fas fa-star"></i>
									    			<i class="fas fa-star"></i>
									    			<i class="far fa-star"></i>
									    			<p class="mt-4 loidanhgia">Lorem ipsum dolor sit amet, consectetur adipisicing elPellentesque vehicula augue eget.Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit.</p>
									    		</div>
									    	</div>
									    </div> <!-- end carousel item -->

									    <div class="carousel-item">
									    	<div class="row mt-5">
									    		<div class="col-sm-2">
									    			<img src="images/admin.jpg" alt="">
									    		</div>
									    		<div class="col-sm-10">
									    			<h4 class="tenkhachhang">Trần Văn B</h4>
									    			<i class="fas fa-star"></i>
									    			<i class="fas fa-star"></i>
									    			<i class="fas fa-star"></i>
									    			<i class="far fa-star"></i>
									    			<i class="far fa-star"></i>
									    			<p class="mt-4 loidanhgia">
															Lorem ipsum dolor sit amet, consectetur adipisicing elPellentesque vehicula augue eget.Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit.

															Lorem ipsum dolor sit amet, consectetur adipisicing elPellentesque vehicula augue eget.Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit.
															Lorem ipsum dolor sit amet, consectetur adipisicing elPellentesque vehicula augue eget.Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit.
									    			</p>
									    		</div>
									    	</div>
									    </div> <!-- end carousel item -->
									  </div>
									</div> <!-- end carousel -->

									<div class="themdanhgia mt-5">
										<form action="">
											<h4 class="text-uppercase">thêm đánh giá</h4>
											<div class="ngoisao">
												<a href=""><i class="far fa-star"></i></a>
												<a href=""><i class="far fa-star"></i></a>
												<a href=""><i class="far fa-star"></i></a>
												<a href=""><i class="far fa-star"></i></a>
												<a href=""><i class="far fa-star"></i></a>
											</div>
											<textarea class="form-control mt-3"></textarea>
										</form>
									</div> <!-- end themdanhgia -->
								</li>
								<div class="vuong1"></div>
								<div class="vuong2"></div>
							</ul>
						</div> <!-- end div .duoi -->
					</div>
				</div>
			</div> <!-- end container -->
		</div> <!-- end mota-danhgia -->

		
		<div class="sanpham_lienquan">
			<div class="slide_dai">
				<div class="container">
					<div class="tieude">
						<h3 class="text-uppercase">sản phẩm liên quan</h3>
					</div>
					<div class="noidung bg_black ">
						<div id="carouselExampleControls" class="carousel slide" data-ride="carousel" data-pause="hover" data-interval="3000" data-keyboard="true">
						  <div class="carousel-inner">
						  	<?php $i = 0; ?>
						  	<?php while($i < count($sanphamlienquan)) { ?>
						  		<?php if ($i % 5 == 0 && $i < 5): ?>
								    <div class="carousel-item active">
								    	<div class="col-12">
								    		<ul>
								    			<?php for($j = $i; $j < count($sanphamlienquan); ++$j) {?>
								    			<?php $i++; ?>
								    				<li><a href="<?php echo base_url() ?>User/chitietsanpham/<?= $sanphamlienquan[$j]['bidanh'] ?>"><img src="<?= $sanphamlienquan[$j]['hinhanh'] ?>" alt="" class="img-fluid"></a></li>
								    				<?php if ($i % 5 == 0): ?>
								    					<?php break; ?>
								    				<?php endif ?>
								    			<?php } ?>
									    	</ul>
								    	</div>
								    </div> <!-- end carousel-item -->
								<?php elseif ($i % 5 == 0 && $i >= 5): ?>
								    <div class="carousel-item">
								    	<div class="col-12">
								    		<ul>
								    			<?php for($j = $i; $j < count($sanphamlienquan); ++$j) {?>
								    			<?php $i++; ?>
								    				<li><a href="<?php echo base_url() ?>User/chitietsanpham/<?= $sanphamlienquan[$j]['bidanh'] ?>"><img src="<?= $sanphamlienquan[$j]['hinhanh'] ?>" alt="" class="img-fluid"></a></li>
								    				<?php if ($i % 5 == 0): ?>
								    					<?php break; ?>
								    				<?php endif ?>
								    			<?php } ?>
									    	</ul>
								    	</div>
								    </div> <!-- end carousel-item -->  
							    <?php endif ?>
						    <?php } ?>
						  </div>
						  <a class="carousel-control-prev btnprev" href="#carouselExampleControls" role="button" data-slide="prev">
						    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
						    <span class="sr-only">Previous</span>
						  </a>
						  <a class="carousel-control-next btnnext" href="#carouselExampleControls" role="button" data-slide="next">
						    <span class="carousel-control-next-icon" aria-hidden="true"></span>
						    <span class="sr-only">Next</span>
						  </a>
						</div>
					</div> <!-- end noidung -->
					
				</div> <!-- end container	 -->			
			</div>
		</div> <!-- end sanpham_lienquan -->

	</div> <!-- end content-main -->
</body>

	<script>
		$(document).ready(function() {
			$('body').on('click', '.themgiohang', function(event) {
				event.preventDefault();
				
				$.ajax({
					url: '<?php echo base_url() ?>User/themGioHang',
					type: 'POST',
					dataType: 'json',
					data: {
						masp: $(this).data('id')
					},
				})
				.done(function() {
					console.log("success");
				})
				.fail(function() {
					console.log("error");
				})
				.always(function(res) {
					console.log("complete");
					console.log(res);
					$('.thongbaonho').text(res['tongsoluong']);
					$('.thongbaogiohang').addClass('hienlen');
				});
				
			});
		});
	</script>
</html>