<?php 
	$giohang = $this->session->userdata('giohang');
	$soluong =0;
	if(!is_null($giohang))
	{
		if(count($giohang) > 0)
		{
			foreach ($giohang as $item) {
				$soluong += $item['soluong'];
			}
		}
	}
	
 ?>
<?php include 'addLib.php' ?>
<div class="menu">
	<nav class="navbar navbar-expand-lg navbar-dark fixed-top">
		<div class="container">
			<?php if (!is_null($menu)): ?>
				<?php foreach ($menu as $item1): ?>
			 	 <a class="navbar-brand logo" href="<?php echo base_url() ?>"><?= $item1['textlogo'] ?></a>
				  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				    <span class="navbar-toggler-icon"></span>
				  </button>
				
				  <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
				    <ul class="navbar-nav text-uppercase">
				    	<?php foreach ($item1['item'] as $item2): ?>
				    		<li class="nav-item popup">
						        <a class="nav-link mr-3 ml-3 menu-item" href="<?php echo base_url() ?>User/<?= $item2['linkmenu'] ?>"><?= $item2['textmenu'] ?></a>
						        <?php if (count($item2['menuphu']) > 0): ?>
							        <div class="popup-menu">
							        	<ul>
							        		<?php foreach ($item2['menuphu'] as $item3): ?>
							        			<li><a href="<?php echo base_url() ?>User/<?= $item2['linkmenu'] ?>" class="text-uppercase font-weight-bold"><?= $item3['textmenuphu'] ?></a></li>
							        		<?php endforeach ?>
							        	</ul>
							        </div> <!-- end popup-menu -->
						        <?php endif ?>
						      </li>
				    	<?php endforeach ?>
				      
				      
				      <?php if ($this->session->has_userdata('user')): ?>
				      	<?php foreach ($this->session->userdata('user') as $value): ?>
				      		<li class="nav-item user">
						        <a class="nav-link mr-3 ml-3 text-black font-weight-bold" href="#"><?php echo $value['username']; ?><i class="fas fa-user-cog usercog"></i></a>
						        <div class="user-setting">
						        	<ul>
						        		<li><a href="">Cập nhật thông tin</a></li>
						        		<?php foreach ($this->session->userdata('quyen') as $item): ?>
						        			<?php if ($item['maquyen'] == 'quantrivien'): ?>
							        			<li><a href="<?php echo base_url() ?>Admin">Trang Quản Trị</a></li>
							        		<?php elseif($item['maquyen'] == 'quanlydonhang'): ?>
							        			<li><a href="<?php echo base_url() ?>Admin/dondathang">Quản lý đơn hàng</a></li>
							        		<?php endif ?>
						        		<?php endforeach ?>
						        		<?php if ($this->session->has_userdata('user')): ?>
						        			<li><a href="<?php echo base_url() ?>User/donhang">Xem đơn hàng</a></li>
						        		<?php endif ?>
						        		<li><a href="" class="dangxuat">Đăng Xuất</a></li>
						        	</ul>
						        </div>
						    </li>
				      	<?php endforeach ?>
				      	
				      <?php else: ?>
				      	<li class="nav-item popup-user">
					        <button class="nav-link mr-3 ml-3 text-white btn btn-link"><i class="fas fa-user"></i></button>
					        <div class="dangnhap_dangky">
					        	<a href="" class="btn btn-outline-danger text-uppercase btnDangNhap">Đăng nhập</a>
					        	<a href="<?php echo base_url() ?>User/dangky" class="btn btn-outline-danger text-uppercase btnDangKy">Đăng ký</a>
					        </div>
					    </li>
				      <?php endif ?>
				      
				    </ul>
				    <form class="form-inline my-2 my-lg-0">
				      <!-- <button class="btn btn-outline-secondary my-2 my-sm-0" type="submit">Search</button> -->
				      <a href=""><i class="fas fa-search btn-search text-white"></i></a>
				    </form>
				    <div class="giohang">
				    	<i class="fas fa-shopping-cart"></i>
				    	<div class="thongbaonho text-center"><?php echo $soluong ?></div>
				    	<div class="thongbaogiohang">
				    		<div class="layer1">
				    			<i class="fas fa-check-circle"></i>
				    			<p>Thêm vào giỏ hàng thành công</p>
				    		</div>
				    		<div class="layer2">
				    			<button type="button" class="btn btn-danger text-white">Xem giỏ hàng và thanh toán</button>
				    		</div>
				    		<div class="layer3 btnClose">X</div>
				    	</div>
				    </div>
				  </div>
				<?php endforeach ?>
			<?php endif ?>  
	  </div>
	</nav>
</div> <!-- end menu -->

<script>
	$(document).ready(function() {
		

		$('.menu .dangxuat').click(function(event) {
			$.ajax({
				url: '<?php echo base_url() ?>User/dangXuat',
				type: 'POST',
				dataType: 'json'
			})
			.done(function() {
				console.log("success");
			})
			.fail(function() {
				console.log("error");
			})
			.always(function() {
				console.log("complete");
				location.reload();
			});
			
			return false;
		});

		$('.giohang .btnClose').click(function(event) {
			event.preventDefault();
			$('.thongbaogiohang').removeClass('hienlen');
		});

		$('.giohang').click(function(event) {
			$(location).attr('href', '<?php echo base_url() ?>User/giohang');
		});
	});
</script>	