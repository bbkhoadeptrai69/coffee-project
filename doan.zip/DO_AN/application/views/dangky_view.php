<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Đăng ký thành viên</title>
	<?php include 'addLib.php' ?>
</head>
<body>
	<?php include 'dangnhap.php' ?>	

	<?php include 'menu.php' ?>

	<?php include 'slide-menu.php' ?>
	<?php include 'loading.php' ?>
	<div class="dangky">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-12">
					<h2 class="text-uppercase text-center text-muted mt-5">đăng ký thành viên</h2>
				</div>
				<div class="col-6">
					<fieldset class="form-group">
						<label>Họ tên</label>
						<input type="text" class="form-control hoten" placeholder="nhập họ tên">
						<div class="text-danger validHoTen tb"></div>
					</fieldset>
					<fieldset class="form-group">
						<label>Tài khoản</label>
						<input type="text" class="form-control taikhoan" placeholder="nhập tài khoản">
						<div class="text-danger validTaiKhoan tb"></div>
					</fieldset>
					<fieldset class="form-group">
						<label>Mật khẩu</label>
						<input type="password" class="form-control matkhau" placeholder="nhập mật khẩu">
						<div class="text-danger validMatKhau tb"></div>
					</fieldset>
					<fieldset class="form-group">
						<label>Nhập lại mật khẩu</label>
						<input type="password" class="form-control nhaplai" placeholder="nhập lại mật khẩu">
						<div class="text-danger validNhapLai tb"></div>
					</fieldset>
					<fieldset class="form-group">
						<label>Địa chỉ</label>
						<input type="text" class="form-control diachi" placeholder="nhập địa chỉ">
					</fieldset>
					<fieldset class="form-group">
						<label>Email</label>
						<input type="email" class="form-control email" placeholder="nhập email">
						<div class="validEmail"></div>
					</fieldset>
					<fieldset class="form-group">
						<label>Avatar</label>
						<input id="avatar" type="file" class="form-control-file">
						<div class="validAvatar"></div>
					</fieldset>
					<fieldset class="form-group">
						<label>Số điện thoại</label>
						<input type="number" class="form-control sodienthoai" placeholder="nhập số điện thoại">
					</fieldset>
					<button class="btn btn-info mt-4 DangKy">Đăng Ký</button>
				</div>
			</div>
		</div>
	</div>
	
	<div class="menuthongbao thanhcong thongbao bg-info">
		<p><i class="fas fa-check-circle mr-3" style="font-size: 20px"></i>Thành công</p>
		<a class="btndangnhapngay" href="">Đăng nhập ngay</a>
	</div>

	<?php include 'footer.php' ?>

	<script>
		$(document).ready(function() {

			$('.dangky .DangKy').click(function(event) {
				$('.tb').text('');
				if($('.hoten').val() == ''){
					$('.validHoTen').text('Vui lòng không bỏ trống họ tên');
					$('.hoten').focus();
				}
				else if($('.taikhoan').val() == ''){
					$('.validTaiKhoan').text('Vui lòng không bỏ trống tài khoản');
					$('.taikhoan').focus();
				}
				else if($('.matkhau').val() == ''){
					$('.validMatKhau').text('Vui lòng không bỏ trống mật khẩu');
					$('.matkhau').focus();
				}
				else if($('.nhaplai').val() == ''){
					$('.validNhapLai').text('Vui lòng nhập lại mật khẩu');
					$('.nhaplai').focus();
				}
				else if($('.nhaplai').val() != $('.matkhau').val()){
					$('.validNhapLai').text('Nhập lại mật khẩu không khớp');
					$('.nhaplai').focus();
				}
				else{
					var check = true;
					var form_data = new FormData();
					if($('#avatar').val() != '')
					{
						var file_data = $('#avatar').prop('files')[0];
						var type = file_data.type;
	        			var match = ["image/gif", "image/png", "image/jpg", "image/jpeg"];

	        			if (type == match[0] || type == match[1] || type == match[2] || type == match[3]) {
	        				check = true;
	        				form_data.append('avatar', file_data);
	        			}
	        			else{
	        				$('.validAvatar').text('Ảnh không đúng định dạng');
	        				check = false;
	        			}
					}
					
					if(check)
					{
						form_data.append('hoten', $('.hoten').val());
						form_data.append('taikhoan', $('.taikhoan').val());
						form_data.append('matkhau', $('.matkhau').val());
						form_data.append('diachi', $('.diachi').val());
						form_data.append('email', $('.email').val());
						form_data.append('sodienthoai', $('.sodienthoai').val());


						$.ajax({
							url: '<?php echo base_url() ?>User/themThanhVien',
							type: 'POST',
							dataType: 'json',
							cache: false,
			                contentType: false,
			                processData: false,
							data: form_data
						})
						.done(function() {
							console.log("success");
						})
						.fail(function() {
							console.log("error");
						})
						.always(function(res) {
							console.log("complete");
							if(res)
							{
								$('input').val('');
								$('.thanhcong').addClass('hienlen').one('webkitTransitionEnd', function(event) {
									$(this).addClass('matdi').one('webkitTransitionEnd', function(event) {
										$(this).removeClass('matdi').removeClass('hienlen');
									});
								});
								$('.btndangnhapngay').click(function(event) {
									$('.btnDangNhap').trigger('click');
									return false;
								});
							}
							else
							{

							}
						});
					}
				}
			});
		});
	</script>
</body>
</html>