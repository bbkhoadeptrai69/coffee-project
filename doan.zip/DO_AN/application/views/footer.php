<div class="footer mt-5 bg-black pt-5 pb-5">
	<div class="container">
		<div class="row">
			<div class="col-4">
				<div class="brand">
					<div class="logo">
						<a class="" href="">COFFEE DAKLAK</a>
					</div>
					<div class="about mt-3 text-muted">
						<p>Tại The Coffee House, chúng tôi luôn trân trọng những câu chuyện và đề cao giá trị Kết nối con người</p>
					</div>
				</div>
			</div>
			<div class="col-4">
				<div class="address">
					<h2 class="text-uppercase text-center text-white">Địa chỉ</h2>
					<p class="mt-4 text-muted"><i class="fas fa-location-arrow mr-3"></i>Address: 114 Võ Văn Ngân, Bình Thọ, Thủ Đức, Hồ Chí Minh</p>
					<p class="mt-4 text-muted"><i class="fas fa-phone mr-3"></i>Phone: 035 703 7064</p>
					<p class="mt-4 text-muted"><i class="fas fa-envelope mr-3"></i>Email: Admin@bestcoffee.com</p>
				</div>
			</div>
			<div class="col-4">
				<div class="openhours">
					<h2 class="text-uppercase text-center text-white">Giờ mở cửa</h2>
					<div class="row">
						<div class="col-6 float-left">
							<p class="mt-4 ml-5 text-muted">Thứ 2 - Thứ 6:</p>
						</div>
						<div class="col-6 float-right">
							<p class="mt-4 text-muted">8:00 am - 22:30 pm</p>
						</div>
					</div>
					<div class="row">
						<div class="col-6 float-left">
							<p class="mt-4 ml-5 text-muted">Thứ 7:</p>
						</div>
						<div class="col-6 float-right">
							<p class="mt-4 text-muted">8:00 am - 21:30 pm</p>
						</div>
					</div>
					<div class="row">
						<div class="col-6 float-left">
							<p class="mt-4 ml-5 text-muted">Chủ nhật:</p>
						</div>
						<div class="col-6 float-right">
							<p class="mt-4 text-muted">7:00 am - 22:30 pm</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div> <!-- end footer -->