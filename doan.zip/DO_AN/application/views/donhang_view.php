<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Đơn hàng của tôi</title>

</head>
<body>
	<?php include 'slide-menu.php' ?>

	<div class="donhangcuatoi">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-12">
					<p class="ml-5 mt-4 pl-5 font-weight-bold">Đơn hàng của tôi</p>
				</div>
				<div class="col-8">
					<?php foreach ($dsDDH as $item): ?>
						<div class="motdonhang mb-3">
							<div class="row justify-content-center pt-3">
								<div class="col-3">
									<p class="text-muted">Mã đơn hàng</p>
									<p><?= $item['machitietddh'] ?></p>
								</div>
								<div class="col-3">
									<p class="text-muted">Ngày đặt hàng</p>
									<p><?= date('d/m/Y', $item['ngaydat']) ?></p>
								</div>
								<div class="col-3">
									<p class="text-muted">Đơn giá</p>
									<p><?= number_format($item['dongia']) ?> đ</p>
								</div>
								<div class="col-12">
									<hr>
									<div class="row">
										<div class="col-3">
											<img class="img-fluid anhsp" src="<?= $item['hinhanh'] ?>" alt="">
										</div>
										<div class="col-6">
											<a href="" class="tensp text-uppercase"><?= $item['tensp'] ?></a>
											<p class="giasp"><?= number_format($item['gia']) ?> đ</p>
											<p class="soluong">số lượng: <?= $item['soluong'] ?></p>
										</div>
										<div class="col-3">
											<?php if ($item['matinhtrang'] == 'chuaxacnhan'): ?>
												<button data-machitietddh="<?= $item['machitietddh'] ?>" class="form-control btn btn-outline-danger btn-sm btnHuy">Hủy</button>
											<?php endif ?>
										</div>
									</div>
								</div>							
							</div>
						</div> <!-- end motdonhang -->
					<?php endforeach ?>
				</div>
			</div>
		</div><!--  end container -->
	</div> <!-- end donhangcuatoi -->

	<div class="danhsachdonhang">
		<div class="container">
			<div class="row">
				<div class="noidung">
					<table class="table table-hover">
					  <thead>
					    <tr>
					      <th scope="col">Mã đơn hàng</th>
					      <th scope="col">Ngày đặt hàng</th>
					      <th scope="col">Sản phẩm</th>
					      <th scope="col">Đơn giá</th>
					      <th scope="col">Trạng thái đơn hàng</th>
					    </tr>
					  </thead>
					  <tbody>
					  	<?php foreach ($dsDDH as $item): ?>
						    <tr>
						      <td><?= $item['machitietddh'] ?></td>
						      <td><?= date('d/m/Y', $item['ngaydat']) ?></td>
						      <td><?= $item['tensp'] ?></td>
						      <td><?= number_format($item['dongia']) ?> đ</td>
						      <td><?= $item['tentinhtrang'] ?></td>
						    </tr>
					    <?php endforeach ?>
					  </tbody>
					</table>
				</div> <!-- end noidung -->
			</div>
		</div>		
	</div> <!-- end danhsachdonhang -->
	
	<div class="menuthongbao thanhcong thongbaodonhang bg-info">
		<p><i class="fas fa-check-circle mr-3" style="font-size: 20px"></i>Thành công</p>
	</div>

	<?php include 'footer.php' ?>

	<script>
		$(document).ready(function() {
			$('.donhangcuatoi .btnHuy').click(function(event) {
				var machitietddh = $(this).data('machitietddh');

				$.ajax({
					url: 'huydondathang',
					type: 'POST',
					dataType: 'json',
					data: {
						machitietddh: machitietddh
					},
				})
				.done(function() {
					console.log("success");
				})
				.fail(function() {
					console.log("error");
				})
				.always(function(res) {
					console.log("complete");
					if (res) {
						$('.thanhcong').addClass('hienlen').one('webkitTransitionEnd', function(event) {
							$(this).addClass('matdi').one('webkitTransitionEnd', function(event) {
								$(this).removeClass('matdi').removeClass('hienlen');
								location.reload();
							});
						});
					}
				});
				
			});
		});
	</script>
</body>
</html>