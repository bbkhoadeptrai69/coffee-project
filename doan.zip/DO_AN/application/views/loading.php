<div class="loading">
	<div class="tronzoom"></div>
	<div class="tron1"></div>
	<div class="tron2"></div>
</div>